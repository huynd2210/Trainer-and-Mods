CAT MAIL CO. - PACKAGE COUNTER (PLUGIN ONLY)
============================================

This ZIP contains only the Package Counter plugin. It does NOT include
BepInEx.

Requirements
------------
- Cat Mail Co. for Windows (64-bit IL2CPP build)
- BepInEx 6.0.0-be.7xx (or a newer be build) already installed in the
  game folder. If you do not have BepInEx, use the full package instead:
  CatMailCo-PackageCounter-v1.1.0.zip

Installation
------------
1. Close Cat Mail Co.
2. Open the folder containing CatMailCo.exe.
3. Copy the BepInEx folder from this ZIP into the game folder. When
   Windows asks about merging folders, choose to merge/overwrite. This
   adds BepInEx\plugins\PackageCounter and leaves your existing BepInEx
   files untouched.
   Alternatively, copy just the PackageCounter folder into the game's
   BepInEx\plugins folder.
4. Launch the game normally.

Verification
------------
The plugin is loaded when BepInEx\LogOutput.log contains:

    Loading [Package Counter 1.1.0]

Controls
--------
- F8: show or hide the counter overlay.
- Left Shift + F8 twice within five seconds: reset the persistent
  all-time counter.

The total and the Customer / Boat / Home route totals persist. "This
shift" resets between shifts. Invalid or returned parcels are not counted.

Configuration
-------------
The config file is created after the first launch:

- BepInEx\config\com.catmailco.packagecounter.cfg

Multiplayer
-----------
Package Counter is a local overlay; each player keeps their own totals.
Every player should install it for consistent totals. Use a private lobby
while testing. This is an unofficial mod and has not been validated by
the game developer.

Removal
-------
Move BepInEx\plugins\PackageCounter out of the plugins folder and delete it.
