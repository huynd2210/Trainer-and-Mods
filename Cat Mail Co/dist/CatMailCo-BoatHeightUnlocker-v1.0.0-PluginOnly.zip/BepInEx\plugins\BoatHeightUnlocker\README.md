# Boat Height Unlocker

Makes Cat Mail Co.'s boat storage height effectively unlimited while leaving every other storage area unchanged.

The mod relaxes both relevant boat checks:

- parcel-placement maximum stack height;
- departure approved-height validation.

The default maximum is 1000 game units. It can be changed in `BepInEx/config/com.catmailco.boatheightunlocker.cfg` after the first launch.

## Build

Run `build.ps1` from this directory. The compiled plugin is installed to `BepInEx/plugins/BoatHeightUnlocker/BoatHeightUnlocker.dll`.
