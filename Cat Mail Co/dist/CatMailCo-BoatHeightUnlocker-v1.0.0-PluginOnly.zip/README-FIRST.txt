CAT MAIL CO. - BOAT HEIGHT UNLOCKER (PLUGIN ONLY)
==================================================

This ZIP contains only the Boat Height Unlocker plugin. It does NOT
include BepInEx.

Requirements
------------
- Cat Mail Co. for Windows (64-bit IL2CPP build)
- BepInEx 6.0.0-be.7xx (or a newer be build) already installed in the
  game folder. If you do not have BepInEx, use the full package instead:
  CatMailCo-BoatHeightUnlocker-v1.0.0.zip

Installation
------------
1. Close Cat Mail Co.
2. Open the folder containing CatMailCo.exe.
3. Copy the BepInEx folder from this ZIP into the game folder. When
   Windows asks about merging folders, choose to merge/overwrite. This
   adds BepInEx\plugins\BoatHeightUnlocker and leaves your existing
   BepInEx files untouched.
   Alternatively, copy just the BoatHeightUnlocker folder into the
   game's BepInEx\plugins folder.
4. Launch the game normally.

Verification
------------
The plugin is loaded when BepInEx\LogOutput.log contains:

    Loading [Boat Height Unlocker 1.0.0]

Configuration
-------------
The config file is created after the first launch:

- BepInEx\config\com.catmailco.boatheightunlocker.cfg

Boat MaximumHeight defaults to 1000 game units, which effectively removes
the boat height restriction.

Multiplayer
-----------
The host must install the mod, and all clients should install it to avoid
local placement rejection or inconsistent boat behavior. Use a private
lobby while testing. This is an unofficial mod and has not been validated
by the game developer.

Removal
-------
Move BepInEx\plugins\BoatHeightUnlocker out of the plugins folder and
delete it.
