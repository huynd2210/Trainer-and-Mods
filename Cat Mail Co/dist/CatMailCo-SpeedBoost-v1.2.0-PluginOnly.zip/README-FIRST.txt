CAT MAIL CO. - SPEED BOOST (PLUGIN ONLY)
========================================

This ZIP contains only the Speed Boost plugin. It does NOT include
BepInEx.

Requirements
------------
- Cat Mail Co. for Windows (64-bit IL2CPP build)
- BepInEx 6.0.0-be.7xx (or a newer be build) already installed in the
  game folder. If you do not have BepInEx, use the full package instead:
  CatMailCo-SpeedBoost-v1.2.0.zip

Installation
------------
1. Close Cat Mail Co.
2. Open the folder containing CatMailCo.exe.
3. Copy the BepInEx folder from this ZIP into the game folder. When
   Windows asks about merging folders, choose to merge/overwrite. This
   adds BepInEx\plugins\SpeedBoost and leaves your existing BepInEx files
   untouched.
   Alternatively, copy just the SpeedBoost folder into the game's
   BepInEx\plugins folder.
4. Launch the game normally.

Verification
------------
The plugin is loaded when BepInEx\LogOutput.log contains:

    Loading [Speed Boost 1.2.0]

Controls
--------
- F6: cycle the walk-speed multiplier through 1x, 2x, 3x, 5x.
- Left Shift + F6: show or hide the on-screen speed indicator.

The multiplier applies to grounded walking and sprinting. Air movement
and climbing keep their own speeds.

Configuration
-------------
The config file is created after the first launch:

- BepInEx\config\com.catmailco.speedboost.cfg

Multiplayer
-----------
The multiplier only affects your own character; the game clock and other
players are not changed. Every player who wants the speed increase should
install the mod. Use a private lobby while testing. This is an unofficial
mod and has not been validated by the game developer.

Removal
-------
Move BepInEx\plugins\SpeedBoost out of the plugins folder and delete it.
