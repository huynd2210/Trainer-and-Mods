CAT MAIL CO. - BREAK ROOM KEY (PLUGIN ONLY)
============================================

This ZIP contains only the Break Room Key plugin. It does NOT include
BepInEx.

Requirements
------------
- Cat Mail Co. for Windows (64-bit IL2CPP build)
- BepInEx 6.0.0-be.7xx (or a newer be build) already installed in the
  game folder. If you do not have BepInEx, use the full package instead:
  CatMailCo-BreakRoomKey-v1.5.0.zip

Installation
------------
1. Close Cat Mail Co.
2. Open the folder containing CatMailCo.exe.
3. Copy the BepInEx folder from this ZIP into the game folder. When
   Windows asks about merging folders, choose to merge/overwrite. This
   adds BepInEx\plugins\BreakRoomKey and leaves your existing BepInEx
   files untouched.
   Alternatively, copy just the BreakRoomKey folder into the game's
   BepInEx\plugins folder.
4. Launch the game normally and load your save.

Verification
------------
The plugin is loaded when BepInEx\LogOutput.log contains:

    Loading [Break Room Key 1.5.0]

When you load into a game, it should log `Break Room Key: scanning ...`
lines, then unlock the break room door and drop a replacement key near it.

Configuration
-------------
The config file is created after the first launch:

- BepInEx\config\com.catmailco.breakroomkey.cfg

- `Behavior / AutoUnlockDoor` (default `true`): unlock the door directly.
- `Behavior / SpawnKey` (default `true`): spawn the replacement key.

Removal
-------
Move BepInEx\plugins\BreakRoomKey out of the plugins folder and delete it.
