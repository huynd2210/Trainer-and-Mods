"""Offline verification. Extra test-only dependencies: pefile and unicorn."""
import random
import struct
import unittest
from pathlib import Path
import trainer as t

def fixture():
    b = bytearray(t.STRIDE)
    struct.pack_into('<I', b, 0x68, 1)
    b[0x15F] = b[0x323] = b[0x30C] = 1
    for o, v in ((t.HP, 7), (t.MAX_HP, 25), (0x70D4, 8), (0x70D6, 20), (0x228, 42)):
        struct.pack_into('<H', b, o, v)
    struct.pack_into('<I', b, t.XP, 150)
    seal(b)
    return b

def seal(b):
    struct.pack_into('<I', b, 0x78, t.health_checksum(b))
    struct.pack_into('<I', b, 0x74, t.stats_checksum(b))

def apply(b, action):
    edits, guard, message = t.plan_change(b, t.u32(b, 0x78), t.u32(b, 0x74), action)
    b = bytearray(b)
    for offset, data in edits: b[offset:offset + len(data)] = data
    return b, guard

class LogicTests(unittest.TestCase):
    def test_heal_and_xp_are_one_shot(self):
        b = fixture(); healed, guard = apply(b, 'heal')
        self.assertEqual(t.u16(healed, t.HP), 25)
        self.assertEqual(t.u32(healed, t.XP), 150)
        self.assertEqual(guard, ('health', t.pack32(t.health_checksum(healed))))
        xp, guard = apply(b, 'xp')
        self.assertEqual(t.u32(xp, t.XP), 250)
        self.assertEqual(t.u16(xp, t.HP), 7)
        self.assertEqual(guard, ('stats', t.pack32(t.stats_checksum(xp))))
        twice, _ = apply(xp, 'xp')
        self.assertEqual(t.u32(twice, t.XP), 350)

    def test_mana_refill_changes_only_stamina_and_health_guard(self):
        for current in (0, 8, 19):
            b = fixture(); struct.pack_into('<H', b, t.SP, current); seal(b)
            filled, guard = apply(b, 'mana')
            self.assertEqual(t.u16(filled, t.SP), 20)
            self.assertEqual(guard, ('health', t.pack32(t.health_checksum(filled))))
            expected = bytearray(b)
            struct.pack_into('<H', expected, t.SP, 20)
            struct.pack_into('<I', expected, 0x78, t.health_checksum(expected))
            self.assertEqual(filled, expected)
            edits, guard, _ = t.plan_change(filled, t.health_checksum(filled), t.stats_checksum(filled), 'mana')
            self.assertEqual(edits, []); self.assertIsNone(guard)

    def test_mana_refuses_invalid_stamina_and_stale_guard(self):
        b = fixture(); struct.pack_into('<H', b, t.SP, 21); seal(b)
        with self.assertRaises(t.Refused): apply(b, 'mana')
        b = fixture()
        with self.assertRaises(t.Refused):
            t.plan_change(b, t.health_checksum(b) - 1, t.stats_checksum(b), 'mana')

    def test_refuses_stale_guards_dead_and_non_player(self):
        for offset in (0x74, 0x78, 0x15F, 0x323, t.HP):
            b = fixture(); b[offset] = 0
            with self.assertRaises(t.Refused):
                t.plan_change(b, 102, t.stats_checksum(b), 'heal')
        b = fixture()
        for h, s in ((t.health_checksum(b) + 1, t.stats_checksum(b)), (t.health_checksum(b), t.stats_checksum(b) + 1)):
            with self.assertRaises(t.Refused): t.plan_change(b, h, s, 'xp')

    def test_exp_overflow_refused(self):
        b = fixture(); struct.pack_into('<I', b, t.XP, 0x7FFFFFFF - 99); seal(b)
        with self.assertRaises(t.Refused): apply(b, 'xp')
        struct.pack_into('<I', b, t.XP, 0x7FFFFFFF - 100); seal(b)
        updated, _ = apply(b, 'xp')
        self.assertEqual(t.u32(updated, t.XP), 0x7FFFFFFF)

    def test_full_health_no_writes(self):
        b, _ = apply(fixture(), 'heal')
        edits, guard, _ = t.plan_change(b, t.health_checksum(b), t.stats_checksum(b), 'heal')
        self.assertEqual(edits, []); self.assertIsNone(guard)

    def test_partial_failure_rolls_back_every_field(self):
        class Memory:
            def __init__(self): self.b = bytearray(b'abcdefghijkl'); self.calls = 0
            def read(self, a, n): return bytes(self.b[a:a+n])
            def write(self, a, v):
                self.calls += 1
                if self.calls == 2:
                    self.b[a] = v[0]
                    raise OSError('simulated partial write')
                self.b[a:a+len(v)] = v
        p = Memory()
        with self.assertRaises(OSError): t.commit(p, [(0, b'1234'), (4, b'5678'), (8, b'9012')])
        self.assertEqual(p.b, bytearray(b'abcdefghijkl'))

    @unittest.skipUnless(t.sys.platform == 'win32', 'Windows API test')
    def test_real_child_process_memory_transaction_and_resume(self):
        import subprocess
        import ctypes
        child_code = ('import ctypes,json,sys; '
                      'b=ctypes.create_string_buffer(b"abcdefgh"); '
                      'print(json.dumps(ctypes.addressof(b)),flush=True); '
                      'sys.stdin.readline(); print(b.raw[:8].decode(),flush=True)')
        child = subprocess.Popen([t.sys.executable, '-c', child_code], stdin=subprocess.PIPE,
                                 stdout=subprocess.PIPE, text=True,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
        p = t.Process.__new__(t.Process)
        p.handle = t.OpenProcess(0x1000 | 0x0800 | 0x38, False, child.pid)
        try:
            self.assertTrue(p.handle)
            address = int(child.stdout.readline())
            with p.paused():
                self.assertEqual(p.read(address, 8), b'abcdefgh')
                t.commit(p, [(address, b'1234'), (address + 4, b'5678')])
            out, _ = child.communicate('\n', timeout=5)
            self.assertEqual(out.strip(), '12345678')
        finally:
            p.close()
            if child.poll() is None: child.kill(); child.wait()

class OriginalMachineCodeTests(unittest.TestCase):
    def setUp(self):
        # Failure-path tests deliberately leave the CPU stopped inside a guard;
        # each test gets a fresh process image, stack, and register state.
        type(self).setUpClass()

    @classmethod
    def setUpClass(cls):
        import pefile
        from unicorn import Uc, UC_ARCH_X86, UC_MODE_32
        from unicorn.x86_const import UC_X86_REG_ESP, UC_X86_REG_EAX, UC_X86_REG_EIP
        cls.ESP, cls.EAX, cls.EIP = UC_X86_REG_ESP, UC_X86_REG_EAX, UC_X86_REG_EIP
        pe = pefile.PE(str(t.ROOT / 'Zorbus.exe'))
        cls.uc = Uc(UC_ARCH_X86, UC_MODE_32)
        cls.uc.mem_map(0, 0xA00000)
        cls.uc.mem_write(0x10000, pe.get_memory_mapped_image())
        cls.uc.mem_map(0x1000000, 0x30000)
        cls.uc.mem_map(0x2000000, 0x10000)
        cls.array = 0x1000100
        cls.player = cls.array + t.STRIDE
        cls.stop = 0x200F000
        cls.uc.mem_write(cls.array-4, t.pack32(3))
        cls.set_global(0x2878F0, cls.array)
        cls.set_global(0x287F9C, 1)
        cls.set_global(0x287BD0, 1)

    @classmethod
    def global_addr(cls, slot): return t.u32(cls.uc.mem_read(slot, 4), 0)
    @classmethod
    def set_global(cls, slot, value): cls.uc.mem_write(cls.global_addr(slot), t.pack32(value))

    def call(self, entry, eax=1, stop=None):
        uc = self.uc
        uc.mem_write(0x2008000, t.pack32(self.stop))
        uc.reg_write(self.ESP, 0x2008000)
        uc.reg_write(self.EAX, eax)
        uc.emu_start(entry, self.stop if stop is None else stop, count=20000)
        self.assertEqual(uc.reg_read(self.EIP), self.stop if stop is None else stop)
        return uc.reg_read(self.EAX)

    def test_random_records_match_original_calculators(self):
        rng = random.Random(61)
        for _ in range(100):
            b = bytearray(rng.randbytes(t.STRIDE))
            b[0x15F] = b[0x323] = 1
            self.uc.mem_write(self.player, bytes(b))
            for fn in (0x1C8248, 0x1941B8, 0x1D9C88, 0x1DA05C, 0x1DB044):
                self.assertEqual(self.call(fn), t.health_checksum(b))
            # Use the original stat validator's independently implemented sum,
            # stopping at its comparison instruction. This does not require a
            # synthetic dungeon map to satisfy the calculator's coordinate check.
            self.assertEqual(self.call(0x225858, 0, stop=0x2259AA), t.stats_checksum(b))

    def test_game_health_guard_accepts_update_rejects_raw_edit(self):
        b = fixture(); h0 = t.health_checksum(b)
        b, _ = apply(b, 'heal'); self.uc.mem_write(self.player, bytes(b))
        self.set_global(0x287A6C, 0)
        self.call(0x1CD4CC, t.health_checksum(b))
        self.assertEqual(bytes(self.uc.mem_read(self.global_addr(0x287A6C), 1)), b'\0')
        self.call(0x1CD4CC, h0)
        self.assertEqual(bytes(self.uc.mem_read(self.global_addr(0x287A6C), 1)), b'\1')

    def test_game_stats_guard_accepts_update_rejects_raw_edit(self):
        b = fixture(); s0 = t.stats_checksum(b)
        b, _ = apply(b, 'xp'); self.uc.mem_write(self.player, bytes(b))
        self.set_global(0x2879F4, 0)
        self.call(0x225858, t.stats_checksum(b))
        self.assertEqual(bytes(self.uc.mem_read(self.global_addr(0x2879F4), 1)), b'\0')
        # Stop immediately after the original checker sets its failure flag,
        # before its punitive game-world changes require more synthetic state.
        self.call(0x225858, s0, stop=0x2259BA)
        self.assertEqual(bytes(self.uc.mem_read(self.global_addr(0x2879F4), 1)), b'\1')

    def test_game_guard_accepts_mana_refill_rejects_stale_checksum(self):
        b = fixture(); old_guard = t.health_checksum(b)
        b, guard = apply(b, 'mana'); self.uc.mem_write(self.player, bytes(b))
        self.set_global(0x287A6C, 0)
        self.call(0x1CD4CC, t.u32(guard[1], 0))
        self.assertEqual(bytes(self.uc.mem_read(self.global_addr(0x287A6C), 1)), b'\0')
        self.call(0x1CD4CC, old_guard)
        self.assertEqual(bytes(self.uc.mem_read(self.global_addr(0x287A6C), 1)), b'\1')

    def test_level_load_dialogue_marker_is_not_an_integrity_failure(self):
        # A perfectly valid, unmodified character and its level-up snapshot.
        b = fixture()
        self.uc.mem_write(self.player, bytes(b))
        self.uc.mem_write(self.global_addr(0x2876B8), bytes(b))
        self.set_global(0x287394, t.health_checksum(b))
        self.set_global(0x287F70, t.stats_checksum(b))
        self.set_global(0x2878F4, 0)
        self.set_global(0x2876F8, 0)
        # Original level-load code calls 0x231EEC at 0x1B7E38 after a random
        # chance check, without requiring an integrity failure. Stop immediately
        # after its marker write and before random dialogue selection.
        self.call(0x231EEC, stop=0x23202C)
        self.assertEqual(bytes(self.uc.mem_read(self.global_addr(0x2876F8), 1)), b'\1')
        for slot in (0x287A6C, 0x2879F4):
            self.assertEqual(bytes(self.uc.mem_read(self.global_addr(slot), 1)), b'\0')

        class Memory:
            def __init__(self, test): self.test = test
            @t.contextmanager
            def paused(self): yield
            def read(self, address, size): return bytes(self.test.uc.mem_read(address, size))
            def int(self, address): return t.u32(self.read(address, 4), 0)
            def global_address(self, slot): return self.test.global_addr(slot)
            def global_int(self, slot): return self.int(self.global_address(slot))
        memory = Memory(self)
        address, record = t.get_player(memory)
        self.assertEqual(address, self.player)
        self.assertEqual(record, b)
        edits, _, _ = t.plan_change(record, t.health_checksum(b), t.stats_checksum(b), 'mana')
        self.assertTrue(edits)
        # Genuine failure flags must continue to block every edit.
        for slot in (0x287A6C, 0x2879F4):
            self.set_global(slot, 1)
            with self.assertRaises(t.Refused): t.get_player(memory)
            report = t.json.loads(t.diagnose(memory))
            self.assertEqual(report['integrity_flags'][t.INTEGRITY_FLAGS[slot]], 1)
            self.assertEqual(report['dialogue_marker_not_a_failure'], 1)
            self.assertEqual(memory.read(self.player, t.STRIDE), b)
            self.assertEqual(memory.read(self.global_addr(slot), 1), b'\1')
            self.set_global(slot, 0)

if __name__ == '__main__': unittest.main(verbosity=2)
