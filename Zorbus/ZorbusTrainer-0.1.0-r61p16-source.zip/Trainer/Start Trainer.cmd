@echo off
cd /d "%~dp0"
python trainer.py watch
pause
