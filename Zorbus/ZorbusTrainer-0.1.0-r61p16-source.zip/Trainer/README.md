# Zorbus trainer — r61 patch 16

Three one-shot actions: heal your living player to maximum HP, refill stamina (the game's mana equivalent), and add exactly 100 EXP. This is an experimental local memory trainer for the executable in this installation. Healing and stamina refill have been confirmed in-game by the user. The level-transition refusal fix has an original-machine-code regression test; further gameplay verification is still useful.

## Run

1. Start Zorbus normally and enter a dungeon with a disposable character. For a local trainer run, turn off **Send obituary** in the game settings before creating the character.
2. Leave the character idle, then run **Start Trainer.cmd** in this folder. Python is already installed on this computer.
3. Return to the dungeon screen:
   - **Ctrl+Alt+F6:** heal to full.
   - **Ctrl+Alt+F7:** add 100 EXP.
   - **Ctrl+Alt+F8:** refill stamina / mana to full.
4. Return to the trainer console to see the result or refusal reason. Press **Ctrl+C** there to stop it.

The shortcuts only perform actions when this Zorbus process is foreground. Key repeat is disabled. Use them while waiting for your next turn, outside menus, character creation, level-up screens, saving, or loading. The trainer exits when the game closes; restart it after restarting the game.

After updating the trainer, stop the old trainer with Ctrl+C and run Start Trainer.cmd again to load the new actions and EXP amount. The game can stay open.

EXP is added immediately to the stored total. Zorbus checks for level-ups when it awards EXP; earn a small amount normally afterward to trigger that check. The trainer does not force the level-up menu. A subsequent game redraw may be needed before changed HP/EXP appears on screen.

From PowerShell in this folder, commands are also available:

```powershell
python .\trainer.py status
python .\trainer.py diagnose
python .\trainer.py heal
python .\trainer.py mana
python .\trainer.py xp
```

## Integrity checks and backups

The trainer verifies the exact executable SHA-256 and two loaded-code signatures. It resolves the current player through the game's pointer slots and dynamic creature array. It validates both existing checksums before writing and updates the stat, its record checksum, and its global checksum copy together while the process is briefly paused. A failed write triggers rollback. It refuses dead characters, mismatched checksums, unsupported executables, and the mapped pre-existing integrity flags. It does not clear flags, patch executable code, freeze HP, inject threads, or edit save files.

The original trainer mistakenly treated a dialogue-preparation marker as an integrity failure. The game can set that marker during ordinary dungeon-level loading with valid stats. This false-positive check has been removed; the two actual validation-failure flags and both checksum checks remain enforced. Restart the trainer after updating. If a refusal persists, run `python .\trainer.py diagnose` and share its output. Diagnostics read stats, checksum copies, flags, and reason codes without changing game memory, even if an actual failure flag is set.

Before the first action in each launch, existing Save files and settings are copied into **backups\<timestamp>.zip**. This backup contains the last on-disk save, not unsaved progress in memory. Actions are logged in **actions.jsonl**. To restore, close Zorbus, preserve the current Save folder elsewhere, and restore the ZIP's Save contents. Restore settings only if desired.

## Verification and the gameplay test still needed

Offline tests exercise the original executable's health and stat validation instructions in an x86 emulator, including proving that stale checksums trigger rejection. They compare 100 randomized records against the original arithmetic, test exact EXP increments, full-health and full-stamina no-ops, overflow refusal, rollback after partial failure, and real Windows child-process read/write/suspend/resume. A regression test runs the original level-load dialogue routine with valid, unmodified stats: its marker is set, genuine failure flags remain clear, and trainer actions remain available. The same test verifies that real failure flags still block writes and remain readable through diagnostics.

These tests do **not** establish that every game integrity path is covered or that live pointer/state behavior is correct. For the first gameplay test:

1. Take damage and note HP and EXP; start the trainer and check its printed status agrees.
2. Use heal once; confirm HP equals max after a redraw or normal turn.
3. Spend some stamina, use Ctrl+Alt+F8 once, and confirm stamina equals its maximum. Use EXP once; confirm exactly +100 before earning further EXP. Earn EXP normally and check the level-up flow.
4. Play several turns, change dungeon level, then save/quit/reload. Check for crashes, unexpected deaths, lost stats, or integrity messages.
5. Report the trainer console output and which step failed. Do not keep testing a valuable character if anything looks wrong.

Developer tests: `python test_trainer.py` (test-only packages: `pefile`, `unicorn`). The trainer itself uses only Python's standard library.
