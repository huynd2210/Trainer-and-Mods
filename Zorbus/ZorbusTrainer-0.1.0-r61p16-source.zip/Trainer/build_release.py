"""Build both distribution archives from explicit allowlists (Windows x64)."""
from pathlib import Path
import hashlib
import importlib.metadata as metadata
import json
import platform
import struct
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
VERSION = '0.1.0'
NAME = f'ZorbusTrainer-{VERSION}-r61p16'

def run(*args):
    subprocess.run([sys.executable, *args], cwd=HERE, check=True)

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    if sys.platform != 'win32' or struct.calcsize('P') != 8:
        raise SystemExit('Build with 64-bit Python on Windows.')
    run('test_trainer.py')
    dist = HERE / 'dist'; dist.mkdir(exist_ok=True)
    work = HERE / 'build' / 'release'; work.mkdir(parents=True, exist_ok=True)
    run('-m', 'PyInstaller', '--noconfirm', '--clean', '--onefile', '--console',
        '--noupx', '--name', 'ZorbusTrainer', '--distpath', str(work / 'bin'),
        '--workpath', str(work / 'pyinstaller'), '--specpath', str(work),
        str(HERE / 'trainer.py'))
    exe = work / 'bin' / 'ZorbusTrainer.exe'
    help_result = subprocess.run([str(exe), '--help'], check=True, cwd=work,
                                 capture_output=True, text=True,
                                 creationflags=subprocess.CREATE_NO_WINDOW)
    if 'diagnose' not in help_result.stdout or 'mana' not in help_result.stdout:
        raise RuntimeError('Packaged executable did not return the expected command help.')
    print('Packaged command help verified.')
    py_license = Path(sys.base_prefix) / 'LICENSE.txt'
    pyinstaller = metadata.distribution('pyinstaller')
    boot_license = next(pyinstaller.locate_file(f) for f in pyinstaller.files
                        if str(f).endswith('licenses/COPYING.txt'))
    manifest = {
        'version': VERSION, 'platform': 'Windows x64',
        'game': 'Zorbus r61 p16',
        'game_sha256': 'ee6be16c41924db2c6ba39bc5fda6afc0e36402a65e2612be61435dca476b856',
        'python': platform.python_version(),
        'build_dependencies': {name: metadata.version(name) for name in
                               ('pyinstaller', 'pefile', 'unicorn', 'capstone')},
        'exe_sha256': digest(exe), 'trainer_source_sha256': digest(HERE / 'trainer.py'),
        'validation': 'Automated tests and packaged --help passed. Gameplay coverage: see README.md.',
    }
    archives = []
    runtime = dist / f'{NAME}-windows-x64.zip'
    with zipfile.ZipFile(runtime, 'w', zipfile.ZIP_DEFLATED) as z:
        z.write(exe, 'Trainer/ZorbusTrainer.exe')
        z.writestr('Trainer/Start Trainer.cmd', '@echo off\r\ncd /d "%~dp0"\r\n"%~dp0ZorbusTrainer.exe" watch\r\npause\r\n')
        # Both packages contain instructions tailored to their actual entrypoint.
        readme = (HERE / 'README.md').read_text(encoding='utf-8')
        readme = readme.replace('Python is already installed on this computer.', 'No Python installation is required.')
        readme = readme.replace('python .\\trainer.py', '.\\ZorbusTrainer.exe')
        readme = readme.replace('python test_trainer.py', 'python test_trainer.py (in the separate source package)')
        z.writestr('Trainer/README.md', readme)
        z.write(HERE / 'DISTRIBUTION.md', 'Trainer/DISTRIBUTION.md')
        z.write(py_license, 'Trainer/licenses/Python-LICENSE.txt')
        z.write(boot_license, 'Trainer/licenses/PyInstaller-COPYING.txt')
        z.writestr('Trainer/BUILD-INFO.json', json.dumps(manifest, indent=2) + '\n')
    archives.append(runtime)
    source = dist / f'{NAME}-source.zip'
    source_files = ['trainer.py', 'test_trainer.py', 'build_release.py',
                    'requirements-dev.txt', 'README.md', 'DISTRIBUTION.md',
                    'Start Trainer.cmd', 'research/disasm.py']
    with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED) as z:
        for name in source_files: z.write(HERE / name, 'Trainer/' + name)
        notes = (HERE / 'research' / 'NOTES.md').read_text(encoding='utf-8')
        # Omit the local character snapshot from public technical notes.
        notes = notes.split('\nOn reloading the reported character,')[0].rstrip() + '\n'
        z.writestr('Trainer/research/NOTES.md', notes)
        z.writestr('Trainer/BUILD-INFO.json', json.dumps(manifest, indent=2) + '\n')
    archives.append(source)
    for archive in archives:
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None: raise RuntimeError(f'Corrupt archive: {archive}')
    (dist / 'SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.name}\n' for p in archives), encoding='ascii')
    for p in archives: print(f'{p.name}: {p.stat().st_size:,} bytes')

if __name__ == '__main__': main()
