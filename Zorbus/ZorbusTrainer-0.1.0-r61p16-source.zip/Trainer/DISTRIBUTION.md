# Zorbus Trainer 0.1.0

Windows x64 trainer for the 32-bit Zorbus release 61, patch 16 executable.
Features: full health, full stamina/mana, and +100 EXP. Includes the fix for
the false integrity refusal after dungeon-level loading.

## Install the standalone package

1. Close any previous trainer console. The game can stay open.
2. Extract the ZIP into the Zorbus installation directory. Keep the folder
   layout: `Zorbus.exe` and `Trainer` must be beside each other.
3. Start the game and load a character. Open `Trainer\Start Trainer.cmd`.
   Python does not need to be installed for the standalone package.
4. While idle on the dungeon screen:
   - Ctrl+Alt+F6: heal to full.
   - Ctrl+Alt+F7: add 100 EXP.
   - Ctrl+Alt+F8: refill stamina/mana.

The trainer console prints action results. Ctrl+C in that console stops it.
The standalone executable also accepts `status`, `diagnose`, `heal`, `mana`,
`xp`, and `watch`, for example `ZorbusTrainer.exe diagnose`.

Backups and action logs are created locally under Trainer when you use it.
Existing saves are backed up before the first action in a trainer launch.
See README.md for recovery instructions, EXP level-up behavior, and test limits.

## Supported game build

Zorbus.exe SHA-256:
`ee6be16c41924db2c6ba39bc5fda6afc0e36402a65e2612be61435dca476b856`

Other builds are deliberately refused. This release contains the trainer only;
you must supply your own installed game. Game binaries, saves, personal settings,
backups, and usage logs are not included.

## Build from source

Extract the source ZIP into your Zorbus directory, preserving its Trainer folder.
Use Windows x64 with Python 3.12 (this release was built with Python 3.12.10).
From PowerShell inside Trainer:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe test_trainer.py
.\.venv\Scripts\python.exe build_release.py
```

The build runs tests, builds a console executable with PyInstaller, and writes
standalone/source ZIPs plus SHA256SUMS.txt into `dist`. Tests require the original
supported Zorbus.exe one directory above Trainer to emulate its checksum code.
The source trainer itself needs only Python's standard library:
`python trainer.py watch`.

The standalone binary bundles Python and the PyInstaller bootloader. Their
redistribution notices are included under `licenses`. The included game-specific
analysis refers to addresses in the supported build; no game binary code is shipped.
