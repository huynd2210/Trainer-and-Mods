"""Local Zorbus r61 p16 trainer. Python standard library only."""
from __future__ import annotations

import argparse
import ctypes as C
from ctypes import wintypes as W
from contextlib import contextmanager
from datetime import datetime
import hashlib
import json
from pathlib import Path
import struct
import sys
import time
import zipfile

# PyInstaller extracts __file__ to a temporary directory. Locate the game next
# to the installed Trainer folder, not next to that temporary runtime.
TRAINER_DIR = (Path(sys.executable) if getattr(sys, 'frozen', False) else Path(__file__)).resolve().parent
ROOT = TRAINER_DIR.parent
HASH = 'ee6be16c41924db2c6ba39bc5fda6afc0e36402a65e2612be61435dca476b856'
IMAGE_BASE = 0x10000
STRIDE = 0x8B98
HP, MAX_HP, XP = 0x70CE, 0x70D0, 0x2F4
SP, MAX_SP = 0x70D4, 0x70D6
XP_AMOUNT = 100
INTEGRITY_FLAGS = {0x287A6C: 'health/stamina validation', 0x2879F4: 'character validation'}

def u16(b, o): return struct.unpack_from('<H', b, o)[0]
def u32(b, o): return struct.unpack_from('<I', b, o)[0]
def pack32(n): return struct.pack('<I', n & 0xFFFFFFFF)

def health_checksum(b):
    return sum(u16(b, o) for o in (0x228, HP, MAX_HP, SP, MAX_SP))

def stats_checksum(b):
    total = u16(b, 0x228)
    total += sum(struct.unpack_from('<b', b, o)[0] for o in range(0x3F4, 0x3F8))
    total += sum(struct.unpack_from('<b', b, o)[0] for o in range(0x409, 0x410))
    total += sum(struct.unpack_from('<h', b, o)[0] for o in range(0x7030, 0x704A, 2))
    total += u16(b, 0x70CC) + u16(b, 0x70D2)
    total += sum(b[o] for o in (0x30C, 0x30D, 0x30E))
    total += sum(u32(b, o) for o in (XP, 0x2F8, 0x2FC))
    return total & 0xFFFFFFFF

class Refused(RuntimeError): pass

def plan_change(record, hp_guard, stats_guard, action):
    """Return only changed fields; never overwrite the whole creature record."""
    if len(record) != STRIDE:
        raise Refused('Incomplete player record.')
    if u32(record, 0x68) == 0 or record[0x15F] != 1 or record[0x323] != 1:
        raise Refused('No active player character. Load a living character first.')
    hp, maximum = u16(record, HP), u16(record, MAX_HP)
    if not 0 < hp <= maximum or not 1 <= record[0x30C] <= 100:
        raise Refused('Player is dead or the stat layout is unexpected.')
    h, s = health_checksum(record), stats_checksum(record)
    if (u32(record, 0x78), hp_guard) != (h, h):
        raise Refused('Health checksums do not match. Wait for an idle turn and retry.')
    if (u32(record, 0x74), stats_guard) != (s, s):
        raise Refused('Stat checksums do not match. Wait for an idle turn and retry.')
    if action == 'heal':
        if hp == maximum: return [], None, f'Already at full health ({hp}/{maximum}).'
        updated = bytearray(record)
        struct.pack_into('<H', updated, HP, maximum)
        h = health_checksum(updated)
        return [(HP, struct.pack('<H', maximum)), (0x78, pack32(h))], ('health', pack32(h)), f'Healed {hp}/{maximum} -> {maximum}/{maximum}.'
    if action == 'mana':
        current, maximum = u16(record, SP), u16(record, MAX_SP)
        if current > maximum:
            raise Refused('Stamina exceeds its maximum; no changes were made.')
        if current == maximum:
            return [], None, f'Already at full stamina / mana ({current}/{maximum}).'
        updated = bytearray(record)
        struct.pack_into('<H', updated, SP, maximum)
        h = health_checksum(updated)
        return [(SP, struct.pack('<H', maximum)), (0x78, pack32(h))], ('health', pack32(h)), f'Refilled stamina / mana {current}/{maximum} -> {maximum}/{maximum}.'
    if action == 'xp':
        old = u32(record, XP)
        if old > 0x7FFFFFFF - XP_AMOUNT:
            raise Refused('EXP would exceed the supported integer range.')
        updated = bytearray(record)
        struct.pack_into('<I', updated, XP, old + XP_AMOUNT)
        s = stats_checksum(updated)
        return [(XP, pack32(old + XP_AMOUNT)), (0x74, pack32(s))], ('stats', pack32(s)), f'EXP {old} -> {old + XP_AMOUNT} (+{XP_AMOUNT}). The next normal EXP award triggers the game\'s level-up check.'
    raise Refused('Unknown action.')

if sys.platform == 'win32':
    k = C.WinDLL('kernel32', use_last_error=True)
    ntdll = C.WinDLL('ntdll')
    user = C.WinDLL('user32', use_last_error=True)
    def api(dll, name, restype, *args):
        f = getattr(dll, name); f.restype = restype; f.argtypes = list(args); return f
    OpenProcess = api(k, 'OpenProcess', W.HANDLE, W.DWORD, W.BOOL, W.DWORD)
    CloseHandle = api(k, 'CloseHandle', W.BOOL, W.HANDLE)
    ReadProcessMemory = api(k, 'ReadProcessMemory', W.BOOL, W.HANDLE, C.c_void_p, C.c_void_p, C.c_size_t, C.POINTER(C.c_size_t))
    WriteProcessMemory = api(k, 'WriteProcessMemory', W.BOOL, W.HANDLE, C.c_void_p, C.c_void_p, C.c_size_t, C.POINTER(C.c_size_t))
    Suspend = api(ntdll, 'NtSuspendProcess', W.LONG, W.HANDLE)
    Resume = api(ntdll, 'NtResumeProcess', W.LONG, W.HANDLE)
    Snapshot = api(k, 'CreateToolhelp32Snapshot', W.HANDLE, W.DWORD, W.DWORD)
    QueryPath = api(k, 'QueryFullProcessImageNameW', W.BOOL, W.HANDLE, W.DWORD, W.LPWSTR, C.POINTER(W.DWORD))
    GetForegroundWindow = api(user, 'GetForegroundWindow', W.HWND)
    WindowPID = api(user, 'GetWindowThreadProcessId', W.DWORD, W.HWND, C.POINTER(W.DWORD))
    KeyState = api(user, 'GetAsyncKeyState', C.c_short, C.c_int)
    RegisterHotKey = api(user, 'RegisterHotKey', W.BOOL, W.HWND, C.c_int, W.UINT, W.UINT)
    UnregisterHotKey = api(user, 'UnregisterHotKey', W.BOOL, W.HWND, C.c_int)
    PeekMessage = api(user, 'PeekMessageW', W.BOOL, C.POINTER(W.MSG), W.HWND, W.UINT, W.UINT, W.UINT)

    class PROCESSENTRY(C.Structure):
        _fields_ = [('size', W.DWORD), ('usage', W.DWORD), ('pid', W.DWORD), ('heap', C.c_size_t), ('module', W.DWORD), ('threads', W.DWORD), ('parent', W.DWORD), ('priority', W.LONG), ('flags', W.DWORD), ('exe', W.WCHAR * 260)]
    class MODULEENTRY(C.Structure):
        _fields_ = [('size', W.DWORD), ('id', W.DWORD), ('pid', W.DWORD), ('global_usage', W.DWORD), ('process_usage', W.DWORD), ('base', C.c_void_p), ('length', W.DWORD), ('module', W.HMODULE), ('name', W.WCHAR * 256), ('path', W.WCHAR * 260)]
    ProcessFirst = api(k, 'Process32FirstW', W.BOOL, W.HANDLE, C.POINTER(PROCESSENTRY))
    ProcessNext = api(k, 'Process32NextW', W.BOOL, W.HANDLE, C.POINTER(PROCESSENTRY))
    ModuleFirst = api(k, 'Module32FirstW', W.BOOL, W.HANDLE, C.POINTER(MODULEENTRY))

def find_pid():
    snap = Snapshot(2, 0)
    if snap == C.c_void_p(-1).value: raise C.WinError(C.get_last_error())
    found = []
    try:
        ent = PROCESSENTRY(); ent.size = C.sizeof(ent)
        more = ProcessFirst(snap, C.byref(ent))
        while more:
            if ent.exe.lower() == 'zorbus.exe': found.append(ent.pid)
            more = ProcessNext(snap, C.byref(ent))
    finally: CloseHandle(snap)
    if len(found) != 1: raise Refused('Start exactly one Zorbus.exe and load a character first.')
    return found[0]

class Process:
    def __init__(self, pid):
        self.pid = pid
        self.handle = OpenProcess(0x1000 | 0x0800 | 0x38, False, pid)
        if not self.handle: raise C.WinError(C.get_last_error())
        try:
            size = W.DWORD(32768); path = C.create_unicode_buffer(size.value)
            if not QueryPath(self.handle, 0, path, C.byref(size)): raise C.WinError(C.get_last_error())
            self.path = Path(path.value)
            if self.path.resolve() != (ROOT / 'Zorbus.exe').resolve():
                raise Refused('Running game is not the Zorbus.exe beside this Trainer folder.')
            if hashlib.sha256(self.path.read_bytes()).hexdigest() != HASH:
                raise Refused('Unsupported executable. This trainer supports only the inspected r61 p16 build.')
            snap = Snapshot(0x18, pid)
            if snap == C.c_void_p(-1).value: raise C.WinError(C.get_last_error())
            try:
                ent = MODULEENTRY(); ent.size = C.sizeof(ent)
                if not ModuleFirst(snap, C.byref(ent)): raise C.WinError(C.get_last_error())
                if Path(ent.path).resolve() != self.path.resolve(): raise Refused('Unexpected main module.')
                self.base = ent.base
            finally: CloseHandle(snap)
            # Check loaded code too, so a patched process cannot silently use this layout.
            probes = {0x1C8248:'53568b1df0782800', 0x1D82EC:'5356578bd88b3df0782800'}
            for address, expected in probes.items():
                code = bytearray.fromhex(expected)
                # Each probe ends with the relocated creature-array pointer-slot address.
                code[-4:] = pack32(self.at(0x2878F0))
                if self.read(self.at(address), len(code)) != code:
                    raise Refused('Loaded game code does not match the supported build.')
        except BaseException:
            self.close(); raise

    def close(self):
        if self.handle: CloseHandle(self.handle); self.handle = None
    def at(self, va): return self.base + va - IMAGE_BASE
    def read(self, address, count):
        result = C.create_string_buffer(count); done = C.c_size_t()
        if not ReadProcessMemory(self.handle, address, result, count, C.byref(done)) or done.value != count:
            raise C.WinError(C.get_last_error())
        return result.raw
    def write(self, address, value):
        done = C.c_size_t(); buf = C.create_string_buffer(value)
        if not WriteProcessMemory(self.handle, address, buf, len(value), C.byref(done)) or done.value != len(value):
            raise C.WinError(C.get_last_error())
    def int(self, address): return u32(self.read(address, 4), 0)
    def global_address(self, slot):
        address = self.int(self.at(slot))
        if not self.base <= address < self.base + 0x8E4000:
            raise Refused('Unexpected global pointer.')
        return address
    def global_int(self, slot): return self.int(self.global_address(slot))
    @contextmanager
    def paused(self):
        # KeyboardInterrupt is deferred during this tiny transaction so it cannot
        # interrupt the suspend call before the finally block is established.
        import signal
        previous = signal.signal(signal.SIGINT, signal.SIG_IGN)
        suspended = False
        try:
            status = Suspend(self.handle)
            if status < 0: raise Refused(f'Could not suspend game: NTSTATUS {status & 0xFFFFFFFF:08x}')
            suspended = True
            yield
        finally:
            try:
                if suspended and Resume(self.handle) < 0:
                    raise Refused('Could not resume the game process. Close/restart the game if it remains frozen.')
            finally: signal.signal(signal.SIGINT, previous)

def get_player(p, *, check_integrity=True):
    index = p.global_int(0x287F9C)
    if index != p.global_int(0x287BD0): raise Refused('Return control to your player character first.')
    array = p.global_int(0x2878F0)
    if not array or not 1 <= index < 100000: raise Refused('No loaded character.')
    length = p.int(array - 4)
    if not index < length <= 100000: raise Refused('Invalid creature array bounds.')
    address = array + index * STRIDE
    record = p.read(address, STRIDE)
    # 0x2876F8 is a dialogue-preparation marker set during ordinary level loads,
    # even with valid checksums. It must not be treated as an integrity failure.
    # Retain the actual failure flags; never clear game flags to make edits pass.
    if check_integrity:
        failures = [f'{name} (slot 0x{slot:X})' for slot, name in INTEGRITY_FLAGS.items()
                    if p.read(p.global_address(slot), 1) != b'\0']
        if failures:
            diagnostic_command = 'ZorbusTrainer.exe diagnose' if getattr(sys, 'frozen', False) else 'python trainer.py diagnose'
            raise Refused('Game integrity failure: ' + ', '.join(failures) +
                          f'. No changes made. Run "{diagnostic_command}" for details.')
    mode = p.global_address(0x287578)
    if p.read(mode + 0x0D, 2) != b'\0\0': raise Refused('Not in a normal active adventure.')
    return address, record

def diagnose(p):
    """Read state even when an integrity flag is set; never repair or edit it."""
    with p.paused():
        address, b = get_player(p, check_integrity=False)
        result = {
            'player_index': p.global_int(0x287F9C),
            'record_address': hex(address),
            'hp': [u16(b, HP), u16(b, MAX_HP)],
            'stamina': [u16(b, SP), u16(b, MAX_SP)],
            'xp': u32(b, XP), 'level': b[0x30C],
            'health_checksum': {'computed': health_checksum(b), 'record': u32(b, 0x78),
                                'global': p.global_int(0x287394)},
            'stat_checksum': {'computed': stats_checksum(b), 'record': u32(b, 0x74),
                              'global': p.global_int(0x287F70)},
            'integrity_flags': {name: p.read(p.global_address(slot), 1)[0]
                                for slot, name in INTEGRITY_FLAGS.items()},
            'dialogue_marker_not_a_failure': p.read(p.global_address(0x2876F8), 1)[0],
            'reason_codes': {f'0x{slot:X}': p.global_int(slot)
                             for slot in (0x287DC8, 0x287800, 0x287DA4)},
        }
    return json.dumps(result, indent=2)

def backup():
    directory = ROOT / 'Trainer' / 'backups'; directory.mkdir(exist_ok=True)
    target = directory / (datetime.now().strftime('%Y%m%d-%H%M%S-%f') + '.zip')
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted((ROOT / 'Save').glob('*')):
            if path.is_file(): archive.write(path, path.relative_to(ROOT))
        for name in ('Settings.txt', 'Keybindings.txt'):
            path = ROOT / 'Data' / name
            if path.exists(): archive.write(path, path.relative_to(ROOT))
    return target

def commit(p, writes):
    originals = [(a, p.read(a, len(v))) for a, v in writes]
    try:
        for a, value in writes: p.write(a, value)
        for a, value in writes:
            if p.read(a, len(value)) != value: raise Refused('Write verification failed.')
    except BaseException as error:
        failures = []
        for a, old in reversed(originals):
            try:
                p.write(a, old)
                if p.read(a, len(old)) != old: failures.append(hex(a))
            except BaseException: failures.append(hex(a))
        if failures: raise Refused(f'Rollback failed at {failures}; restart without saving.') from error
        raise

def operate(p, action):
    with p.paused():
        address, record = get_player(p)
        guards = {'health': p.global_address(0x287394), 'stats': p.global_address(0x287F70)}
        if action == 'status':
            # Run the same validation, but do not apply the heal plan.
            plan_change(record, p.int(guards['health']), p.int(guards['stats']), 'heal')
            return f"HP {u16(record, HP)}/{u16(record, MAX_HP)} | SP (mana) {u16(record, SP)}/{u16(record, MAX_SP)} | EXP {u32(record, XP)} | Level {record[0x30C]} | checksums OK"
        edits, guard, message = plan_change(record, p.int(guards['health']), p.int(guards['stats']), action)
        if edits:
            writes = [(address + offset, data) for offset, data in edits]
            writes.append((guards[guard[0]], guard[1]))
            commit(p, writes)
    if edits:
        with (ROOT / 'Trainer' / 'actions.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps({'time': datetime.now().isoformat(), 'pid': p.pid, 'action': action, 'result': message}) + '\n')
    return message

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['status', 'diagnose', 'heal', 'mana', 'xp', 'watch'], nargs='?', default='watch')
    args = parser.parse_args()
    if sys.platform != 'win32': raise Refused('Windows is required.')
    p = Process(find_pid())
    try:
        if args.action == 'diagnose':
            print(diagnose(p)); return
        print(operate(p, 'status'), flush=True)
        if args.action == 'status': return
        print(f'Save backup: {backup()}', flush=True)
        if args.action != 'watch': print(operate(p, args.action)); return
        registered = []
        try:
            actions = {1: 'heal', 2: 'xp', 3: 'mana'}
            for identifier, key in ((1, 0x75), (2, 0x76), (3, 0x77)):
                if not RegisterHotKey(None, identifier, 0x4003, key):
                    raise Refused('A Ctrl+Alt+F6/F7/F8 shortcut is already registered. Use the heal/xp/mana command instead.')
                registered.append(identifier)
            print(f'Ready. In Zorbus: Ctrl+Alt+F6 = heal; Ctrl+Alt+F7 = +{XP_AMOUNT} EXP; Ctrl+Alt+F8 = refill stamina / mana.\nCtrl+C here stops trainer. Use only while idle on the dungeon screen.', flush=True)
            get_exit = api(k, 'GetExitCodeProcess', W.BOOL, W.HANDLE, C.POINTER(W.DWORD))
            while True:
                msg = W.MSG()
                while PeekMessage(C.byref(msg), None, 0x312, 0x312, 1):
                    foreground = W.DWORD()
                    WindowPID(GetForegroundWindow(), C.byref(foreground))
                    if foreground.value == p.pid and msg.wParam in actions:
                        try: print(operate(p, actions[msg.wParam]), flush=True)
                        except (OSError, Refused) as exc: print(f'REFUSED: {exc}', flush=True)
                exit_code = W.DWORD()
                if not get_exit(p.handle, C.byref(exit_code)) or exit_code.value != 259: break
                time.sleep(0.025)
        finally:
            for identifier in registered: UnregisterHotKey(None, identifier)
    finally: p.close()

if __name__ == '__main__':
    try: main()
    except KeyboardInterrupt: print('\nTrainer stopped.')
    except (Refused, OSError) as exc:
        print(f'REFUSED: {exc}', file=sys.stderr); sys.exit(1)
