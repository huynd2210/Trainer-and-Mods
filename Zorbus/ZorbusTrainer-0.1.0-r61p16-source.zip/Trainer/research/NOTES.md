# Local binary findings

Executable: Zorbus r61 p16, PE32 Delphi, preferred image base `0x10000`.
SHA-256: `ee6be16c41924db2c6ba39bc5fda6afc0e36402a65e2612be61435dca476b856`.
Addresses below are preferred-image virtual addresses, relocated in the trainer.

Pointer slots:

| Slot | Meaning |
| --- | --- |
| 0x2878F0 | Address of dynamic creature-array pointer |
| 0x287F9C | Address of original player index |
| 0x287BD0 | Address of currently controlled creature index |
| 0x287394 | Address of player HP/SP checksum copy |
| 0x287F70 | Address of player stat/EXP checksum copy |

Creature stride is `0x1173 * 8 = 0x8B98`. Delphi array length is at array pointer minus four. Index zero is not a playable creature. Record `+0x68` must be nonzero; `+0x15F` marks player, `+0x323` is checked by experience routines for an active being.

HP is uint16 at `+0x70CE`; max HP is uint16 at `+0x70D0`. EXP is uint32 at `+0x2F4`. Level is byte `+0x30C`. Checksums are uint32 at `+0x78` (HP/SP) and `+0x74` (stats/EXP).

Health checksum: sum of unsigned 16-bit fields `0x228, 0x70CE, 0x70D0, 0x70D4, 0x70D6`. Original calculators include `0x1C8248`, `0x1941B8`, `0x1D9C88`, `0x1DA05C`, `0x1DB044`. The healing routine `0x1E0ABC` updates HP, record checksum and global copy. Original validator `0x1CD4CC` sets the flag pointed to by `0x287A6C` on mismatch.

Stat checksum: unsigned word `0x228`; signed bytes `0x3F4..0x3F7` and `0x409..0x40F`; 13 signed words `0x7030..0x7048`; unsigned words `0x70CC,0x70D2`; bytes `0x30C,0x30D,0x30E`; unsigned dwords `0x2F4,0x2F8,0x2FC`, summed modulo 2^32. Original calculator `0x1D82EC`; original validator `0x225858`, comparison at `0x2259AA`, failure flag pointer slot `0x2879F4`.

The gain-experience effect at `0x17C67C` updates `+0x2F4`, calls `0x1D82EC`, writes `+0x74`, then calls level-up check `0x1DFD08`. Other callers of the level-up check are EXP award paths `0x1E04B5`, `0x1E0680`, `0x1E24B6`. Thus an external EXP write should not promise immediate level-up on a simple redraw or wait turn.

Anti-cheat text includes “Die, cheater, die!” and “Cheat Engine? Really? Come on.” near `0x2320F0`. Multiple integrity paths exist. This implementation preserves the two mapped stat invariants; it does not claim exhaustive anti-cheat coverage. No original game files were modified during development.

## Correction: false refusal after dungeon transition

Slot `0x2876F8` points to byte `0x7A24B5`. The initial trainer incorrectly classified this byte as an integrity-failure flag because `0x231EEC` writes it near anti-cheat dialogue strings. That classification was not supported by the caller. Level-load code at `0x1B7E2E..0x1B7E38` calls the routine based on a random chance after resolving a valid player, with no integrity-failure condition. The routine sets the marker at `0x232029` and selects a taunt string. A fixture with consistent, unmodified health and stat checksums reproduces the marker becoming 1 while real failure flags remain 0. The old trainer rejects this exact fixture; the corrected trainer permits it.

Removed only this marker from the trainer's refusal conditions. The trainer does not clear the marker or change the game's routine. Actual failure slots `0x287A6C` and `0x2879F4` still block writes and now appear by name/address in refusal messages. Added read-only `diagnose` action for flags and all three copies of each checksum.
