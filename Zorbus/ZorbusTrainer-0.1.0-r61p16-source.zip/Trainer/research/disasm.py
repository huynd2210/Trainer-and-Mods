import sys, struct
from pathlib import Path
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_32

EXE = Path(__file__).resolve().parents[2] / 'Zorbus.exe'
pe = pefile.PE(str(EXE))
data = EXE.read_bytes()
base = pe.OPTIONAL_HEADER.ImageBase
md = Cs(CS_ARCH_X86, CS_MODE_32)

def dis(start, size):
    offset = pe.get_offset_from_rva(start-base)
    for i in md.disasm(data[offset:offset+size], start):
        print(f'{i.address:08x}  {i.bytes.hex():20s} {i.mnemonic:8s} {i.op_str}')

def refs(addr):
    needle=struct.pack('<I',addr)
    pos=0
    while (pos:=data.find(needle,pos))>=0:
        print(hex(pe.get_rva_from_offset(pos)+base));pos+=1

if __name__=='__main__':
    if sys.argv[1]=='refs': refs(int(sys.argv[2],16))
    else: dis(int(sys.argv[1],16),int(sys.argv[2],16))
