@echo off
cd /d "%~dp0"
"%~dp0ZorbusTrainer.exe" watch
pause
