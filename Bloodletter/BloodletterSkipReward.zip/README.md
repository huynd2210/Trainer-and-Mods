# Bloodletter — Skip Card Reward

Adds a **skip** option to the card reward you are offered at the end of each day, so a day can end
without forcing a card into the deck.

## What it does

Bloodletter already contains the whole skip mechanic — `CardReward.Skip()` is implemented and wired
to a `ButtonID.Skip` button — but the button is only revealed while `CardManager.Skips > 0`, which
only ever happens while the Skipper remedy is held. This mod reveals it on every reward instead.

Skipping does what the game's own skip does: no card is added, and the next reward's first slot is
forced to a rare (`RareChance = 100`), exactly like declining a reward with the Skipper remedy.

## Where the skip appears

| Reward | Skip offered | Why |
|---|---|---|
| End-of-day villager reward | yes | this is the one you asked for |
| Bloodstone-extraction reward | yes | resumes through `OnCardRewardConfirmed`, which skip fires |
| Run-setup rewards (before day 1) | no | the setup coroutine waits on `pickingCardReward`, which the game's `Skip()` never clears |
| Reward created by a played card | no | the card resumes through `CEGetCardReward.EffectDone`, which the game's `Skip()` never calls |

The last two are held back because the game's own `Skip()` would strand the sequence that spawned
them. Set `AllowIncompleteSkipRewards = true` if you want them anyway.

## Install

Drop `BepInEx/plugins/BloodletterSkipReward.dll` into the game folder (or use the `-Pack` zip, which
brings BepInEx with it). Launch once to generate
`BepInEx/config/dev.bloodletter.skipreward.cfg`.

## Config — `BepInEx/config/dev.bloodletter.skipreward.cfg`

| Setting | Default | Meaning |
|---|---|---|
| `Enabled` | `true` | Show the skip option. |
| `AllowIncompleteSkipRewards` | `false` | Also offer skip on the two reward flavours listed above. |
| `UseConfirmButtonFallback` | `true` | If a reward prefab has no Skip button wired up, show the Confirm button with nothing selected instead — the game treats an empty confirm as a skip — wearing the prefab's own skip sprite. |

## How it hooks in

No Harmony patch. The reveal runs from the game's own
`EventHandler.CardRewardCardsSpawnedEvent`, which fires at the end of the reward's spawn animation:
right after the game decides whether to show the skip button, and just before it hands interaction
back to the player.

## Compatibility

Built against Bloodletter (Unity 6000.3.11, Mono) with **BepInEx 5.4.23.5 x64 (Unity Doorstop
4.5.0)**. Older BepInEx 5 builds are not interchangeable here: 5.4.23.2 / doorstop 4.3.0 crashes
this game during preloader startup, before the graphics device is created.
