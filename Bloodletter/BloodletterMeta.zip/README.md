# Bloodletter — Meta Progression

Permanent, cross-run upgrades. Buy them once in an in-game panel; they apply automatically at the
start of every new run.

**Every upgrade costs 0 by default, so the whole tree is free.** Costs are configurable — set the
`*Cost` entries in the config file to turn it into an economy.

## The upgrades

| Upgrade | Ranks | Effect per rank |
|---|---|---|
| **Steady Hands** | 1–6 | +1 hand size (`SteadyHandsPerLevel` changes the step) |
| **Blessed Beginnings** | 1–5 | one extra random blessing shuffled into the starting deck |
| **Night Physician** | 1 | cures 1 sickness on a random sick villager each night |
| **Whispered Faith** | 1 | turns 1 random distrusting villager to trust each night |
| **The Chosen** | 1–5 | one extra random villager starts at 100 purity and 100 health |

Rank caps are config entries (`*Max`), so Night Physician and Whispered Faith can be raised past 1 —
each extra rank cures/converts one more villager per night.

**The Chosen** prefers villagers already in the village on day 1, and only reaches into the
villagers who arrive later if you own more ranks than there are villagers present.

## Using it

* Press **M** (configurable). The small **ICHOR** readout in the screen corner shows your balance
  and the key — it is a label, not a button, so it never takes a click meant for the game. Drag the
  panel's header to move it.
* Buy ranks; **−** refunds one rank, **Refund all** empties the tree and returns every Ichor spent.
* Changes apply to the **next new run**. A run already in progress keeps its own state — including a
  run resumed from a save, whose bonuses were already baked in on its day 1.

## Ichor

The currency. You earn `IchorPerDay` (default 1) for every day survived. With every cost at 0 it is
purely a score; raise the costs and it becomes the gate. Reloading a save does not re-pay days that
were already paid for.

## Install

Drop `BepInEx/plugins/BloodletterMeta.dll` into the game folder (or use the `-Pack` zip, which
brings BepInEx with it). Launch once to generate `BepInEx/config/dev.bloodletter.meta.cfg`.

## Config — `BepInEx/config/dev.bloodletter.meta.cfg`

| Section | Setting | Default | Meaning |
|---|---|---|---|
| General | `Enabled` | `true` | Apply upgrades. Off = play vanilla without uninstalling. |
| General | `Hotkey` | `M` | Opens/closes the panel. |
| General | `ShowCornerButton` | `true` | The always-on ICHOR readout. |
| General | `HudCorner` | `TopLeft` | Which corner the readout sits in: `TopLeft`, `TopRight`, `BottomLeft`, `BottomRight`. The game keeps its own buttons top-right. |
| Economy | `Ichor` | `0` | Current balance (this is where it is saved). |
| Economy | `IchorPerDay` | `1` | Earned per day survived. |
| Upgrades | `<Name>` | `0` | Owned rank. |
| Upgrades | `<Name>Max` | see table | Rank cap. |
| Upgrades | `<Name>Cost` | `0` | Ichor per rank. `0` = free. |
| Upgrades | `SteadyHandsPerLevel` | `1` | Hand size per Steady Hands rank. |

Levels, costs and the Ichor balance all live in this file, so they persist between sessions and can
be hand-edited.

## How it hooks in

* **Run start** — Harmony postfix on `DayCycleManager.InitializeTheGame(bool withRunSave)`. The
  village and the deck are both built by the time it returns, and the flag distinguishes a fresh run
  from a resumed one.
* **Night** — `EventHandler.EntityNightlyActivityFinishedEvent`, so a cure lands *after* the
  entity's nightly spread rather than being overwritten by it.
* **Day payout** — `EventHandler.DayCompletedEvent`.

Blessings are built the same way the game builds a starter-deck card, and shuffled into the draw
pile. The Chosen writes purity and health directly rather than going through `ChangeHealth`, which
would fire the "reached 100 health" blessing payout and a stat popup during setup.

The panel is drawn with IMGUI, matching the other Unity 6 plugins in this mod family: no canvas to
keep alive across scene loads and no EventSystem dependency for clicks. The corner readout is a
label rather than a button on purpose — a clickable element parked in a screen corner sits on top of
the game's own corner controls and swallows clicks meant for them.

## Compatibility

Built against Bloodletter (Unity 6000.3.11, Mono) with **BepInEx 5.4.23.5 x64 (Unity Doorstop
4.5.0)**. Older BepInEx 5 builds are not interchangeable here: 5.4.23.2 / doorstop 4.3.0 crashes
this game during preloader startup, before the graphics device is created.
