# Drone Sector Trainer

A BepInEx trainer for **Drone Sector** (build 376, Unity 6000.2.6f2, Mono x64).

Press **F1** in game to open the menu. While it is open the mouse is released and drone aiming is
suspended, so moving the cursor will not swing the camera.

## Features

### Drone
| Feature | Effect |
| --- | --- |
| God Mode | Anti-air fire no longer damages the hull or subsystems. |
| No Mission Fail | Suppresses every failure trigger: drone lost, fuel out, all squads lost, timeout, scripted fails. |
| Infinite Fuel | Refills the tank each tick. Unlimited loiter time. |
| Repair Drone | One-shot restore of the hull and every subsystem to 100%. |

### Combat
| Feature | Effect |
| --- | --- |
| Infinite Ammo | Keeps every loaded weapon topped up to magazine capacity. |
| Rapid Fire | Removes weapon cooldown — fires once per frame while the trigger is held. |
| One-Hit Kill | Drone hits kill instantly. **Friendly and neutral units are never affected.** |
| Invincible Squad | Your infantry and vehicles take no damage from any source. |
| Kill All Enemies | Destroys every enemy on the map. Kills are credited to the drone, so destroy objectives count. |

### Mission
| Feature | Effect |
| --- | --- |
| Time Scale | Free game speed from ×0.1 to ×8, with presets. Overrides the game's own fast-forward keys. |
| Freeze / Unfreeze | Toggles the game's pause. |
| Complete Mission | Ends the mission as a success immediately. |

### Economy (career)
Add or zero any career resource and any ammunition type. Edits go into the live stores that the
game serialises on save, so they persist into the career file.

### Status
Live telemetry: hull integrity, fuel and flight time remaining, altitude, speed, selected ammo,
and unit counts per side.

## Configuration

Settings are written to `BepInEx/config/dev.dronesector.trainer.cfg` on first run.

| Setting | Default | Notes |
| --- | --- | --- |
| `ToggleKey` | `F1` | Any [Unity Input System key name](https://docs.unity3d.com/Packages/com.unity.inputsystem@1.18/api/UnityEngine.InputSystem.Key.html). |
| `UiScale` | `1` | Raise to `1.5`–`2` on 1440p/4K displays. |
| `ReleaseCursor` | `true` | Frees the cursor and suspends aiming while the menu is open. |

Toggle states persist across sessions — a cheat left on is still on next launch. The corner
indicator lists everything currently active while the menu is closed.

## Notes and caveats

- **Single-player only.** Do not use this on anything competitive or shared.
- **Back up your career saves** before using the economy panel. Resource and ammunition edits are
  written into the career file on the next autosave and there is no undo.
- Rapid Fire fires once per rendered frame, so its rate of fire scales with your framerate.
- One-Hit Kill spares registered player and neutral units, but destructible scenery is fair game.
- Time Scale suppresses the game's `TimeScaleInput` component while enabled; the game's own
  fast-forward keys resume working the moment you turn it off.

## Troubleshooting

Check `BepInEx/LogOutput.log`. The plugin logs `Drone Sector Trainer 1.0.0 loaded` on success.

- **Nothing happens on F1** — confirm BepInEx loaded at all (the log file exists). If the game
  updated, individual features may log a warning and disable themselves; the rest keep working.
- **Menu is tiny** — raise `UiScale` in the config file.

## Building from source

Requires the .NET SDK. No NuGet packages: the mod references the game's own assemblies plus
`lib/BepInEx.dll` and `lib/0Harmony.dll` taken from BepInEx 5.4.23.4.

```
dotnet build -c Release DroneSectorTrainer/DroneSectorTrainer.csproj
```

Point the build at a different install with `-p:GameDir=...`. `.verify/` contains a checker that
confirms every patched member still exists in the shipped assemblies — run it after a game update.
