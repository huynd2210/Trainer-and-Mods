using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using BepInEx;
using BepInEx.Configuration;
using FallenAces;
using FallenAces.PlayerHands;
using HarmonyLib;
using UnityEngine;
using UnityEngine.InputSystem;
using Key = UnityEngine.InputSystem.Key;

namespace FallenAcesSuperHot
{
    [BepInPlugin(Id, "Fallen Aces SuperHot", "1.0.0")]
    public sealed class SuperHotPlugin : BaseUnityPlugin
    {
        public const string Id = "local.codex.fallenacessuperhot";
        private static SuperHotPlugin instance;
        private Harmony harmony;
        private ConfigEntry<bool> enabledOnStart, convertHitscan;
        private ConfigEntry<Key> toggleKey;
        private ConfigEntry<float> frozenScale, actionGrace, slowFactor, rampTime, bulletSpeed;
        private bool modEnabled, ownsTime;
        private float actionUntil, baseFixedDelta, lastScale = 1f, lastFixedDelta;
        private float projectileFactor = 1f;
        private string status = "";
        private float statusUntil;
        private Animator zoomAnimator;
        private AnimatorUpdateMode savedZoomMode;
        private int zoomStateHash;
        private FirstPersonWeaponHand zoomHand;
        private bool zoomPlaying;

        private static readonly FieldInfo HandInUse = RequiredField(typeof(PlayerHand), "_firstPersonWeaponHandInUse");
        private static readonly FieldInfo RightCooldown = RequiredField(typeof(PlayerRightHand), "_actionCooldownHandler");
        private static readonly FieldInfo CooldownTime = RequiredField(typeof(ActionCooldownHandler), "_actionCooldown");
        private static readonly FieldInfo GenericHands = RequiredField(typeof(PlayerHand), "_genericHandsAnimationHandler");

        private static FieldInfo RequiredField(Type type, string name)
        {
            return AccessTools.Field(type, name) ?? throw new MissingFieldException(type.FullName, name);
        }

        private void Awake()
        {
            instance = this;
            enabledOnStart = Config.Bind("General", "EnabledOnStart", true, "Enable SuperHot when the game starts.");
            toggleKey = Config.Bind("Hotkeys", "ToggleSuperHot", Key.RightBracket, "Input System key; RightBracket is ].");
            frozenScale = Number("General", "FrozenTimeScale", .02f, .01f, .5f, "World speed while idle; never exactly zero.");
            actionGrace = Number("General", "ActionGrace", .35f, .05f, 2f, "Real seconds of normal time after an action ends.");
            slowFactor = Number("Projectiles", "SlowFactor", .15f, .01f, 1f, "Extra enemy projectile slowdown while idle.");
            rampTime = Number("Projectiles", "RampUpTime", 1.5f, .1f, 5f, "Real seconds for enemy projectiles to regain normal speed.");
            convertHitscan = Config.Bind("Projectiles", "ConvertEnemyHitscanBullets", true, "Convert enemy ranged bullet/nail/spear hitscan attacks to travelling projectiles. Melee and player shots are untouched.");
            bulletSpeed = Number("Projectiles", "ConvertedBulletSpeed", 40f, 5f, 200f, "World units per game second for converted enemy hitscan bullets.");
            modEnabled = enabledOnStart.Value;
            harmony = new Harmony(Id);
            try
            {
                harmony.PatchAll(typeof(SuperHotPlugin).Assembly);
                ActionCooldownHandler.StartedActionCooldown += OnActionCooldown;
                Logger.LogInfo("Loaded. ] toggles SuperHot; idle scale 0.02, free look/weapon aim, enemy projectile grace enabled.");
                if (Array.IndexOf(Environment.GetCommandLineArgs(), "-superhot-smoke-test") >= 0)
                    StartCoroutine(SmokeTest());
            }
            catch (Exception ex)
            {
                modEnabled = false;
                harmony.UnpatchSelf();
                Logger.LogError("SuperHot could not initialize; patches removed. " + ex);
                enabled = false;
            }
        }

        private ConfigEntry<float> Number(string section, string key, float value, float min, float max, string description)
        {
            return Config.Bind(section, key, value, new ConfigDescription(description, new AcceptableValueRange<float>(min, max)));
        }

        private static float Safe(ConfigEntry<float> setting, float fallback, float min, float max)
        {
            return TimeLogic.FiniteClamp(setting.Value, fallback, min, max);
        }

        private bool CanControl()
        {
            var time = TimeScaleManager.Instance;
            var world = GameworldSceneController.Instance;
            var player = Player.Instance;
            return isActiveAndEnabled && modEnabled && time != null && !time.Paused && Mathf.Approximately(time.UnpausedTimescale, 1f)
                && world != null && !world.IsLoading && player != null && player.isActiveAndEnabled && player.IsAlive
                && InputManager.Instance != null && InputManager.AllowNormalGameplayInput
                && player.CameraHandler != null && player.CameraHandler.AllowMouseLook
                && player.MovementHandler != null && player.MovementHandler.IsInNormalState
                && !PlayerHandsParent.InCutsceneMode;
        }

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard != null && toggleKey.Value != Key.None && keyboard[toggleKey.Value].wasPressedThisFrame)
            {
                modEnabled = !modEnabled;
                if (!modEnabled) ReleaseTime();
                status = "SuperHot: " + (modEnabled ? "ON" : "OFF");
                statusUntil = Time.unscaledTime + 2.5f;
                Logger.LogInfo(status);
            }
            // Only the scope transition plays in real time. Other weapon animations retain game time.
            if (zoomAnimator != null)
            {
                bool applicable = CanControl() && zoomHand != null && zoomHand.gameObject.activeInHierarchy;
                var state = zoomAnimator.GetCurrentAnimatorStateInfo(0);
                zoomPlaying = applicable && (state.shortNameHash == zoomStateHash || state.fullPathHash == zoomStateHash) && state.normalizedTime < 1f;
                zoomAnimator.updateMode = zoomPlaying ? AnimatorUpdateMode.UnscaledTime : savedZoomMode;
                if (zoomPlaying)
                {
                    var hands = Player.Instance.GetHandsParent();
                    if (hands != null && hands.RightHand != null)
                    {
                        var cooldown = (ActionCooldownHandler)RightCooldown.GetValue(hands.RightHand);
                        if (cooldown != null)
                        {
                            float remaining = (float)CooldownTime.GetValue(cooldown);
                            CooldownTime.SetValue(cooldown, Mathf.Max(0f, remaining - Mathf.Max(0f, Time.unscaledDeltaTime - Time.deltaTime)));
                        }
                    }
                }
            }
        }

        private void LateUpdate()
        {
            if (!CanControl()) { ReleaseTime(); return; }
            if (!ownsTime)
            {
                baseFixedDelta = Time.fixedDeltaTime;
                ownsTime = true;
                projectileFactor = 1f;
            }
            bool acting = IsActing();
            lastScale = acting ? 1f : Safe(frozenScale, .02f, .01f, .5f);
            lastFixedDelta = baseFixedDelta * lastScale;
            Time.timeScale = lastScale;
            Time.fixedDeltaTime = lastFixedDelta;
            projectileFactor = TimeLogic.ProjectileFactor(acting, projectileFactor,
                Safe(slowFactor, .15f, .01f, 1f), Time.unscaledDeltaTime, Safe(rampTime, 1.5f, .1f, 5f));
        }

        private FirstPersonWeaponHand CurrentWeaponHand()
        {
            var player = Player.Instance;
            var hands = player != null ? player.GetHandsParent() : null;
            return hands != null && hands.RightHand != null ? (FirstPersonWeaponHand)HandInUse.GetValue(hands.RightHand) : null;
        }

        private bool IsActing()
        {
            var input = InputManager.Instance.PlayerInput;
            bool action = input.Move.ReadValue<Vector2>().sqrMagnitude > .0025f;
            var fpwh = CurrentWeaponHand();
            bool scope = fpwh != null && fpwh.FirstPersonWeapon != null
                && fpwh.FirstPersonWeapon.SecondaryAction == FirstPersonWeapon.SecondaryActions.Scope;
            foreach (var control in input.Get().actions)
            {
                if (IsFreeInput(control, input, scope)) continue;
                bool hold = control == input.AttackPrimaryAction || control == input.Kick
                    || control == input.ThrowDrop || control == input.Use || control == input.UseGadgetTertiaryAction
                    || (control == input.BlockSecondaryAction && !scope);
                if (control.enabled && (control.WasPerformedThisFrame() || (hold && control.IsPressed()))) action = true;
            }
            var hands = Player.Instance.GetHandsParent();
            if (hands != null)
            {
                action |= hands.ReloadAnimationIsPlaying;
                if (hands.RightHand != null)
                {
                    var generic = (GenericHandsAnimationHandler)GenericHands.GetValue(hands.RightHand);
                    action |= generic != null && generic.AnimationIsPlaying;
                    var substate = hands.RightHand.GetNormalState().CurrentSubState;
                    action |= hands.RightHand.InNormalState() && substate != PlayerRightHand.NormalState.SubState.Default
                        && substate != PlayerRightHand.NormalState.SubState.Scoped;
                }
            }
            if (action) actionUntil = Mathf.Max(actionUntil, Time.unscaledTime + Safe(actionGrace, .35f, .05f, 2f));
            return action || Time.unscaledTime < actionUntil;
        }

        private static bool IsFreeInput(InputAction control, InputMaster.PlayerActions input, bool scope)
        {
            return control == input.LookX || control == input.LookY || control == input.Move || control == input.TestMove
                || control == input.HideHud || control == input.UnhideHud || control == input.Map
                || control == input.QuickSave || control == input.QuickLoad || (scope && control == input.BlockSecondaryAction);
        }

        private void OnActionCooldown(float duration)
        {
            if (!CanControl()) return;
            // Zoom cooldown is compensated locally; it must not wake the world.
            if (zoomPlaying) return;
            actionUntil = Mathf.Max(actionUntil, Time.unscaledTime + TimeLogic.FiniteClamp(duration, .35f, 0f, 30f));
        }

        private void ReleaseTime()
        {
            if (ownsTime)
            {
                var time = TimeScaleManager.Instance;
                Time.timeScale = TimeLogic.ReleasedScale(time != null && time.Paused,
                    time != null ? time.UnpausedTimescale : 1f, Time.timeScale, lastScale);
                if (Mathf.Approximately(Time.fixedDeltaTime, lastFixedDelta)) Time.fixedDeltaTime = baseFixedDelta;
            }
            ownsTime = false;
            projectileFactor = 1f;
            actionUntil = float.NegativeInfinity;
            if (zoomAnimator != null) zoomAnimator.updateMode = savedZoomMode;
        }

        private void OnDisable() { ReleaseTime(); }
        private void OnDestroy()
        {
            ReleaseTime();
            ActionCooldownHandler.StartedActionCooldown -= OnActionCooldown;
            if (harmony != null) harmony.UnpatchSelf();
            if (instance == this) instance = null;
        }

        private void OnGUI()
        {
            if (Time.unscaledTime < statusUntil) GUI.Label(new Rect(18, 18, 420, 32), status);
        }

        private static bool Active => instance != null && instance.isActiveAndEnabled && instance.ownsTime && instance.CanControl();

        // Replace deltaTime inside Travel only: movement, gravity, trajectory progression,
        // distance accounting AND collision sweeps all use the same shortened step.
        public static float ProjectileDelta(Projectile projectile)
        {
            return Time.deltaTime * (Active && projectile.IsEnemyProjectile && !projectile.IsPlayerProjectile ? instance.projectileFactor : 1f);
        }

        [HarmonyPatch(typeof(Projectile), "Travel")]
        private static class ProjectileTravelPatch
        {
            private static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
            {
                var getter = AccessTools.PropertyGetter(typeof(Time), "deltaTime");
                var replacement = AccessTools.Method(typeof(SuperHotPlugin), nameof(ProjectileDelta));
                int count = 0;
                foreach (var code in instructions)
                {
                    if (code.Calls(getter))
                    {
                        var load = new CodeInstruction(OpCodes.Ldarg_0);
                        load.labels.AddRange(code.labels);
                        load.blocks.AddRange(code.blocks);
                        yield return load;
                        yield return new CodeInstruction(OpCodes.Call, replacement);
                        count++;
                    }
                    else yield return code;
                }
                if (count != 4) throw new InvalidOperationException("Projectile.Travel changed: expected 4 deltaTime reads, found " + count);
            }
        }

        [HarmonyPatch(typeof(Projectile), nameof(Projectile.Fire))]
        private static class HitscanPatch
        {
            private static void Prefix(Projectile __instance, ref float ____speed)
            {
                if (Active && instance.convertHitscan.Value && __instance.IsEnemyProjectile && !__instance.IsPlayerProjectile
                    && __instance.IsRangedAttack && __instance.IsBulletLikeProjectile && __instance.IsHitscan)
                    ____speed = Safe(instance.bulletSpeed, 40f, 5f, 200f);
            }
        }

        [HarmonyPatch(typeof(ScaleAxisDeltaTimeProcessor), nameof(ScaleAxisDeltaTimeProcessor.Process))]
        private static class ControllerLookPatch
        {
            private static void Postfix(float value, ref float __result)
            {
                if (Active) __result = value * Time.unscaledDeltaTime;
            }
        }

        [HarmonyPatch(typeof(FirstPersonWeaponHand), nameof(FirstPersonWeaponHand.TryPlayAnimation))]
        private static class ZoomPatch
        {
            private static void Postfix(FirstPersonWeaponHand __instance, FirstPersonWeaponHand.Animation animation,
                bool __result, Animator ____animator, Dictionary<FirstPersonWeaponHand.Animation, FirstPersonWeaponHand.AnimationDefinition> ____animations)
            {
                if (!__result || instance == null) return;
                if (__instance != instance.CurrentWeaponHand()) return;
                if (instance.zoomAnimator != null) instance.zoomAnimator.updateMode = instance.savedZoomMode;
                instance.zoomPlaying = false;
                instance.zoomAnimator = null;
                if (!instance.CanControl() || (animation != FirstPersonWeaponHand.Animation.ZoomIn && animation != FirstPersonWeaponHand.Animation.ZoomOut)) return;
                instance.zoomHand = __instance;
                instance.zoomAnimator = ____animator;
                instance.savedZoomMode = ____animator.updateMode;
                instance.zoomStateHash = ____animations[animation].AnimatorStateHash;
                instance.zoomPlaying = true;
                ____animator.updateMode = AnimatorUpdateMode.UnscaledTime;
            }
        }

        private IEnumerator SmokeTest()
        {
            // Sample as soon as the real input asset exists. Null-renderer startup movies
            // can terminate early on this build, so don't rely on a long fixed delay.
            float deadline = Time.realtimeSinceStartup + 10f;
            while (InputManager.Instance == null && Time.realtimeSinceStartup < deadline) yield return null;
            yield return null;
            var input = InputManager.Instance;
            Logger.LogInfo("SMOKE: patches=" + Harmony.GetAllPatchedMethods().CountOwned(Id)
                + "; input=" + (input != null) + "; ownsTime=" + ownsTime
                + "; scale=" + Time.timeScale + "; fixedDelta=" + Time.fixedDeltaTime);
            if (input != null)
            {
                var actions = input.PlayerInput;
                bool verified = IsFreeInput(actions.LookX, actions, false) && IsFreeInput(actions.LookY, actions, false)
                    && IsFreeInput(actions.BlockSecondaryAction, actions, true) && !IsFreeInput(actions.BlockSecondaryAction, actions, false)
                    && !IsFreeInput(actions.AttackPrimaryAction, actions, false) && !IsFreeInput(actions.Reload, actions, false);
                Logger.LogInfo("SMOKE: input-classification=" + (verified ? "PASS" : "FAIL"));
            }
            Logger.LogInfo("SMOKE COMPLETE (startup only; gameplay still needs manual testing).");
            // BepInEx's disk logger flushes periodically; allow the final diagnostics to reach disk.
            yield return new WaitForSecondsRealtime(1f);
            Application.Quit();
        }
    }

    internal static class PatchInspection
    {
        internal static int CountOwned(this IEnumerable<MethodBase> methods, string owner)
        {
            int count = 0;
            foreach (var method in methods) if (Harmony.GetPatchInfo(method).Owners.Contains(owner)) count++;
            return count;
        }
    }
}
