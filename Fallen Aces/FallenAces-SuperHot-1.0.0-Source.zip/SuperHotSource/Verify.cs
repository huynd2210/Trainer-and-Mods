using System;

namespace FallenAcesSuperHot
{
    internal static class Verify
    {
        private static int checks;
        private static void Equal(string name, float expected, float actual)
        {
            checks++;
            if (float.IsNaN(actual) || Math.Abs(expected - actual) > .0001f)
                throw new Exception(name + ": expected " + expected + ", got " + actual);
        }
        private static void Main()
        {
            Equal("Idle projectile floor", .15f, TimeLogic.ProjectileFactor(false, 1, .15f, .016f, 1.5f));
            Equal("Resume ramps instead of snapping", .25f, TimeLogic.ProjectileFactor(true, .15f, .15f, .15f, 1.5f));
            Equal("Long frame cannot exceed normal speed", 1, TimeLogic.ProjectileFactor(true, .15f, .15f, 8, 1.5f));
            Equal("Second stop resets ramp", .15f, TimeLogic.ProjectileFactor(false, .8f, .15f, .016f, 1.5f));
            foreach (int fps in new[] { 30, 60, 144 })
            {
                float factor = .15f;
                for (int i = 0; i < fps; i++) factor = TimeLogic.ProjectileFactor(true, factor, .15f, 1f / fps, 1.5f);
                Equal("Frame-independent ramp at " + fps + " FPS", .15f + 1f / 1.5f, factor);
            }
            Equal("Toggle off restores native speed", 1, TimeLogic.ReleasedScale(false, 1, .02f, .02f));
            Equal("Pause remains zero", 0, TimeLogic.ReleasedScale(true, 1, 0, .02f));
            Equal("Pause wins even before its setter", 0, TimeLogic.ReleasedScale(true, 1, .02f, .02f));
            Equal("Death slow motion is preserved", .1f, TimeLogic.ReleasedScale(false, .1f, .1f, .02f));
            Equal("New native scale is restored", .5f, TimeLogic.ReleasedScale(false, .5f, .02f, .02f));
            Equal("NaN config has safe fallback", .02f, TimeLogic.FiniteClamp(float.NaN, .02f, .01f, .5f));
            Equal("Infinity config has safe fallback", .02f, TimeLogic.FiniteClamp(float.PositiveInfinity, .02f, .01f, .5f));
            Equal("Zero cannot hard-freeze", .01f, TimeLogic.FiniteClamp(0, .02f, .01f, .5f));
            Console.WriteLine("PASS: " + checks + " time-control checks.");
        }
    }
}
