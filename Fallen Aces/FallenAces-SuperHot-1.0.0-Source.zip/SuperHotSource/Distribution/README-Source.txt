Fallen Aces SuperHot 1.0.0 - Source
=================================
Contains the mod's C# source, build/verification/packaging scripts and
distribution documentation. Game assemblies, decompiled game source,
compiled programs, personal configs and runtime logs are not included.

Build
-----
1. Install BepInEx 5.4.23.5 x64 in your Fallen Aces game folder.
2. Install the .NET 8 SDK (or a newer compatible SDK).
3. Extract this archive into the game folder. SuperHotSource must sit
   beside Fallen Aces.exe, Fallen Aces_Data and BepInEx.
4. Close the game. In PowerShell run:
     & .\SuperHotSource\build.ps1
   This compiles and installs BepInEx\plugins\FallenAces.SuperHot.dll.
   Add -NoInstall to compile only.
5. Run the isolated time-control checks:
     & .\SuperHotSource\verify.ps1
   Verification uses the Windows .NET Framework C# compiler.
6. To rebuild the three release ZIPs:
     & .\SuperHotSource\package.ps1 -Rebuild
   Packaging also requires the BepInEx core files and Doorstop bootstrap
   from the complete bundle in the game folder. Output: release/.

SuperHotPlugin.cs implements input, gameplay gating, time ownership,
scope compensation and Harmony projectile patches.
TimeLogic.cs contains the isolated ramp/config/restoration logic.
Verify.cs tests timing at multiple frame rates and restoration edges.

The mod targets the supplied Fallen Aces v0.9.1 installation (Unity
6000.3.10). Private fields and the projectile method structure are
version-sensitive. Integration targets were checked against that build.

See Distribution/README.txt for player behavior and validation limits.
The implementation was adapted from CULTIC SuperHot 1.3.2.
