param([switch]$Rebuild)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$gameRoot = Split-Path $PSScriptRoot -Parent
$docs = Join-Path $PSScriptRoot 'Distribution'
$release = Join-Path $PSScriptRoot 'release'
$version = '1.0.0'
New-Item -ItemType Directory -Force $release | Out-Null
if ($Rebuild) { & (Join-Path $PSScriptRoot 'build.ps1') -NoInstall }

function Make-Package([string]$Name, [System.Collections.IDictionary]$Entries) {
    $archivePath = Join-Path $release $Name
    foreach ($source in $Entries.Values) {
        if (!(Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing package input: $source" }
    }
    # Explicit entries include .doorstop_version and cannot accidentally include
    # game assemblies, logs, inspection output or personal configurations.
    $stream = [IO.File]::Open($archivePath, [IO.FileMode]::Create)
    $zip = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach ($entry in $Entries.GetEnumerator()) {
            [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $entry.Value, $entry.Key, [IO.Compression.CompressionLevel]::Optimal) | Out-Null
        }
    } finally { $zip.Dispose(); $stream.Dispose() }

    $zip = [IO.Compression.ZipFile]::OpenRead($archivePath)
    try {
        if ($zip.Entries.Count -ne $Entries.Count) { throw "Entry count mismatch: $Name" }
        foreach ($entry in $zip.Entries) {
            if (!$Entries.Contains($entry.FullName)) { throw "Unexpected entry: $($entry.FullName)" }
            $sha = [Security.Cryptography.SHA256]::Create()
            $entryStream = $entry.Open()
            try { $actual = [BitConverter]::ToString($sha.ComputeHash($entryStream)).Replace('-', '') }
            finally { $entryStream.Dispose(); $sha.Dispose() }
            $expected = (Get-FileHash -LiteralPath $Entries[$entry.FullName] -Algorithm SHA256).Hash
            if ($actual -ne $expected) { throw "Content mismatch: $($entry.FullName)" }
        }
    } finally { $zip.Dispose() }
    Write-Host "Verified $Name ($($Entries.Count) files)"
    return $archivePath
}

$mod = [ordered]@{
    'BepInEx/plugins/FallenAces.SuperHot.dll' = Join-Path $PSScriptRoot 'FallenAces.SuperHot.dll'
    'README.txt' = Join-Path $docs 'README.txt'
    'INSTALL.txt' = Join-Path $docs 'INSTALL-ModOnly.txt'
}
$paths = @()
$paths += Make-Package "FallenAces-SuperHot-$version-Mod-Only.zip" $mod

$bundle = [ordered]@{}
foreach ($entry in $mod.GetEnumerator()) { $bundle[$entry.Key] = $entry.Value }
$bundle['INSTALL.txt'] = Join-Path $docs 'INSTALL-WithBepInEx.txt'
foreach ($name in @('winhttp.dll', 'doorstop_config.ini', '.doorstop_version')) { $bundle[$name] = Join-Path $gameRoot $name }
$coreNames = @('0Harmony.dll','0Harmony.xml','0Harmony20.dll','BepInEx.dll','BepInEx.Harmony.dll','BepInEx.Harmony.xml',
    'BepInEx.Preloader.dll','BepInEx.Preloader.xml','BepInEx.xml','HarmonyXInterop.dll','Mono.Cecil.dll',
    'Mono.Cecil.Mdb.dll','Mono.Cecil.Pdb.dll','Mono.Cecil.Rocks.dll','MonoMod.RuntimeDetour.dll',
    'MonoMod.RuntimeDetour.xml','MonoMod.Utils.dll','MonoMod.Utils.xml')
foreach ($name in $coreNames) { $bundle["BepInEx/core/$name"] = Join-Path $gameRoot "BepInEx/core/$name" }
$bundle['BepInEx/config/BepInEx.cfg'] = Join-Path $docs 'BepInEx.cfg'
$bundle['THIRD-PARTY-NOTICES.txt'] = Join-Path $docs 'THIRD-PARTY-NOTICES.txt'
foreach ($file in (Get-ChildItem -LiteralPath (Join-Path $docs 'licenses') -File)) { $bundle["licenses/$($file.Name)"] = $file.FullName }
$paths += Make-Package "FallenAces-SuperHot-$version-With-BepInEx.zip" $bundle

$source = [ordered]@{}
foreach ($name in @('SuperHotPlugin.cs','TimeLogic.cs','Verify.cs','build.ps1','verify.ps1','package.ps1')) {
    $source["SuperHotSource/$name"] = Join-Path $PSScriptRoot $name
}
$source['SuperHotSource/README.txt'] = Join-Path $docs 'README-Source.txt'
foreach ($file in (Get-ChildItem -LiteralPath $docs -Recurse -File)) {
    $relative = $file.FullName.Substring($docs.Length + 1).Replace('\', '/')
    $source["SuperHotSource/Distribution/$relative"] = $file.FullName
}
$paths += Make-Package "FallenAces-SuperHot-$version-Source.zip" $source
$hashes = foreach ($path in $paths) { "{0}  {1}" -f (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant(), (Split-Path $path -Leaf) }
$hashes | Set-Content -LiteralPath (Join-Path $release 'SHA256SUMS.txt') -Encoding ascii
