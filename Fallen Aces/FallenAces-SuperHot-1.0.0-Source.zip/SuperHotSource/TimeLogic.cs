using System;

namespace FallenAcesSuperHot
{
    // Pure time-control math, also exercised outside Unity by the verification runner.
    internal static class TimeLogic
    {
        internal static float FiniteClamp(float value, float fallback, float min, float max)
        {
            return float.IsNaN(value) || float.IsInfinity(value) ? fallback : Math.Max(min, Math.Min(max, value));
        }

        internal static float ProjectileFactor(bool acting, float current, float slow, float elapsed, float ramp)
        {
            return acting ? Math.Min(1f, current + Math.Max(0f, elapsed) / ramp) : slow;
        }

        internal static float ReleasedScale(bool paused, float nativeScale, float currentScale, float lastApplied)
        {
            if (paused) return 0f;
            // Don't overwrite a later native time change (death, cinematics, etc.).
            return Math.Abs(currentScale - lastApplied) < 0.00001f ? nativeScale : currentScale;
        }
    }
}
