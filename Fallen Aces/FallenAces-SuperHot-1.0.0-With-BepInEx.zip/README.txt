Fallen Aces SuperHot 1.0.0
=========================
A BepInEx mod adapted from CULTIC SuperHot 1.3.2.

Press ] (right bracket) to toggle. Enabled by default.

Time slows to 2% while idle. Movement, combat, throwing and interaction
advance time. Looking around and scoped weapon aiming stay free.
Reloads and committed actions have time to finish. Right-click blocking
and melee actions advance time because they share the aim binding.

Enemy projectiles get extra slowdown while idle and regain full speed
gradually when you move, giving you a chance to dodge. Enemy ranged
hitscan bullets become travelling projectiles; player shots and melee
are not converted. Already-converted bullets finish their flight when
you disable the mod.

The game retains time control during menus, loading, death, cutscenes,
native slow motion and special movement such as mantling and vehicles.

Requirements and compatibility
------------------------------
Windows x64, Fallen Aces using the Mono scripting runtime, BepInEx 5.x.
Built against the supplied v0.9.1 installation, Unity 6000.3.10.
The complete bundle includes BepInEx 5.4.23.5 and Doorstop 4.5.0.
Other game builds have not been verified.

Configuration
-------------
After the first launch, close the game and edit:
BepInEx\config\local.codex.fallenacessuperhot.cfg

Options include startup enable, toggle key, idle speed, action grace,
enemy projectile slowdown/ramp, hitscan conversion and bullet speed.
Defaults are generated automatically; no personal config is included.

Uninstall
---------
Close the game and delete BepInEx\plugins\FallenAces.SuperHot.dll.
The loader can remain installed for other mods.

Validation
----------
Compiled successfully. Headless startup verified all four Harmony
patches and input classification. Fifteen time-control logic checks pass.
Gameplay feel, visual behavior and every scripted sequence have not yet
been manually verified. Test idle/aim, attack/reload, projectile dodging,
toggle-off while stationary, pause/resume and death/reload.
For problems, provide BepInEx\LogOutput.log and the steps to reproduce.

This is an unofficial mod. Game files are not included.
