using System; using System.IO; using System.Linq;
EnsureDataLoaded();
GlobalDecompileContext ctx = new(Data);
var st = Data.ToolInfo.DecompilerSettings;
foreach (var n in new[]{"gml_Object_O_foodbrain_Step_2","gml_Object_O_foodbrain_Draw_64"}) {
    var c = Data.Code.ByName(n);
    if (c is null) { Console.WriteLine("MISSING " + n); continue; }
    string s = new Underanalyzer.Decompiler.DecompileContext(ctx, c, st).DecompileToString();
    File.WriteAllText(@"C:\Users\Admin\CSD2-Autoplay-Mod\build\" + n + ".gml", s);
    Console.WriteLine($"{n}: {s.Length} chars, keyboard_key_press={s.Contains("keyboard_key_press")}, AP_init={s.Contains("AP_init")}");
}
