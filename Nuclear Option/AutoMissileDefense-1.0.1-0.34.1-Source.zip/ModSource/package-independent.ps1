param([ValidateSet('AMRAAM','ARHMissileInterceptor','AutoMissileDefense','KillCostTracker')][string]$Mod)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$gameRoot = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$packaging = Join-Path $PSScriptRoot 'Packaging'
$versions = @{AMRAAM='1.1.2'; ARHMissileInterceptor='1.0.1'; AutoMissileDefense='1.0.1'; KillCostTracker='1.5.1'}
$mods = if ($Mod) { @($Mod) } else {
    @('AMRAAM','ARHMissileInterceptor','AutoMissileDefense','KillCostTracker') | Where-Object { Test-Path (Join-Path $PSScriptRoot "$_/$_.csproj") }
}
if (!$mods) { throw 'No mod source projects found.' }
New-Item -ItemType Directory -Path $packaging -Force | Out-Null

function Write-IndependentZip([string]$path, [System.Collections.IDictionary]$entries) {
    $lines = foreach ($entry in $entries.GetEnumerator()) {
        '{0}  {1}' -f (Get-FileHash -LiteralPath $entry.Value).Hash.ToLowerInvariant(), $entry.Key
    }
    $manifest = Join-Path $packaging ([IO.Path]::GetFileNameWithoutExtension($path) + '.MANIFEST.sha256')
    [IO.File]::WriteAllLines($manifest, [string[]]$lines, [Text.UTF8Encoding]::new($false))
    $entries['MANIFEST.sha256'] = $manifest
    if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path }
    $zip = [IO.Compression.ZipFile]::Open($path, 'Create')
    try {
        foreach ($entry in $entries.GetEnumerator()) {
            [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $entry.Value, $entry.Key, 'Optimal') | Out-Null
        }
    } finally { $zip.Dispose() }
    Write-Output ("{0}: {1:N2} MB, {2} entries" -f $path, ((Get-Item $path).Length / 1MB), $entries.Count)
}

foreach ($name in $mods) {
    $root = Join-Path $PSScriptRoot $name
    & (Join-Path $root 'build.ps1')
    $release = Join-Path $gameRoot "release/independent/$name"
    New-Item -ItemType Directory -Path $release -Force | Out-Null
    $instructions = Join-Path $packaging "INSTALL-$name.txt"
    $usage = switch ($name) {
        'AMRAAM' { 'Select AIM-120 AMRAAM on an ARH-capable hardpoint. Change custom saved loadouts back to stock before uninstalling.' }
        'ARHMissileInterceptor' { 'Select an ARH station, use normal target selection for a tracked hostile missile and fire. No new key binding is required.' }
        'AutoMissileDefense' { 'Carry an IR missile such as MMR-S3 and press F8 while flying to toggle automatic defense. It starts OFF by default.' }
        'KillCostTracker' { 'F7 toggles the tracker. With the cursor available, scroll over the panel to see all faction totals.' }
    }
    $modelNotes = if ($name -eq 'AMRAAM') { 'AMRAAM source includes the original Blender file and baked mesh/paint. Optional model re-export reads assets/amraam_inspired.blend from its own source folder.' } else { '' }
    $visualNotes = if ($name -eq 'AMRAAM') { 'The offscreen chooser fixture disables text masking; live dropdown clipping is not verified.' } else { '' }
    $text = @"
$name $($versions[$name]) for Nuclear Option 0.34.1
=================================================
This mod runs independently. None of the other three custom mods is required.
It requires the game and the shared BepInEx 5 Mono loader.

Mod.zip: this mod only; use with an existing compatible BepInEx 5 install.
Dist.zip: this mod plus Windows x64 BepInEx 5.4.23.5 and Doorstop.
Source.zip: only this mod's code, build script, tests/assets where applicable,
and the standalone packaging script. No game assemblies are redistributed.

Install Mod or Dist:
1. Close Nuclear Option. In Steam, Manage > Browse local files.
2. Extract the ZIP beside NuclearOption.exe. Plugin files go into
   BepInEx/plugins/$name. Dist also puts winhttp.dll beside the executable.
3. Start the game. Config is generated on first run. Read the plugin README
   for controls, settings and usage. No personal settings or saves are bundled.
   If BepInEx is already installed, use Mod to keep the existing shared loader.
4. To uninstall, move only BepInEx/plugins/$name outside the plugins directory
   while the game is closed. Leave the shared loader if other mods use it.
   For AMRAAM, change saved custom loadouts back to stock before uninstalling.

Build Source:
Extract into the game directory so ModSource/$name sits beside the game's
NuclearOption_Data and BepInEx folders. Requires .NET 8, game 0.34.1 and BepInEx 5.
Run: powershell -ExecutionPolicy Bypass -File .\ModSource\$name\build.ps1 -Install
Repackage: powershell -ExecutionPolicy Bypass -File .\ModSource\package-independent.ps1 -Mod $name
Other mod source directories are not needed.

$usage
$modelNotes

Standalone loading and startup hooks have been checked in isolated runs.
Live firing, cockpit input, model/bay fit and multiplayer remain manual checks.
$visualNotes
Do not assume a future game version is compatible.

Each archive has MANIFEST.sha256 covering every payload file.
Dist includes upstream license texts for its shared loader libraries.
"@
    [IO.File]::WriteAllText($instructions, $text, [Text.UTF8Encoding]::new($false))
    $modFiles = [ordered]@{'INSTALL.txt'=$instructions}
    $modFiles["BepInEx/plugins/$name/NuclearOption.$name.dll"] = Join-Path $root "bin/Release/NuclearOption.$name.dll"
    $modFiles["BepInEx/plugins/$name/README.md"] = Join-Path $root 'README.md'
    if ($name -eq 'AMRAAM') {
        foreach ($asset in @('amraam.meshbin','amraam-paint.png')) {
            $modFiles["BepInEx/plugins/AMRAAM/$asset"] = Join-Path $root "assets/$asset"
        }
    }
    $dist = [ordered]@{}
    foreach ($entry in $modFiles.GetEnumerator()) { $dist[$entry.Key]=$entry.Value }
    foreach ($file in @('winhttp.dll','doorstop_config.ini')) { $dist[$file]=Join-Path $gameRoot $file }
    Get-ChildItem (Join-Path $gameRoot 'BepInEx/core') -File | Sort-Object Name | ForEach-Object { $dist["BepInEx/core/$($_.Name)"]=$_.FullName }
    Get-ChildItem (Join-Path $packaging 'licenses') -File | Sort-Object Name | ForEach-Object { $dist["licenses/$($_.Name)"]=$_.FullName }
    $source = [ordered]@{'INSTALL.txt'=$instructions; 'ModSource/package-independent.ps1'=(Join-Path $PSScriptRoot 'package-independent.ps1')}
    Get-ChildItem (Join-Path $packaging 'licenses') -File | Sort-Object Name | ForEach-Object { $source["ModSource/Packaging/licenses/$($_.Name)"]=$_.FullName }
    Get-ChildItem $root -Recurse -File | Where-Object {
        $relative=$_.FullName.Substring($root.Length+1)
        $relative -notmatch '(^|\\)(bin|obj|evidence|release)\\' -and
        $_.Extension -in '.cs','.csproj','.ps1','.py','.md','.blend','.png','.meshbin' -and
        $_.Name -notin 'HANDOFF.md','package.ps1'
    } | Sort-Object FullName | ForEach-Object { $source["ModSource/$name/"+$_.FullName.Substring($root.Length+1).Replace('\','/')]=$_.FullName }
    $prefix="$name-$($versions[$name])-NO0.34.1"
    Write-IndependentZip (Join-Path $release "$prefix-Mod.zip") $modFiles
    Write-IndependentZip (Join-Path $release "$prefix-Dist.zip") $dist
    Write-IndependentZip (Join-Path $release "$prefix-Source.zip") $source
    $hashes=Get-ChildItem $release -Filter '*.zip' -File | Sort-Object Name | ForEach-Object { '{0}  {1}' -f (Get-FileHash $_.FullName).Hash.ToLowerInvariant(),$_.Name }
    [IO.File]::WriteAllLines((Join-Path $release 'SHA256SUMS.txt'),[string[]]$hashes,[Text.UTF8Encoding]::new($false))
}
