using System;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using RogueCraft.Game;
using RogueCraft.UI;
using UnityEngine;
using Player = RogueCraft.Game.Controllers.Player;

namespace RoguecraftTrainer
{
    [BepInPlugin(PluginId, "Roguecraft Trainer", "1.0.0")]
    public sealed class TrainerPlugin : BaseUnityPlugin
    {
        public const string PluginId = "local.roguecraft.trainer";
        public static TrainerPlugin Instance { get; private set; }
        public ConfigEntry<bool> Invincibility { get; private set; }
        public ConfigEntry<bool> AlwaysHit { get; private set; }
        public ConfigEntry<bool> EnemiesAlwaysMiss { get; private set; }
        public ConfigEntry<bool> HealRequest { get; private set; }
        private ConfigEntry<KeyboardShortcut> invincibilityKey, healKey, alwaysHitKey, missKey;
        private Harmony harmony;
        private bool ready;
        private static readonly FieldInfo HudInstance = AccessTools.Field(typeof(HudUi), "_instance");

        public static bool IsInvincible => Instance != null && Instance.ready && Instance.Invincibility.Value;
        public static bool HitsGuaranteed => Instance != null && Instance.ready && Instance.AlwaysHit.Value;
        public static bool MissesGuaranteed => Instance != null && Instance.ready && Instance.EnemiesAlwaysMiss.Value;

        private void Awake()
        {
            Instance = this;
            Invincibility = Config.Bind("1. Cheats", "Invincibility", false, "Prevent player health loss, including traps, explosions and poison. F8 toggles.");
            AlwaysHit = Config.Bind("1. Cheats", "Always hit", false, "Guarantee valid player attack rolls, including ranged attacks and bosses. Does not aim or extend range. F10 toggles.");
            EnemiesAlwaysMiss = Config.Bind("1. Cheats", "Enemies always miss", false, "Make enemy attacks against the player miss, including bosses. Environmental hazards still hurt unless Invincibility is on. F11 toggles.");
            HealRequest = Config.Bind("2. Actions", "Heal to full now", false, "Set true to heal the living player to their current maximum HP. Resets after use. F9 also heals.");
            invincibilityKey = Config.Bind("3. Hotkeys", "Invincibility key", new KeyboardShortcut(KeyCode.F8));
            healKey = Config.Bind("3. Hotkeys", "Heal key", new KeyboardShortcut(KeyCode.F9));
            alwaysHitKey = Config.Bind("3. Hotkeys", "Always hit key", new KeyboardShortcut(KeyCode.F10));
            missKey = Config.Bind("3. Hotkeys", "Enemies miss key", new KeyboardShortcut(KeyCode.F11));
            // A saved action must never execute on the next launch.
            HealRequest.Value = false;
            try
            {
                harmony = new Harmony(PluginId);
                harmony.PatchAll(typeof(TrainerPlugin).Assembly);
                ready = true;
                Logger.LogInfo($"Trainer ready: {harmony.GetPatchedMethods().CountMethods()} patches. F8 invincibility; F9 heal; F10 always hit; F11 enemies miss.");
            }
            catch (Exception error)
            {
                harmony?.UnpatchSelf();
                Logger.LogError("Trainer disabled because patch installation failed: " + error);
                enabled = false;
            }
        }

        private void Update()
        {
            if (!ready) return;
            if (invincibilityKey.Value.IsDown()) Toggle(Invincibility, "Invincibility");
            if (alwaysHitKey.Value.IsDown()) Toggle(AlwaysHit, "Always hit");
            if (missKey.Value.IsDown()) Toggle(EnemiesAlwaysMiss, "Enemies always miss");
            bool requested = HealRequest.Value;
            if (requested) HealRequest.Value = false;
            if (requested || healKey.Value.IsDown()) HealToFull();
        }

        private void Toggle(ConfigEntry<bool> option, string label)
        {
            option.Value = !option.Value;
            Report($"{label}: {(option.Value ? "ON" : "OFF")}");
        }

        public bool HealToFull()
        {
            Actor pawn = CurrentPawn();
            if (pawn == null || pawn.Asset == null || !pawn.IsAlive || pawn.Hp <= 0)
            {
                Report("Heal unavailable: start or resume a living character first.");
                return false;
            }
            RestoreHealth(pawn);
            // Transformations retain a separate original body. Heal it too so reverting
            // does not restore stale wounded health.
            Actor origin = Player.TransformOriginPawn;
            if (origin != null && origin != pawn && origin.Asset != null && origin.IsAlive && origin.Hp > 0)
                RestoreHealth(origin);
            Report($"Healed to full: {pawn.Hp}/{pawn.MaxHp} HP.");
            return true;
        }

        private static void RestoreHealth(Actor pawn)
        {
            pawn.Hp = pawn.MaxHp;
            if (pawn == CurrentPawn() && HudInstance?.GetValue(null) is HudUi hud && hud != null)
                HudUi.SetHealth(pawn.Hp);
        }

        public static Actor CurrentPawn() => Player.HasInstance ? Player.PlayerPawn : null;
        public static bool IsLivingPlayer(Actor actor) => actor != null && actor == CurrentPawn() && actor.Asset != null && actor.IsAlive && actor.Hp > 0;

        internal void Report(string message)
        {
            Logger.LogMessage(message);
            if (CurrentPawn() != null && HudInstance?.GetValue(null) is HudUi hud && hud != null)
                HudUi.LogEvent("[Trainer] " + message);
        }

        private void OnDestroy()
        {
            ready = false;
            harmony?.UnpatchSelf();
            if (Instance == this) Instance = null;
        }
    }

    internal static class PatchCount
    {
        internal static int CountMethods(this System.Collections.Generic.IEnumerable<MethodBase> methods)
        {
            int count = 0;
            foreach (MethodBase method in methods) count++;
            return count;
        }
    }

    [HarmonyPatch(typeof(GameConfig), nameof(GameConfig.GodMode), MethodType.Getter)]
    internal static class GodModePatch
    {
        private static void Postfix(ref bool __result)
        {
            if (TrainerPlugin.IsInvincible) __result = true;
        }
    }

    [HarmonyPatch(typeof(Actor), nameof(Actor.Hp), MethodType.Setter)]
    internal static class HealthPatch
    {
        private static bool Prefix(Actor __instance, int value)
        {
            // Skipping the setter preserves exact HP even if a maximum changes.
            // Healing, spawning, NPC damage and normal play remain untouched.
            return !(TrainerPlugin.IsInvincible && TrainerPlugin.IsLivingPlayer(__instance) && value < __instance.Hp);
        }
    }

    [HarmonyPatch(typeof(Actor), nameof(Actor.Die))]
    internal static class DeathPatch
    {
        private static bool Prefix(Actor __instance) => !(TrainerPlugin.IsInvincible && TrainerPlugin.IsLivingPlayer(__instance));
    }

    [HarmonyPatch(typeof(Player), nameof(Player.ForceKill))]
    internal static class ForceKillPatch
    {
        private static bool Prefix() => !(TrainerPlugin.IsInvincible && TrainerPlugin.IsLivingPlayer(TrainerPlugin.CurrentPawn()));
    }

    [HarmonyPatch(typeof(Player), nameof(Player.TryAttack))]
    internal static class AttackRollPatch
    {
        private static bool Prefix(ref bool __result)
        {
            if (!TrainerPlugin.HitsGuaranteed) return true;
            __result = true;
            return false;
        }
    }

    [HarmonyPatch(typeof(Player), nameof(Player.TryDefend))]
    internal static class DefendRollPatch
    {
        private static bool Prefix(ref bool __result)
        {
            if (!TrainerPlugin.MissesGuaranteed) return true;
            __result = true; // true means the player successfully avoids the attack.
            return false;
        }
    }

    [HarmonyPatch(typeof(CombatSystem), nameof(CombatSystem.Attack), new Type[] { typeof(IActor), typeof(IActor), typeof(Vector2Int), typeof(bool), typeof(float), typeof(bool?) })]
    internal static class CommittedAttackPatch
    {
        private static void Prefix(IActor attacker, ref bool? preResolvedPlayerHit)
        {
            if (TrainerPlugin.HitsGuaranteed && Player.HasInstance && attacker != null && attacker.IsPlayerControlled)
                preResolvedPlayerHit = true;
        }
    }

    [HarmonyPatch(typeof(CombatSystem), nameof(CombatSystem.Attack), new Type[] { typeof(Boss), typeof(IActor) })]
    internal static class BossMissPatch
    {
        private static bool Prefix(IActor defender)
        {
            if (!TrainerPlugin.MissesGuaranteed || !Player.HasInstance || defender == null || !defender.IsPlayerControlled)
                return true;
            // Bosses do not call TryDefend. Their attack animation is initiated
            // by BossController before this method; skip only the hit resolution.
            TrainerPlugin.Instance.Report("Boss attack missed.");
            return false;
        }
    }
}
