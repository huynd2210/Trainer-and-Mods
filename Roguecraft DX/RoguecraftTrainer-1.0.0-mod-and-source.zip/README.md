# Roguecraft DX Trainer 1.0.0

Includes the trainer mod and its C# source. Requires Roguecraft DX (Unity Mono x64) and BepInEx 5 installed separately. Tested with Unity 6000.5.6f1 and BepInEx 5.4.23.5. BepInEx, Harmony, UnityExplorer, Configuration Manager, and game assemblies are not bundled.

## Install

1. Close the game.
2. Copy `Mod/RoguecraftTrainer.dll` into `BepInEx/plugins/RoguecraftTrainer/` inside your game directory. Create the folder if necessary. Install only one copy of the DLL.
3. Launch the game.

For this game's tested BepInEx setup, keep the following entry point in `BepInEx/config/BepInEx.cfg`:

```ini
[Preloader.Entrypoint]
Assembly = UnityEngine.CoreModule.dll
Type = MonoBehaviour
Method = .cctor
```

The default Application entry point crashed in testing; MonoBehaviour resolved it.

## Controls

| Key | Action |
| --- | --- |
| F8 | Toggle invincibility |
| F9 | Heal to full |
| F10 | Toggle always hit |
| F11 | Toggle enemies always miss |

Cheats default to off. Toggles persist across launches. Settings and hotkeys are saved in `BepInEx/config/local.roguecraft.trainer.cfg`.

If Configuration Manager is installed separately, press F1 and expand **Roguecraft Trainer** to change settings or activate **Heal to full now**. Configuration Manager is optional; hotkeys work without it.

- Invincibility prevents player HP loss from attacks, traps, explosions and poison, and prevents direct death of a living player.
- Heal restores the living player's current maximum HP, including upgrades and a stored original body during transformation. It consumes no item or turn. It does not revive or cure poison.
- Always hit guarantees valid attack rolls for melee, ranged and boss targets. It does not aim, increase range or shoot through walls.
- Enemies always miss prevents enemy attacks against the player, including boss attacks. Traps still hurt unless invincibility is enabled.

## Build source

Install a .NET SDK and point the build at your own game directory with BepInEx 5 installed:

```powershell
dotnet build ./Source/RoguecraftTrainer.csproj -c Release -p:GameDir="C:\Path\To\Roguecraft.DX\game"
```

The resulting DLL is `Source/bin/Release/netstandard2.1/RoguecraftTrainer.dll`. References resolve from your game installation and are not copied to the build output.

## Validation

Compiled with zero warnings and errors. Passed 228 headless runtime assertions against the patched game methods. The player confirmed all requested features worked during live gameplay. Compatibility with other game versions has not been tested.

## Remove or troubleshoot

Close the game and remove `BepInEx/plugins/RoguecraftTrainer/RoguecraftTrainer.dll` to uninstall. The optional trainer config can also be removed. Original game files are not modified.

If something fails, check `BepInEx/LogOutput.log` for **Roguecraft Trainer** and confirm only one trainer DLL is installed.
