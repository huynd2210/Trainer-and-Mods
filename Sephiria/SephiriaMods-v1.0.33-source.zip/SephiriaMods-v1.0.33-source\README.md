# Sephiria v1.0.33 mod source

Contains the editable source, project files, install/uninstall scripts, and configuration for SephiriaTrainer, SephiriaStatBuff, and SephiriaExpandedInventory. Generated `bin` and `obj` files and original game binaries are excluded.

Extract these three mod folders directly into the Sephiria v1.0.33 game folder, beside `Sephiria_Data`. Install the mods in this order: Trainer, StatBuff, ExpandedInventory. From PowerShell:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\SephiriaTrainer\install.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\SephiriaStatBuff\install.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\SephiriaExpandedInventory\install.ps1
```

Building requires the .NET 8 SDK and access to the game's managed assemblies. Uninstall in reverse order. The trainer's standalone uninstaller restores its assembly backup, so always remove the other mods first.
