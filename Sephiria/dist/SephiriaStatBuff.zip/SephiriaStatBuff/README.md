# Sephiria Stat Buff (game v1.0.33)

Adds configurable bonuses to the local player's stats. On by default; **F8** toggles it. Edit `SephiriaStatBuff.cfg` in the game folder and press **F9** to reload without restarting (reload also applies the file's `Enabled` line).

Values add to the game's own stats. `AllDamageBonus`, `AttackSpeed` and `DamageReduction` are percentage points; `HPRegen`, `MPRegen`, `Luck` and the rest use the game's stat units. `0` leaves a stat alone. Turning the buff off removes only its own contributions. Applies to solo play or the local host, not a remote server's player.

## Install

Needs the .NET 8 runtime. Close the game, extract this zip into the Sephiria game folder (you get `SephiriaStatBuff\` beside `Sephiria_Data\`), then run from the game folder:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\SephiriaStatBuff\install.ps1
```

Extracted somewhere else? Add `-GameDirectory 'C:\path\to\Sephiria'`. The first install copies a default `SephiriaStatBuff.cfg` into the game folder; an existing one is kept.

## Remove

Close the game and run `.\SephiriaStatBuff\uninstall.ps1`. It removes only its own hook and leaves other Sephiria mods and the config file in place. If you also use the Sephiria Trainer, uninstall this mod before the trainer.

Built for Sephiria v1.0.33; other versions may fail to patch.
