# Sephiria Trainer (game v1.0.33)

With a save loaded, press **F6** to add 1,000 saphires to the active profile or **F7** to add 10,000 gold to the current run. Each press adds the amount again. Saphires are saved immediately; gold follows the game's normal money handling.

## Install

Needs the .NET 8 runtime. Close the game, extract this zip into the Sephiria game folder (you get `SephiriaTrainer\` beside `Sephiria_Data\`), then run from the game folder:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\SephiriaTrainer\install.ps1
```

Extracted somewhere else? Add `-GameDirectory 'C:\path\to\Sephiria'`.

The installer backs up `Sephiria_Data\Managed\Assembly-CSharp.dll` as `Assembly-CSharp.dll.trainer-original`, copies `SephiriaTrainer.dll` next to it, and adds one call to the player's update loop. It refuses to run while that backup exists from an earlier install; uninstall first.

## Remove

Close the game and run `.\SephiriaTrainer\uninstall.ps1`. It restores the backed-up assembly, so it also drops the hooks of any Sephiria mod installed *after* the trainer (StatBuff, ExpandedInventory). Uninstall those first, or run their `install.ps1` again afterwards.

Built for Sephiria v1.0.33; other versions may fail to patch.
