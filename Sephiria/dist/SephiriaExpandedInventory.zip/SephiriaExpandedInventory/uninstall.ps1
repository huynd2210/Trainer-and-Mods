param([string]$GameDirectory = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Stop'
$mod = Split-Path -Leaf $PSScriptRoot
$game = [System.IO.Path]::GetFullPath($GameDirectory)
$assembly = Join-Path $game 'Sephiria_Data\Managed\Assembly-CSharp.dll'
if (!(Test-Path -LiteralPath $assembly -PathType Leaf)) {
    throw "Sephiria not found at $game. Pass -GameDirectory 'C:\path\to\Sephiria'."
}
if (Get-Process Sephiria -ErrorAction SilentlyContinue) { throw "Close Sephiria before removing $mod." }
& dotnet (Join-Path $PSScriptRoot 'Patcher\bin\Release\net8.0\Patcher.dll') uninstall $game
if ($LASTEXITCODE -ne 0) { throw "$mod removal failed." }
