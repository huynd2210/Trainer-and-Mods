# Sephiria Expanded Inventory (game v1.0.33)

Adds four rows of six slots (24 slots) to each player inventory. The inventory panel keeps its size; its contents scroll with the mouse wheel or controller selection. Set `ExtraRows` (1 to 16) in `SephiriaExpandedInventory.cfg` in the game folder before starting the game to change the amount.

Extra slots are added when a player avatar starts on the server, so in multiplayer the host needs the mod.

## Install

Needs the .NET 8 runtime. Close the game, extract this zip into the Sephiria game folder (you get `SephiriaExpandedInventory\` beside `Sephiria_Data\`), then run from the game folder:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\SephiriaExpandedInventory\install.ps1
```

Extracted somewhere else? Add `-GameDirectory 'C:\path\to\Sephiria'`. The first install copies a default `SephiriaExpandedInventory.cfg` into the game folder; an existing one is kept.

## Remove

**Empty the extra rows first** (or finish the run): items left in them may become unreachable. Then close the game and run `.\SephiriaExpandedInventory\uninstall.ps1`. It removes only its own hooks and keeps the previous assembly as `Assembly-CSharp.dll.expandedinventory-last`. If you also use the Sephiria Trainer, uninstall this mod before the trainer.

Built for Sephiria v1.0.33. The scrolling layout was checked structurally; its in-game look has not had a hands-on test.
