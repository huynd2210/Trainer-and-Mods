param([string]$GameDirectory = (Split-Path -Parent $PSScriptRoot))
$ErrorActionPreference = 'Stop'
$mod = Split-Path -Leaf $PSScriptRoot
$game = [System.IO.Path]::GetFullPath($GameDirectory)
$assembly = Join-Path $game 'Sephiria_Data\Managed\Assembly-CSharp.dll'
if (!(Test-Path -LiteralPath $assembly -PathType Leaf)) {
    throw "Sephiria not found at $game. Extract the zip into the game folder, or pass -GameDirectory 'C:\path\to\Sephiria'."
}
if (Get-Process Sephiria -ErrorAction SilentlyContinue) { throw "Close Sephiria before installing $mod." }
& dotnet (Join-Path $PSScriptRoot 'Patcher\bin\Release\net8.0\Patcher.dll') install $game
if ($LASTEXITCODE -ne 0) { throw "$mod installation failed." }
foreach ($config in Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.cfg' -File) {
    $target = Join-Path $game $config.Name
    if (!(Test-Path -LiteralPath $target)) { Copy-Item -LiteralPath $config.FullName -Destination $target }
}
