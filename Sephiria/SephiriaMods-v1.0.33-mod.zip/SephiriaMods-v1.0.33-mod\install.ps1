param([string]$GameDirectory = $PSScriptRoot)
$ErrorActionPreference = 'Stop'
$game = [System.IO.Path]::GetFullPath($GameDirectory)
$assembly = Join-Path $game 'Sephiria_Data\Managed\Assembly-CSharp.dll'
if (!(Test-Path -LiteralPath $assembly -PathType Leaf)) { throw "Sephiria game assembly not found: $assembly" }
if (Get-Process Sephiria -ErrorAction SilentlyContinue) { throw 'Close Sephiria before installing mods.' }

$mods = @('SephiriaTrainer', 'SephiriaStatBuff', 'SephiriaExpandedInventory')
foreach ($mod in $mods) {
    $patcher = Join-Path $PSScriptRoot "$mod\Patcher\bin\Release\net8.0\Patcher.dll"
    if (!(Test-Path -LiteralPath $patcher -PathType Leaf)) { throw "Missing patcher: $patcher" }
    & dotnet $patcher install $game
    if ($LASTEXITCODE -ne 0) { throw "$mod installation failed." }
}

$inventoryConfig = Join-Path $game 'SephiriaExpandedInventory.cfg'
if (!(Test-Path -LiteralPath $inventoryConfig)) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'SephiriaExpandedInventory\SephiriaExpandedInventory.cfg') -Destination $inventoryConfig
}
Write-Host 'All three mods installed.'
