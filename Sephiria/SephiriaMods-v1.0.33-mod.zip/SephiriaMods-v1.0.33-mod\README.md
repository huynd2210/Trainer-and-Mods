# Sephiria v1.0.33 mod bundle

Includes three compiled mods: SephiriaTrainer, SephiriaStatBuff, and SephiriaExpandedInventory. This package contains no original game files. It patches the target game's `Assembly-CSharp.dll` and places the mod DLLs in `Sephiria_Data/Managed`.

## Install

Requires Windows PowerShell and the .NET 8 runtime. Close the game. Extract this archive directly into the Sephiria v1.0.33 game folder, then run:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install.ps1
```

Alternatively, extract anywhere and pass `-GameDirectory 'C:\path\to\Sephiria'`.

The trainer adds currency with F6/F7. The stat buff uses F8/F9 and `SephiriaStatBuff.cfg`. Expanded inventory adds four scrollable rows by default; change `ExtraRows` (1 through 16) in `SephiriaExpandedInventory.cfg` before starting a run.

## Remove

Close the game, then run `powershell -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1`. The bundle removes hooks in reverse install order. Do not run the trainer's separate uninstaller while the other two mods are installed: it restores its original assembly backup and would also erase later patches. Remove items from expanded inventory rows before uninstalling that mod.

Keep your own backup of saves and the target game assembly before installing into a different copy. This bundle was built against Sephiria v1.0.33. The expanded inventory's visible layout has only been checked structurally; in-game appearance and scrolling still need a hands-on test.
