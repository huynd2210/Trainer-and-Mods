# Vampire Crawlers Trainer

A BepInEx trainer mod for **Vampire Crawlers** (Unity 6000.0.62f1, IL2CPP, x64).

Single-player only. Everything runs in your own game process.

## Hotkeys

| Key | Action |
|-----|--------|
| `F1` | Show / hide the trainer panel |
| `F2` | Show / hide the status strip |
| `F3` | God Mode (toggle) |
| `F4` | Revive player |
| `F5` | Run coins +1000 |
| `F6` | Level up, **with** the card-reward choice |
| `F7` | Add 100 XP |
| `F8` | Kill all living enemies |
| `F9` | Freeze all living enemies (5 stacks) |
| `F10` | Draw a card |
| `F11` | Hand size +1 (lasts the whole run) |
| `F12` | Shop coins +10000 (the between-runs wallet) |

All keys and amounts are configurable in
`BepInEx/config/nosebleed.vampirecrawlers.trainer.cfg`, written on first launch.

## The panel

`F1` opens the panel. The left column holds the actions above; the right column is a
stat editor covering every stat the game defines (Might, Luck, Greed, Health, Mana,
Deal Count, Rerolls, Banishes, and the rest — the list is generated from the game's
own stat enum, so it matches whatever the build ships).

The stat value **is** the control:

- **Wheel** over a value to step it (step size is derived from that stat's own range)
- **Drag** it horizontally to sweep
- **Click** a stat row to hold it at its current number
- **Right-click** a stat row to release the hold and give it back to the game
- **Click** any action row to fire it, same as its hotkey

A held stat is re-asserted every frame and shows `held` next to the value.

## The status strip

A compact line at the top-left shows the values you actually make decisions on —
HP, run coins, level, mana — plus a tag for every cheat currently active. Out of a run
it shows the shop wallet instead. `F2` hides it.

## Two coin pots

The game keeps two separate currencies, and the trainer exposes both:

- **Run Coins** (`F5`) — spent inside the current run.
- **Shop Coins** (`F12`) — the persistent wallet the between-runs shops spend.

Granting shop coins updates the live wallet; it is written to disk the next time the
game saves progression normally.

## Notes and limits

- **Hand size** works through the game's run-modifier channel (the same one power-ups
  use), so it survives the stat resets that happen at encounter boundaries and lasts
  for the rest of the run. It applies from the next deal, not mid-deal.
- **Level Up (F6)** calls the game's real level-up, so the card-reward screen appears.
  Each press is one level and one reward choice — resolve the choice before pressing
  again rather than stacking modals.
- **Add XP (F7)** uses the game's own XP path. That path is gated and does nothing in
  some states (outside an encounter, for one); when the trainer detects it was refused
  it writes the XP directly and then resolves any level-ups through the normal path so
  you still get the rewards.
- Most cheats need an active run. Shop coins is the exception and works from the menus.
- The overlay is drawn with IMGUI. This build ships with most of `UnityEngine.GUI`
  stripped, so the mod probes at startup for a draw call that survives and logs which
  one it picked; if none did, hotkeys still work and only the overlay is missing.

## Building from source

Requires the .NET 8 SDK.

The project references the game's own BepInEx `core` and generated `interop` assemblies
directly rather than NuGet packages, so before the first build you need a game install
that has BepInEx installed **and has been launched at least once** — that first launch is
what generates `BepInEx/interop`.

Point the build at that install with `GameDir` (the folder holding `Vampire Crawlers.exe`):

```bash
dotnet build -c Release -o build -p:GameDir="D:\Games\Vampire Crawlers"
```

`GameDir` is also read from an environment variable of the same name, and the default in
`VampireCrawlersTrainer.csproj` is the author's install path — set it either way. If the
path is wrong or the interop dump has not happened yet, the build stops with a message
saying which of the two is missing rather than a wall of missing-type errors.

Then copy `build/VampireCrawlersTrainer.dll` into `BepInEx/plugins/`.

`package.ps1` (one directory up) does the whole release: builds Release and writes the
mod-only, self-contained `-Pack`, and `-Source` zips into `dist/`. The `-Pack` zip needs a
BepInEx IL2CPP win-x64 build placed at `bepinex/BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.788.zip`;
without it the script warns and produces the other two.

## Uninstalling

Delete `BepInEx/plugins/VampireCrawlersTrainer.dll`. Nothing else is touched; the mod
writes no save data of its own.
