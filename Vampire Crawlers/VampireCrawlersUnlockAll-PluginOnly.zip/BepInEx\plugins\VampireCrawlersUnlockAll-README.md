# Vampire Crawlers — Unlock All

Unlocks every crawler, achievement, card, dungeon, town building, power-up and gem slot
on the current save profile — and can put it all back exactly as it was.

Reverting restores **the unlock state you had when you first pressed unlock**, not a fresh
save. Coins, metrics and run progress are never touched in either direction.

## Using it

**Load your profile first** — press Continue (or start a run) before unlocking. Then press
**Insert** or **`\`** for the panel.

This matters. At the title screen the game's progression object exists but is empty; it is
only filled in when a profile loads. Unlocking before that writes into something the game is
about to throw away, and pressing Continue puts your real save straight back over it. The mod
refuses to run until it has seen a profile load, and the state line says so in red, so you
cannot hit this by accident — but it is why the panel is worth opening *after* Continue, not
before.

```
UNLOCK ALL                      SaveProfile0
──────────────────────────────────────────────
●  Crawlers                            3 / 12
●  Achievements                       38 / 52
●  Card collection                    19 / 94
●  Dungeons                            4 / 9
●  Town buildings                      6 / 7
●  Power-ups                          14 / 14
●  Gem slots                           0 / 94
●  Tutorials                           2 / 2
──────────────────────────────────────────────
Original — nothing changed yet
U unlock everything    R revert    Esc close
```

The state line is the one to read before pressing anything:

| Line | Means |
| --- | --- |
| `Original — nothing changed yet` | ready; `U` will unlock and record a baseline |
| `Unlocked — baseline saved, revert available` | done; `R` puts it back |
| `Reloaded since unlocking — press U to re-apply` | the game reloaded progression and the unlocks are no longer in memory; `U` re-applies without touching the baseline |
| *anything in red* | it will not run, and the line says why — most often no profile loaded yet |

| Key | Does |
| --- | --- |
| `Insert` or `\` | show/hide the panel |
| `U` | unlock everything (asks for `U` again to confirm) |
| `R` | revert to the recorded baseline (asks for `R` again) |
| `Esc` | cancel a pending confirm, or close the panel |

Two keys open the panel because a lot of laptop keyboards have no usable `Insert` without
`Fn`, and a mod whose only way in is a key you do not have looks exactly like a mod that is
broken. Either works; both are rebindable.

If neither opens it, `BepInEx\LogOutput.log` lists every key the mod actually receives
(`Key seen: ...`) — bind `Panel` to one of those.

Both operations rewrite your save, so each wants its key twice. The confirm lapses by
itself after five seconds.

A dot (`●`) marks a category that is switched on; a hollow one (`○`) is switched off in the
config and will be left completely alone.

## How reverting works

Before it changes anything, the first unlock does three things, in this order, and stops if
any of them fails:

1. **Copies your save files** to `BepInEx\VampireCrawlersUnlockAll\save-backup-<profile>-<date>\`.
   The blunt way back — a byte copy of the save as it was.
2. **Records a baseline** — every value it is about to change, written to
   `BepInEx\VampireCrawlersUnlockAll\snapshot-<profile>.tsv`. The precise way back.
3. **Reads that file back and checks it.** If the baseline did not survive the round trip,
   nothing is unlocked at all.

An unlock that could not be undone would be worse than no unlock, so there is no path
through this mod that changes your profile without a verified record of the old values.

The baseline is written **once**, on the first unlock, and is never overwritten by a second
one. Re-recording it while everything was already unlocked would capture the unlocked state
as the thing to revert to, and quietly destroy the only copy of your real progress.

Revert restores those values and renames the baseline to `.reverted-<date>` rather than
deleting it — if a restore ever goes wrong, that file is the only record of what the values
should have been.

Progress you make *after* unlocking is kept: reverting only rewinds the entries it recorded.
Coins you earn, runs you finish and metrics are all untouched.

### If you would rather rewind everything

Close the game and copy the files from a `save-backup-…` folder back over
`%USERPROFILE%\AppData\LocalLow\Nosebleed Interactive\Vampire Crawlers\Save\`. That undoes
the unlock *and* everything played since. The panel's revert is the better first choice.

## What it unlocks

| Category | What it does |
| --- | --- |
| Crawlers | every character marked purchased, no coins spent |
| Achievements | every achievement marked unlocked |
| Card collection | every card marked discovered |
| Dungeons | every dungeon marked visited |
| Town buildings | every building marked visited |
| Power-ups | every power-up at its top level and switched on, no coins spent |
| Gem slots | every card opened to the most gem slots it allows, no coins spent |
| Tutorials | both tutorial-complete flags set |

**Achievements are the master key.** Relics and arcanas are not stored as unlocks of their
own — the game asks whether their required achievement is unlocked. Setting the achievement
flags opens all of them, which is why there is no separate relic or arcana category.

Each category can be switched off in the config file. Switching one off means it is not
captured and not changed, in either direction.

### What it deliberately leaves alone

Gem frequencies, sealed gems and gem rarity costs are *preferences* — how often you want to
see a gem, which ones you have chosen to stop seeing — not progress. There is no "unlocked"
value for them, only a preferred one, and picking one for you would be inventing choices you
never made.

**Coins are never touched**, in either direction. Nothing here spends them and nothing grants
them, so no unlock or revert can cost you a balance you earned. (If you want coins, that is
what the Vampire Crawlers Trainer's `F12` is for.)

## Things worth knowing

- **Achievements are not sent to Steam.** The flags are written straight into the save,
  going around the game's own unlock path, which also means no coin rewards are paid out and
  no unlock toasts fire. That is what keeps the operation exactly reversible. A Steam
  achievement you had already earned stays earned — this mod only touches the local save,
  and it cannot un-earn one.
- **The shop's refund buttons become generous.** Power-up levels and gem slots are written
  without spending coins, and the game's "coins spent" counter is left alone — so refunding
  them would pay out for levels you never bought. Switch those two categories off if that
  bothers you.
- **Some screens need a reload.** Anything already on screen keeps the numbers it was built
  with; back out to the menu, or restart, to see the unlocks everywhere.
- **One baseline per profile.** Snapshots are keyed to the profile id, and reverting refuses
  to cross profiles.
- **Baselines from before v1.1 are refused.** Version 1.0.0 could capture the title screen's
  blank progression and call it a baseline; restoring from one would have wiped the profile
  it was meant to protect. There is no way to tell a good v1 file from a bad one afterwards,
  so the format version was bumped and none of them are read. If you have one, delete it (or
  keep it as a record) — do not try to restore from it.
- **Where your save actually lives.** The log line `Save folder in use: ...` names the folder
  the game is really using. Worth checking if you manage saves with other tooling: a
  packaged or containerised process can see a different `AppData\LocalLow` than the game
  does, and then two copies of "the save" disagree.

## Config

`BepInEx\config\nosebleed.vampirecrawlers.unlockall.cfg`, written on first launch.

```ini
[Hotkeys]
Panel = Insert
PanelAlt = Backslash
Unlock = U
Revert = R

[Display]
OpenPanelOnStart = false

[Categories]
Characters = true
Achievements = true
Cards = true
Dungeons = true
Buildings = true
PowerUpLevels = true
CardGemSlots = true
Tutorials = true
```

The hotkeys avoid `F1`–`F12` on purpose: the Vampire Crawlers Trainer, which most people run
alongside this, binds all twelve.

## Install

Extract into your Vampire Crawlers folder — the one with `Vampire Crawlers.exe` — so the DLL
lands in `BepInEx\plugins\`. The `-Pack` zip brings BepInEx with it if you do not have it.

## If something looks wrong

`BepInEx\LogOutput.log` has a line per operation: where the save was backed up, how many
entries the baseline holds, and how many values each category changed. Every failure is
logged with the category that caused it, and a category that throws is skipped rather than
taking the rest down with it.

## Design notes

- Adding a new kind of unlock is one new `UnlockCategory` plus one line in `UnlockCatalog`.
  The snapshot, the config file, the panel and the apply/revert sequence all iterate the
  catalog, so none of them grows a branch per category.
- The categories walk the dictionaries the *game* built during load, not the content
  databases. The game's own `Init` methods have already filtered those databases down to
  what this build ships, so iterating their output cannot unlock demo-only or disabled
  content the save was never meant to contain. Card discovery is the exception — it is a
  set, with no pre-built list of everything — so that one does read the card database.
- Every read of game state happens in `Update`, never in `OnGUI`. `OnGUI` runs several times
  a frame and, during a scene change, the objects it would be reading are mid-destruction;
  touching a freed il2cpp object is a native access violation that no `try`/`catch` can
  intercept. The panel only ever renders values already copied into plain managed fields.
- The snapshot format is tab-separated plain text, not JSON, because it is the user's safety
  net: it has to be readable and fixable by hand without this mod installed.
