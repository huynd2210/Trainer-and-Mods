using StatId = Nosebleed.Pancake.GameLogic.PlayerStats.Stats;
using System;
using System.Collections.Generic;
using Nosebleed.Pancake.GameLogic;
using Nosebleed.Pancake.Models;
using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// Resolves the live game objects the cheats act on, and snapshots everything the UI
    /// displays exactly once per frame.
    ///
    /// The snapshot is a safety mechanism, not an optimisation. OnGUI runs several times
    /// per frame (once per input event, plus layout and repaint), so reading game state
    /// from inside it multiplied every il2cpp dereference by that factor -- and during a
    /// scene transition those objects are mid-destruction. Touching a freed il2cpp object
    /// is a native access violation, which no try/catch can intercept: the process simply
    /// dies. So all reads happen here, once, from Update; the UI only ever renders values
    /// that were already copied out into plain managed fields.
    /// </summary>
    internal sealed class GameContext
    {
        private GameModel _game;
        private int _lastResolveFrame = -1;

        // Enemy enumeration is the expensive and most destruction-prone lookup, so it is
        // throttled rather than run every frame.
        private const float EnemyPollInterval = 0.25f;
        private float _nextEnemyPoll;

        internal PlayerModel Player { get; private set; }
        internal PlayerStats Stats { get; private set; }
        internal bool InRun => Player != null;

        // ---- snapshot: the only things the UI is allowed to read ------------------
        internal string CoinsText { get; private set; } = "--";
        internal string LevelText { get; private set; } = "--";
        internal string XpText { get; private set; } = "--";
        internal string ManaText { get; private set; } = "--";
        internal string HpText { get; private set; } = "--";
        internal string ShopCoinsText { get; private set; } = "--";
        internal int EnemiesAlive { get; private set; }
        internal bool ProgressionReady { get; private set; }

        private readonly Dictionary<StatId, float> _statValue = new Dictionary<StatId, float>();
        private readonly Dictionary<StatId, float> _statMax = new Dictionary<StatId, float>();

        /// <summary>
        /// Persistent between-runs progression (shop wallet, unlocks). Present in menus as
        /// well as mid-run, so cheats using it must not be gated on an active run.
        /// </summary>
        internal Nosebleed.Pancake.MetaProgression.ProgressionData Progression
        {
            get
            {
                try { return Nosebleed.Pancake.GameConfig.Accessors.Globals.Progression; }
                catch (Exception) { return null; }
            }
        }

        /// <summary>Re-resolve the model graph and refill the snapshot. Call once per Update.</summary>
        internal void Refresh()
        {
            if (_lastResolveFrame == Time.frameCount) return;
            _lastResolveFrame = Time.frameCount;

            ResolveModels();
            FillSnapshot();
        }

        private void ResolveModels()
        {
            try
            {
                // Never trust the cached reference across a frame boundary: a scene change
                // destroys GameModel and leaves the managed wrapper pointing at freed memory.
                // Unity's overloaded == reports destroyed objects as null, so this re-finds.
                if (_game == null) _game = UnityEngine.Object.FindFirstObjectByType<GameModel>();

                Player = _game != null ? _game.PlayerModel : null;
                Stats = Player != null ? Player.PlayerStats : null;
            }
            catch (Exception)
            {
                _game = null;
                Player = null;
                Stats = null;
            }
        }

        private void FillSnapshot()
        {
            _statValue.Clear();
            _statMax.Clear();

            var progression = Progression;
            ProgressionReady = progression != null;
            ShopCoinsText = ProgressionReady
                ? Safely.Get(() => progression.TotalCoins.Value.ToString("N0"), "--")
                : "--";

            if (Player == null)
            {
                CoinsText = LevelText = XpText = ManaText = HpText = "--";
                EnemiesAlive = 0;
                _nextEnemyPoll = 0f;
                return;
            }

            var p = Player;
            CoinsText = Safely.Get(() => p.CurrentCoinCount.ToString("N0"), "--");
            LevelText = Safely.Get(() => p.PlayerLevel.ToString(), "--");
            XpText = Safely.Get(() => p.PlayerXp + " / " + p.MaxXp, "--");
            ManaText = Safely.Get(() => p.CachedMana.ToString(), "--");

            if (Stats != null)
            {
                foreach (var raw in Enum.GetValues(typeof(StatId)))
                {
                    var stat = (StatId)raw;
                    if (stat == StatId.None) continue;

                    SimpleStat s = Safely.Get<SimpleStat>(() => Stats.GetStat(stat), null);
                    if (s == null) continue;

                    _statValue[stat] = Safely.Get(() => s.Value, 0f);
                    _statMax[stat] = Safely.Get(() => s.GetMaxValue(), 0f);
                }
            }

            if (_statValue.TryGetValue(StatId.Health, out float hp))
            {
                float max = _statMax.TryGetValue(StatId.Health, out float m) ? m : 0f;
                HpText = Mathf.RoundToInt(hp) + "/" + Mathf.RoundToInt(max);
            }
            else HpText = "--";

            PollEnemies();
        }

        private void PollEnemies()
        {
            if (Time.unscaledTime < _nextEnemyPoll) return;
            _nextEnemyPoll = Time.unscaledTime + EnemyPollInterval;
            EnemiesAlive = LiveEnemies().Count;
        }

        /// <summary>Forget cached references (used on scene change).</summary>
        internal void Invalidate()
        {
            _game = null;
            Player = null;
            Stats = null;
            _lastResolveFrame = -1;
            _nextEnemyPoll = 0f;
        }

        /// <summary>Snapshotted stat value; false when the stat is unavailable this frame.</summary>
        internal bool TryStatValue(StatId which, out float value) => _statValue.TryGetValue(which, out value);

        /// <summary>Snapshotted stat ceiling, used to size the edit step.</summary>
        internal float StatMax(StatId which) => _statMax.TryGetValue(which, out float m) ? m : 0f;

        /// <summary>
        /// Live stat handle, for mutation only. Must be called from Update, never from
        /// OnGUI -- see the note on this class.
        /// </summary>
        internal SimpleStat Stat(StatId which)
        {
            if (Stats == null) return null;
            try { return Stats.GetStat(which); }
            catch (Exception) { return null; }
        }

        /// <summary>
        /// Every enemy currently instantiated and still alive. Enumerates the scene, so it
        /// is for actions and the throttled poll only -- never per-frame rendering.
        /// </summary>
        internal List<EnemyModel> LiveEnemies()
        {
            var result = new List<EnemyModel>();
            if (Player == null) return result;   // no run: nothing to enumerate, nothing to trip over

            try
            {
                var found = UnityEngine.Object.FindObjectsByType<EnemyModel>(FindObjectsSortMode.None);
                if (found == null) return result;
                foreach (var e in found)
                {
                    if (e == null) continue;
                    try
                    {
                        if (e.IsDead) continue;
                        if (e.Health <= 0d) continue;
                    }
                    catch (Exception) { continue; }
                    result.Add(e);
                }
            }
            catch (Exception) { /* between scenes */ }
            return result;
        }
    }
}
