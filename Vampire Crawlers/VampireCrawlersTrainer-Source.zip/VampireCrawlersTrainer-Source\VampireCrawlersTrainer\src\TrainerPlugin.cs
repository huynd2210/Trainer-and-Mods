using BepInEx;
using BepInEx.Logging;
using BepInEx.Unity.IL2CPP;
using Il2CppInterop.Runtime.Injection;
using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// BepInEx entry point. Registers the trainer MonoBehaviour with the il2cpp domain and
    /// parks it on a hidden, scene-persistent GameObject.
    /// </summary>
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class TrainerPlugin : BasePlugin
    {
        public const string PluginGuid = "nosebleed.vampirecrawlers.trainer";
        public const string PluginName = "Vampire Crawlers Trainer";
        public const string PluginVersion = "1.0.0";

        private static ManualLogSource _log;

        internal static void Info(string msg) => _log?.LogInfo(msg);
        internal static void Warn(string msg) => _log?.LogWarning(msg);

        public override void Load()
        {
            _log = Log;

            var cfg = new TrainerConfig(Config);
            CheatCatalog.Build(cfg);

            ClassInjector.RegisterTypeInIl2Cpp<TrainerBehaviour>();

            var host = new GameObject("VampireCrawlersTrainer");
            Object.DontDestroyOnLoad(host);
            host.hideFlags = HideFlags.HideAndDontSave;

            var behaviour = host.AddComponent<TrainerBehaviour>();
            behaviour.Configure(cfg);

            Info($"{PluginName} {PluginVersion} loaded -- {CheatCatalog.All.Count} cheats registered. "
                 + $"Press {Hotkeys.Name(cfg.KeyPanel)} in game for the panel.");
        }
    }
}
