using System;
using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// One trainer capability. Each implementation owns its own state, upkeep and row
    /// rendering, so the panel and hotkey handler only ever iterate the registry -- adding
    /// a cheat never means editing a dispatcher.
    /// </summary>
    internal interface ICheat
    {
        string Id { get; }
        string Label { get; }
        string Category { get; }

        /// <summary>Key that activates this cheat, or KeyCode.None.</summary>
        KeyCode Hotkey { get; }

        /// <summary>Short tag shown in the always-on strip while this cheat is doing something; null when idle.</summary>
        string Badge { get; }

        /// <summary>False when the cheat cannot act right now (e.g. no run in progress).</summary>
        bool Available(GameContext ctx);

        /// <summary>Hotkey press or row click.</summary>
        void Activate(GameContext ctx);

        /// <summary>Per-frame upkeep for cheats that must be re-asserted.</summary>
        void Tick(GameContext ctx);

        /// <summary>Render this cheat's row and consume its own pointer input.</summary>
        void Draw(Rect row, int index, Gui gui, GameContext ctx, RowInput input);
    }

    /// <summary>Shared row chrome: label on the left, cheat-specific readout on the right.</summary>
    internal abstract class CheatBase : ICheat
    {
        public string Id { get; protected set; }
        public string Label { get; protected set; }
        public string Category { get; protected set; }
        public KeyCode Hotkey { get; protected set; }

        public virtual string Badge => null;

        /// <summary>Overridable so cheats that work in menus are not gated on an active run.</summary>
        protected Func<GameContext, bool> AvailableWhen;
        public virtual bool Available(GameContext ctx)
            => AvailableWhen != null ? Safely.Get(() => AvailableWhen(ctx), false) : ctx.InRun;
        public abstract void Activate(GameContext ctx);
        public virtual void Tick(GameContext ctx) { }

        public virtual void Draw(Rect row, int index, Gui gui, GameContext ctx, RowInput input)
        {
            bool enabled = Available(ctx);
            float pad = Theme.Px(10f);
            float keyW = Theme.Px(46f);
            float gap = Theme.Px(12f);

            // The hotkey gets its own reserved column with a gap on each side; without it
            // the right-aligned value ran straight into the key ("6 aliveF8").
            var keyRect = new Rect(row.xMax - pad - keyW, row.y, keyW, row.height);
            var labelRect = new Rect(row.x + pad, row.y, row.width * 0.46f, row.height);
            float valueX = labelRect.xMax + gap;
            var valueRect = new Rect(valueX, row.y,
                                     Mathf.Max(0f, keyRect.x - gap - valueX), row.height);

            gui.Text(labelRect, Label, gui.Label, enabled ? Theme.Text : Theme.TextMuted);
            DrawValue(valueRect, gui, ctx, enabled);
            gui.Text(keyRect, Hotkeys.Name(Hotkey), gui.Small, Theme.TextMuted);
        }

        /// <summary>Right-hand readout, which for editable cheats is also the control.</summary>
        protected virtual void DrawValue(Rect r, Gui gui, GameContext ctx, bool enabled) { }
    }

    /// <summary>A cheat that is either on or off and re-asserts itself every frame.</summary>
    internal sealed class ToggleCheat : CheatBase
    {
        private readonly Action<GameContext, bool> _apply;
        private readonly string _badge;
        internal bool On { get; private set; }

        internal ToggleCheat(string id, string label, string category, KeyCode key,
                             Action<GameContext, bool> apply, string badge,
                             Func<GameContext, bool> availableWhen = null)
        {
            Id = id; Label = label; Category = category; Hotkey = key;
            _apply = apply; _badge = badge; AvailableWhen = availableWhen;
        }

        public override string Badge => On ? _badge : null;

        public override void Activate(GameContext ctx)
        {
            On = !On;
            Safely.Run(() => _apply(ctx, On));
        }

        private float _nextReassert;

        public override void Tick(GameContext ctx)
        {
            // Re-assert while on: the game resets these on encounter/turn boundaries.
            // Twice a second is plenty and keeps the per-frame cost at zero.
            if (!On || !ctx.InRun) return;
            if (Time.unscaledTime < _nextReassert) return;
            _nextReassert = Time.unscaledTime + 0.5f;
            Safely.Run(() => _apply(ctx, true));
        }

        protected override void DrawValue(Rect r, Gui gui, GameContext ctx, bool enabled)
        {
            gui.Text(r, On ? "ON" : "off", gui.LabelRight,
                     On ? Theme.Accent : Theme.TextMuted);
        }
    }

    /// <summary>A one-shot cheat: fires once per activation, no persistent state.</summary>
    internal sealed class ActionCheat : CheatBase
    {
        private readonly Action<GameContext> _run;
        private readonly Func<GameContext, string> _readout;
        private float _flashUntil;

        internal ActionCheat(string id, string label, string category, KeyCode key,
                             Action<GameContext> run, Func<GameContext, string> readout = null,
                             Func<GameContext, bool> availableWhen = null)
        {
            Id = id; Label = label; Category = category; Hotkey = key;
            _run = run; _readout = readout; AvailableWhen = availableWhen;
        }

        public override void Activate(GameContext ctx)
        {
            if (!Available(ctx)) return;
            Safely.Run(() => _run(ctx));
            _flashUntil = Time.unscaledTime + 0.45f;
        }

        protected override void DrawValue(Rect r, Gui gui, GameContext ctx, bool enabled)
        {
            bool flashing = Time.unscaledTime < _flashUntil;
            string text = flashing ? "done" : (_readout != null ? Safely.Get(() => _readout(ctx), "--") : "apply");
            gui.Text(r, text, gui.LabelRight, flashing ? Theme.Good : Theme.TextMuted);
        }
    }

    /// <summary>Swallow il2cpp interop faults so one bad call can never kill the overlay.</summary>
    internal static class Safely
    {
        internal static void Run(Action a)
        {
            try { a(); }
            catch (Exception ex) { TrainerPlugin.Warn("cheat action failed: " + ex.Message); }
        }

        internal static T Get<T>(Func<T> f, T fallback)
        {
            try { return f(); }
            catch (Exception) { return fallback; }
        }
    }
}
