# Packages the Vampire Crawlers trainer for distribution.
#
# Produces three zips -- the two required by the standing BepInEx packaging convention,
# plus the buildable source:
#   VampireCrawlersTrainer.zip         mod only  -> for people who already have BepInEx
#   VampireCrawlersTrainer-Pack.zip    BepInEx + the mod, self-contained
#   VampireCrawlersTrainer-Source.zip  the C# project, buildable against any install
#
# The -Pack exists because getting BepInEx installed (right build, right folder, right
# doorstop) is the single most common failure point; it ships a known-good build so the
# mod-only zip stays self-serve for anyone who already has one installed.

$ErrorActionPreference = 'Stop'

$Root     = Split-Path -Parent $MyInvocation.MyCommand.Path
$Project  = Join-Path $Root 'VampireCrawlersTrainer'
# The install to build against -- assumed to sit next to this folder. Edit if yours differs.
$GameDir  = Join-Path (Split-Path -Parent $Root) 'game'
$Out      = Join-Path $Root 'dist'
$Staging  = Join-Path $Root '_staging'
$ModName  = 'VampireCrawlersTrainer'

# BepInEx build bundled into the -Pack zip. Must match what the mod was built against.
$BepInExZip = Join-Path $Root 'bepinex\BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.788.zip'

Write-Host "==> Building $ModName (Release)"
Push-Location $Project
dotnet build -c Release -o build --nologo -p:GameDir="$GameDir" | Out-Null
Pop-Location

$Dll = Join-Path $Project 'build\VampireCrawlersTrainer.dll'
if (-not (Test-Path $Dll)) { throw "build produced no DLL at $Dll" }

$Readme = Join-Path $Project 'README.md'

# Clean staging and output
foreach ($d in @($Staging, $Out)) {
  if (Test-Path $d) { Remove-Item $d -Recurse -Force }
  New-Item -ItemType Directory -Path $d -Force | Out-Null
}

# ---------------------------------------------------------------- mod-only zip
Write-Host "==> Staging mod-only zip"
$ModStage = Join-Path $Staging 'mod'
$ModPlugins = Join-Path $ModStage 'BepInEx\plugins'
New-Item -ItemType Directory -Path $ModPlugins -Force | Out-Null
Copy-Item $Dll    (Join-Path $ModPlugins "$ModName.dll") -Force
Copy-Item $Readme (Join-Path $ModPlugins "$ModName-README.md") -Force

$ModZip = Join-Path $Out "$ModName.zip"
Compress-Archive -Path (Join-Path $ModStage '*') -DestinationPath $ModZip -Force
Write-Host "    $ModZip"

# ------------------------------------------------------------------- pack zip
if (Test-Path $BepInExZip) {
  Write-Host "==> Staging self-contained pack (BepInEx + mod)"
  $PackStage = Join-Path $Staging 'pack'
  New-Item -ItemType Directory -Path $PackStage -Force | Out-Null

  Expand-Archive -Path $BepInExZip -DestinationPath $PackStage -Force

  $PackPlugins = Join-Path $PackStage 'BepInEx\plugins'
  New-Item -ItemType Directory -Path $PackPlugins -Force | Out-Null
  Copy-Item $Dll    (Join-Path $PackPlugins "$ModName.dll") -Force
  Copy-Item $Readme (Join-Path $PackPlugins "$ModName-README.md") -Force

  # Each pack ships an INSTALL.txt covering only the mods it contains.
  $install = @"
Vampire Crawlers Trainer -- self-contained pack
================================================

Contains BepInEx 6 (IL2CPP, win-x64, build be.788) and the Vampire Crawlers Trainer.
Nothing else needs installing.

INSTALL
  1. Extract everything in this zip into your Vampire Crawlers game folder --
     the folder that contains "Vampire Crawlers.exe".
     You should end up with "winhttp.dll" and a "BepInEx" folder next to the exe.
  2. Run the game once and wait. The first launch is slow (a minute or more): BepInEx
     has to dump the game's assemblies before any mod can load. The window may look
     frozen -- let it finish.
  3. In game, press F1 for the trainer panel.

HOTKEYS
  F1  panel            F5  run coins +1000     F9   freeze enemies
  F2  status strip     F6  level up (+reward)  F10  draw a card
  F3  god mode         F7  add 100 XP          F11  hand size +1 (whole run)
  F4  revive           F8  kill all enemies    F12  shop coins +10000

  Keys and amounts: BepInEx\config\nosebleed.vampirecrawlers.trainer.cfg (written on
  first launch).

ADDING MORE MODS
  Drop any other mod's BepInEx\plugins\*.dll into this install's BepInEx\plugins.

UNINSTALL
  Delete winhttp.dll, doorstop_config.ini, .doorstop_version, changelog.txt, and the
  BepInEx and dotnet folders. The game itself is untouched.

TROUBLESHOOTING
  No overlay? Open BepInEx\LogOutput.log and look for "Vampire Crawlers Trainer".
  If it is not listed, BepInEx did not load -- confirm winhttp.dll sits beside the exe.
"@
  Set-Content -Path (Join-Path $PackStage 'INSTALL.txt') -Value $install -Encoding utf8

  $PackZip = Join-Path $Out "$ModName-Pack.zip"
  Compress-Archive -Path (Join-Path $PackStage '*') -DestinationPath $PackZip -Force
  Write-Host "    $PackZip"
} else {
  Write-Warning "BepInEx zip not found at $BepInExZip -- skipping the -Pack zip."
  Write-Warning "Place the BepInEx IL2CPP win-x64 build there and re-run to produce it."
}

# ---------------------------------------------------------------- source zip
# The buildable project only: sources, csproj, packaging script, docs. No build output,
# no obj/, and not the ~34 MB bundled BepInEx zip -- package.ps1 warns and skips the
# -Pack zip when that is absent, which is the right behaviour for a source checkout.
Write-Host "==> Staging source zip"
$SrcStage = Join-Path $Staging "src\$ModName-Source"
New-Item -ItemType Directory -Path $SrcStage -Force | Out-Null

$ProjStage = Join-Path $SrcStage $ModName
New-Item -ItemType Directory -Path $ProjStage -Force | Out-Null
Copy-Item (Join-Path $Project 'src')                    $ProjStage -Recurse -Force
Copy-Item (Join-Path $Project "$ModName.csproj")        $ProjStage -Force
Copy-Item $Readme                                       $ProjStage -Force

Copy-Item (Join-Path $Root 'package.ps1')               $SrcStage -Force

# The -Pack zip's BepInEx build is not shipped in source form; leave a note where it goes.
$BepStage = Join-Path $SrcStage 'bepinex'
New-Item -ItemType Directory -Path $BepStage -Force | Out-Null
Set-Content -Path (Join-Path $BepStage 'PLACE-BEPINEX-ZIP-HERE.txt') -Encoding utf8 -Value @'
package.ps1 bundles a BepInEx build into VampireCrawlersTrainer-Pack.zip. That build is
not redistributed in this source archive.

To produce the -Pack zip yourself, download the BepInEx 6 IL2CPP win-x64 build and drop
the zip in this folder under exactly this name:

  BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.788.zip

  https://builds.bepinex.dev/projects/bepinex_be

Without it, package.ps1 still builds the mod-only and -Source zips and just warns about
this one.
'@

Set-Content -Path (Join-Path $SrcStage 'BUILDING.txt') -Encoding utf8 -Value @'
Vampire Crawlers Trainer -- source
==================================

Layout
  VampireCrawlersTrainer\src\        the mod's C# sources
  VampireCrawlersTrainer\*.csproj    the project
  VampireCrawlersTrainer\README.md   what the mod does, hotkeys, design notes
  package.ps1                        builds Release and writes the release zips
  bepinex\                           where the bundled BepInEx build goes (see note there)

Requirements
  .NET 8 SDK (the project targets net6.0; the SDK builds it).
  A Vampire Crawlers install with BepInEx 6 IL2CPP installed that has been LAUNCHED AT
  LEAST ONCE -- that first launch generates BepInEx\interop, which this project
  references directly instead of NuGet packages.

Build
  cd VampireCrawlersTrainer
  dotnet build -c Release -o build -p:GameDir="D:\Games\Vampire Crawlers"

  GameDir is the folder containing "Vampire Crawlers.exe". It is also read from an
  environment variable of the same name; the fallback baked into the csproj is the
  author's own path, so set it one way or the other. A wrong path or a missing interop
  dump fails the build with a message saying which, not a wall of type errors.

  Then copy build\VampireCrawlersTrainer.dll into <game>\BepInEx\plugins\.

Release
  powershell -ExecutionPolicy Bypass -File package.ps1

  Writes dist\VampireCrawlersTrainer.zip, -Pack.zip and -Source.zip. package.ps1 has its
  own $GameDir variable near the top, passed to the build; it assumes the game sits next
  to this folder. Edit it if your layout differs.
'@

$SrcZip = Join-Path $Out "$ModName-Source.zip"
Compress-Archive -Path (Join-Path $Staging 'src\*') -DestinationPath $SrcZip -Force
Write-Host "    $SrcZip"

Remove-Item $Staging -Recurse -Force
Write-Host ""
Write-Host "==> Done. Artifacts in $Out"
Get-ChildItem $Out | Select-Object Name, @{n='MB';e={[math]::Round($_.Length/1MB,2)}} | Format-Table -AutoSize
