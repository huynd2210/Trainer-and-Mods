using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// Single source of truth for the overlay's look. Vampire Crawlers is a dark,
    /// gold-on-near-black gothic deckbuilder, so the trainer borrows that vocabulary:
    /// near-black panels, aged-gold accents, warm parchment text. Every colour used by
    /// the overlay is named here -- no ad-hoc colours at call sites.
    /// </summary>
    internal static class Theme
    {
        // --- palette tokens ---
        internal static readonly Color Backdrop   = new Color(0.043f, 0.035f, 0.051f, 0.94f); // #0B090D
        internal static readonly Color BackdropSoft = new Color(0.043f, 0.035f, 0.051f, 0.78f);
        internal static readonly Color RowAlt     = new Color(1f, 1f, 1f, 0.035f);
        internal static readonly Color RowHover   = new Color(0.949f, 0.757f, 0.306f, 0.13f);
        internal static readonly Color Border     = new Color(0.788f, 0.635f, 0.153f, 0.85f);  // #C9A227
        internal static readonly Color BorderSoft = new Color(0.788f, 0.635f, 0.153f, 0.35f);

        internal static readonly Color Text       = new Color(0.910f, 0.886f, 0.816f, 1f);     // #E8E2D0
        internal static readonly Color TextMuted  = new Color(0.604f, 0.573f, 0.518f, 1f);     // #9A9284
        internal static readonly Color Accent     = new Color(0.949f, 0.757f, 0.306f, 1f);     // #F2C14E  titles / active
        internal static readonly Color AccentDim  = new Color(0.788f, 0.635f, 0.153f, 1f);     // #C9A227
        internal static readonly Color Danger     = new Color(0.839f, 0.322f, 0.290f, 1f);     // #D6524A
        internal static readonly Color Good       = new Color(0.514f, 0.780f, 0.518f, 1f);     // #83C784

        // --- scale ---
        /// <summary>UI scale so the overlay stays legible from 1080p to 4K.</summary>
        internal static float Scale
        {
            get
            {
                float s = Screen.height / 1080f;
                return Mathf.Clamp(s, 1.0f, 2.25f);
            }
        }

        internal static int Font(int basePx) => Mathf.RoundToInt(basePx * Scale);
        internal static float Px(float basePx) => basePx * Scale;

        private static Texture2D _solid;
        internal static Texture2D Solid
        {
            get
            {
                if (_solid == null)
                {
                    _solid = new Texture2D(1, 1, TextureFormat.RGBA32, false);
                    _solid.SetPixel(0, 0, Color.white);
                    _solid.Apply();
                    _solid.hideFlags = HideFlags.HideAndDontSave;
                }
                return _solid;
            }
        }

        /// <summary>
        /// Fill a rect with a flat colour. Routed through Painter because which IMGUI
        /// draw call survives this build's stripping is only knowable at runtime.
        /// </summary>
        internal static void Fill(Rect r, Color c) => Painter.Fill(r, c);

        /// <summary>1px (scaled) outline drawn as four fills.</summary>
        internal static void Outline(Rect r, Color c, float thickness = 1f)
        {
            float t = Mathf.Max(1f, thickness * Scale);
            Fill(new Rect(r.x, r.y, r.width, t), c);
            Fill(new Rect(r.x, r.yMax - t, r.width, t), c);
            Fill(new Rect(r.x, r.y, t, r.height), c);
            Fill(new Rect(r.xMax - t, r.y, t, r.height), c);
        }
    }
}
