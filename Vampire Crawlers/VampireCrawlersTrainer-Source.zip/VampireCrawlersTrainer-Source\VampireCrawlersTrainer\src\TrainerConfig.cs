using BepInEx.Configuration;
using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// User-editable settings, persisted to BepInEx/config/nosebleed.vampirecrawlers.trainer.cfg.
    /// </summary>
    internal sealed class TrainerConfig
    {
        internal KeyCode KeyPanel { get; private set; }
        internal KeyCode KeyStrip { get; private set; }
        internal KeyCode KeyGodMode { get; private set; }
        internal KeyCode KeyRevive { get; private set; }
        internal KeyCode KeyCoins { get; private set; }
        internal KeyCode KeyLevel { get; private set; }
        internal KeyCode KeyXp { get; private set; }
        internal KeyCode KeyKillAll { get; private set; }
        internal KeyCode KeyFreeze { get; private set; }
        internal KeyCode KeyDraw { get; private set; }
        internal KeyCode KeyHandSize { get; private set; }
        internal KeyCode KeyShopCoins { get; private set; }

        internal int CoinGrant { get; private set; }
        internal long ShopCoinGrant { get; private set; }
        internal int HandSizeGrant { get; private set; }
        internal int LevelGrant { get; private set; }
        internal int XpGrant { get; private set; }
        internal int FreezeStacks { get; private set; }
        internal bool StripVisibleByDefault { get; private set; }

        internal TrainerConfig(ConfigFile file)
        {
            KeyPanel   = file.Bind("Hotkeys", "Panel",       KeyCode.F1, "Show/hide the trainer panel.").Value;
            KeyStrip   = file.Bind("Hotkeys", "StatusStrip", KeyCode.F2, "Show/hide the always-on status strip.").Value;
            KeyGodMode = file.Bind("Hotkeys", "GodMode",     KeyCode.F3, "Toggle invulnerability.").Value;
            KeyRevive  = file.Bind("Hotkeys", "Revive",      KeyCode.F4, "Revive the player.").Value;
            KeyCoins   = file.Bind("Hotkeys", "AddCoins",    KeyCode.F5, "Grant coins.").Value;
            KeyLevel   = file.Bind("Hotkeys", "AddLevels",   KeyCode.F6, "Grant levels.").Value;
            KeyXp      = file.Bind("Hotkeys", "AddXp",       KeyCode.F7, "Grant XP.").Value;
            KeyKillAll = file.Bind("Hotkeys", "KillAll",     KeyCode.F8, "Kill every living enemy.").Value;
            KeyFreeze  = file.Bind("Hotkeys", "Freeze",      KeyCode.F9, "Freeze every living enemy.").Value;
            KeyDraw    = file.Bind("Hotkeys", "DrawCard",    KeyCode.F10, "Draw one card.").Value;
            KeyHandSize  = file.Bind("Hotkeys", "HandSize",  KeyCode.F11, "Increase hand size (deal count).").Value;
            KeyShopCoins = file.Bind("Hotkeys", "ShopCoins", KeyCode.F12, "Grant persistent shop coins.").Value;

            CoinGrant    = file.Bind("Amounts", "CoinGrant",    1000, "Run coins granted per activation.").Value;
            ShopCoinGrant = file.Bind("Amounts", "ShopCoinGrant", 10000L,
                "Persistent shop coins granted per activation (the between-runs wallet).").Value;
            HandSizeGrant = file.Bind("Amounts", "HandSizeGrant", 1,
                "Extra cards per deal added per activation.").Value;
            LevelGrant   = file.Bind("Amounts", "LevelGrant",   1,
                "Level-ups triggered per activation. Each one opens its own card-reward choice.").Value;
            XpGrant      = file.Bind("Amounts", "XpGrant",      100,  "XP granted per activation.").Value;
            FreezeStacks = file.Bind("Amounts", "FreezeStacks", 5,    "Freeze stacks applied per activation.").Value;

            StripVisibleByDefault = file.Bind("Display", "StatusStripVisible", true,
                "Show the compact status strip as soon as a run starts.").Value;
        }
    }
}
