using StatId = Nosebleed.Pancake.GameLogic.PlayerStats.Stats;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// The registry of everything the trainer can do. This is the only file that needs
    /// touching to add a capability: append one entry and it appears in the panel, gets
    /// its hotkey handled and its badge shown, with no dispatcher to update.
    /// </summary>
    internal static class CheatCatalog
    {
        private static readonly List<ICheat> _all = new List<ICheat>();
        internal static IReadOnlyList<ICheat> All => _all;

        internal static void Build(TrainerConfig cfg)
        {
            _all.Clear();

            // ---- Survival -------------------------------------------------------
            _all.Add(new ToggleCheat(
                "godmode", "God Mode", "Survival", cfg.KeyGodMode,
                (ctx, on) => ctx.Player.SetInvulnerable(on),
                badge: "GOD"));

            _all.Add(new ActionCheat(
                "revive", "Revive Player", "Survival", cfg.KeyRevive,
                ctx => ctx.Player.TryRevivePlayer()));

            // ---- Economy --------------------------------------------------------
            _all.Add(new ActionCheat(
                "coins", "Run Coins +" + cfg.CoinGrant, "Economy", cfg.KeyCoins,
                ctx => ctx.Player.AddCoins(cfg.CoinGrant, true),
                ctx => ctx.CoinsText));

            // The between-runs wallet is a separate pot and is reachable from the menus,
            // so this one must not be gated on an active run.
            _all.Add(new ActionCheat(
                "shopcoins", "Shop Coins +" + cfg.ShopCoinGrant, "Economy", cfg.KeyShopCoins,
                ctx => PlayerActions.AddShopCoins(ctx, cfg.ShopCoinGrant),
                ctx => ctx.ShopCoinsText,
                availableWhen: ctx => ctx.ProgressionReady));

            // ---- Progression ----------------------------------------------------
            _all.Add(new ActionCheat(
                "level", "Level Up (+reward)", "Progression", cfg.KeyLevel,
                ctx => PlayerActions.LevelUp(ctx, cfg.LevelGrant),
                ctx => "Lv " + ctx.LevelText));

            _all.Add(new ActionCheat(
                "xp", "Add " + cfg.XpGrant + " XP", "Progression", cfg.KeyXp,
                ctx => PlayerActions.AddXp(ctx, cfg.XpGrant),
                ctx => ctx.XpText));

            // ---- Encounter ------------------------------------------------------
            _all.Add(new ActionCheat(
                "handsize", "Hand Size +" + cfg.HandSizeGrant, "Encounter", cfg.KeyHandSize,
                ctx => PlayerActions.AddHandSize(ctx, cfg.HandSizeGrant),
                ctx => ctx.TryStatValue(StatId.DealCount, out float d) ? Mathf.RoundToInt(d).ToString() : "--"));

            _all.Add(new ActionCheat(
                "killall", "Kill All Enemies", "Encounter", cfg.KeyKillAll,
                ctx =>
                {
                    foreach (var e in ctx.LiveEnemies()) Safely.Run(() => e.Kill());
                },
                ctx => ctx.EnemiesAlive + " alive"));

            _all.Add(new ActionCheat(
                "freeze", "Freeze Enemies (" + cfg.FreezeStacks + ")", "Encounter", cfg.KeyFreeze,
                ctx =>
                {
                    foreach (var e in ctx.LiveEnemies()) Safely.Run(() => e.Freeze(cfg.FreezeStacks));
                }));

            _all.Add(new ActionCheat(
                "draw", "Draw A Card", "Encounter", cfg.KeyDraw,
                ctx => ctx.Player.Button_DrawCard()));

            // ---- Stats ----------------------------------------------------------
            // Generated straight from the game's own enum: whatever stats the build
            // defines are the stats the editor offers.
            foreach (var value in Enum.GetValues(typeof(StatId)))
            {
                var stat = (StatId)value;
                if (stat == StatId.None) continue;
                _all.Add(new StatCheat(stat));
            }
        }

        /// <summary>Categories in declaration order, without duplicates.</summary>
        internal static List<string> Categories()
        {
            var seen = new List<string>();
            foreach (var c in _all)
                if (!seen.Contains(c.Category)) seen.Add(c.Category);
            return seen;
        }
    }
}
