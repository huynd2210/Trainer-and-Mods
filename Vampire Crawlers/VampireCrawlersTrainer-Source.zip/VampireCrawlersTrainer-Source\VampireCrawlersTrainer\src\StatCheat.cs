using StatId = Nosebleed.Pancake.GameLogic.PlayerStats.Stats;
using System;
using Nosebleed.Pancake.GameLogic;
using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// One row of the stat editor, bound to a single value of the game's own <c>Stats</c>
    /// enum. Every stat the game defines gets one of these automatically, so the set of
    /// editable stats tracks the game rather than a hand-maintained list.
    ///
    /// The readout is the control: wheel over it to step, drag it horizontally to sweep,
    /// click to hold the value, right-click to let the game have it back. There is no
    /// separate "edit" field, so the displayed number is never a stale copy of the truth.
    /// </summary>
    internal sealed class StatCheat : CheatBase
    {
        private readonly StatId _stat;
        private bool _locked;
        private float _target;

        internal StatCheat(StatId stat)
        {
            _stat = stat;
            Id = "stat." + stat;
            Label = Prettify(stat.ToString());
            Category = "Stats";
            Hotkey = KeyCode.None;
        }

        public override string Badge => _locked ? Label : null;

        public override bool Available(GameContext ctx) => ctx.TryStatValue(_stat, out _);

        /// <summary>Steps requested by the pointer this frame, applied during Update.</summary>
        private float _pendingSteps;

        /// <summary>Clicking the row holds the stat at its present value (or releases it).</summary>
        public override void Activate(GameContext ctx)
        {
            var s = ctx.Stat(_stat);
            if (s == null) return;

            if (_locked) { _locked = false; return; }

            if (ctx.TryStatValue(_stat, out float live)) _target = live;
            Lock(s);
        }

        public override void Tick(GameContext ctx)
        {
            // Every mutation happens here, in Update -- never from OnGUI, which runs
            // several times per frame and can land mid scene-teardown.
            if (_pendingSteps != 0f)
            {
                Adjust(ctx, _pendingSteps);
                _pendingSteps = 0f;
            }

            if (!_locked) return;
            var s = ctx.Stat(_stat);
            if (s == null) return;
            Safely.Run(() =>
            {
                if (!Mathf.Approximately(s.Value, _target)) s.SetValue(_target, true);
            });
        }

        private void Lock(SimpleStat s)
        {
            _locked = true;
            // Lift the stat's own ceiling first, otherwise SetValue is clamped straight back down.
            Safely.Run(() => s.Uncap());
            Safely.Run(() => s.SetValue(_target, true));
        }

        /// <summary>Nudge the held value; starts holding if it wasn't already.</summary>
        private void Adjust(GameContext ctx, float deltaSteps)
        {
            var s = ctx.Stat(_stat);
            if (s == null) return;

            if (!_locked && ctx.TryStatValue(_stat, out float live)) _target = live;
            _target = Mathf.Max(0f, _target + deltaSteps * StepFor(ctx));
            Lock(s);
        }

        /// <summary>
        /// Step size derived from the stat's own declared range, so a 0..1 multiplier and a
        /// 0..500 health pool both feel right without a hand-written table per stat.
        /// </summary>
        private float StepFor(GameContext ctx)
        {
            // Every player stat floors at zero, so the declared ceiling is the span.
            float span = ctx.StatMax(_stat);
            if (span > 0f && span < 1e6f)
                return Mathf.Max(RoundNice(span / 100f), 0.01f);

            ctx.TryStatValue(_stat, out float v);
            return Mathf.Max(1f, RoundNice(Mathf.Abs(v) * 0.05f));
        }

        /// <summary>Snap a step to 1/2/5 x 10^n so increments land on readable numbers.</summary>
        private static float RoundNice(float x)
        {
            if (x <= 0f) return 0.01f;
            float mag = Mathf.Pow(10f, Mathf.Floor(Mathf.Log10(x)));
            float n = x / mag;
            if (n < 1.5f) n = 1f;
            else if (n < 3.5f) n = 2f;
            else if (n < 7.5f) n = 5f;
            else n = 10f;
            return n * mag;
        }

        public override void Draw(Rect row, int index, Gui gui, GameContext ctx, RowInput input)
        {
            bool present = ctx.TryStatValue(_stat, out float liveValue);

            float pad = Theme.Px(10f);
            var labelRect = new Rect(row.x + pad, row.y, row.width * 0.46f, row.height);
            var valueRect = new Rect(row.x + row.width * 0.46f, row.y, row.width * 0.54f - pad, row.height);

            gui.Text(labelRect, Label, gui.Label, present ? Theme.Text : Theme.TextMuted);

            if (!present)
            {
                gui.Text(valueRect, "--", gui.LabelRight, Theme.TextMuted);
                return;
            }

            // Gestures land on the value itself, but only record intent; Tick applies it.
            if (input.Wheel != 0f) _pendingSteps += input.Wheel;
            if (input.Dragging && Mathf.Abs(input.DragDelta) > 0f)
                _pendingSteps += input.DragDelta / (12f * Theme.Scale);
            if (input.RightClicked) _locked = false;

            float shown = _locked ? _target : liveValue;
            string text = StepFor(ctx) >= 1f
                ? Mathf.RoundToInt(shown).ToString()
                : shown.ToString("0.00");

            if (_locked) text += "  held";
            gui.Text(valueRect, text, gui.LabelRight, _locked ? Theme.Accent : Theme.Text);
        }

        /// <summary>"CardSkips" -> "Card Skips"</summary>
        private static string Prettify(string raw)
        {
            var sb = new System.Text.StringBuilder(raw.Length + 4);
            for (int i = 0; i < raw.Length; i++)
            {
                char c = raw[i];
                if (i > 0 && char.IsUpper(c) && !char.IsUpper(raw[i - 1])) sb.Append(' ');
                sb.Append(c);
            }
            return sb.ToString();
        }
    }
}
