using StatId = Nosebleed.Pancake.GameLogic.PlayerStats.Stats;
using System;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// The multi-step operations behind the cheats, kept out of the catalog so the registry
    /// stays a plain list of declarations.
    /// </summary>
    internal static class PlayerActions
    {
        /// <summary>
        /// Level up through the game's own path so the card-reward choice appears.
        ///
        /// AddLevels_DEBUG only advances the counter -- it skips the reward flow entirely,
        /// which is why a debug level-up looked purely cosmetic. LevelUp() is the method the
        /// real XP threshold calls, and it opens the choose-a-card modal.
        /// </summary>
        internal static void LevelUp(GameContext ctx, int times)
        {
            var p = ctx.Player;
            if (p == null) return;

            for (int i = 0; i < times; i++)
            {
                int before = Safely.Get(() => p.PlayerLevel, 0);
                Safely.Run(() => p.LevelUp());
                // Stop early if the game declined, rather than stacking reward modals.
                if (Safely.Get(() => p.PlayerLevel, before) == before) break;
            }
        }

        /// <summary>
        /// Grant XP, falling back to a direct write when the game refuses.
        ///
        /// PlayerModel.AddXp is gated (it no-ops while XP gain is disabled, e.g. outside an
        /// encounter), so the result is verified rather than assumed; if nothing moved, the
        /// XP field is set directly and any resulting level-ups are resolved through
        /// LevelUp() so the rewards still appear.
        /// </summary>
        internal static void AddXp(GameContext ctx, int amount)
        {
            var p = ctx.Player;
            if (p == null) return;

            int xpBefore = Safely.Get(() => p.PlayerXp, 0);
            int lvlBefore = Safely.Get(() => p.PlayerLevel, 0);

            Safely.Run(() => p.AddXp(amount, true));

            int xpAfter = Safely.Get(() => p.PlayerXp, xpBefore);
            int lvlAfter = Safely.Get(() => p.PlayerLevel, lvlBefore);
            if (xpAfter != xpBefore || lvlAfter != lvlBefore) return;  // the game took it

            TrainerPlugin.Info("AddXp was refused by the game; writing XP directly.");
            // _playerXp is an IntVariable, not a bare int; SetValue notifies the XP bar.
            Safely.Run(() => p._playerXp.SetValue(xpBefore + amount, true));
            ResolveLevelUps(ctx);
        }

        /// <summary>Spend banked XP on level-ups for as long as the threshold is met.</summary>
        private static void ResolveLevelUps(GameContext ctx)
        {
            var p = ctx.Player;
            if (p == null) return;

            for (int guard = 0; guard < 20; guard++)
            {
                int xp = Safely.Get(() => p.PlayerXp, 0);
                int max = Safely.Get(() => p.MaxXp, int.MaxValue);
                if (max <= 0 || xp < max) break;

                int lvlBefore = Safely.Get(() => p.PlayerLevel, 0);
                Safely.Run(() => p.LevelUp());
                if (Safely.Get(() => p.PlayerLevel, lvlBefore) == lvlBefore) break;
            }
        }

        /// <summary>
        /// Widen the hand for the rest of the run. DealCount is this game's
        /// cards-dealt-per-turn, so it is the stat that governs hand size.
        ///
        /// This goes through AddRunValueModifier rather than SetValue because SimpleStat
        /// carries a _resetAfterEncounter flag: a plain SetValue is the *current* value and
        /// gets wiped the next time the game resets stats at an encounter boundary.
        /// AddRunValueModifier raises the run's *base* instead -- the same channel the
        /// game's own power-ups and arcana use -- so every later reset restores to the
        /// boosted number and the extra cards persist for the whole run.
        ///
        /// Takes effect on the next deal.
        /// </summary>
        internal static void AddHandSize(GameContext ctx, int delta)
        {
            var s = ctx.Stat(StatId.DealCount);
            if (s == null) return;

            // Lift the ceiling first, or the raised base is clamped straight back down.
            Safely.Run(() => s.Uncap());
            Safely.Run(() => s.AddMax(delta, true));
            Safely.Run(() => s.AddRunValueModifier(delta, true));

            TrainerPlugin.Info("Hand size: run base modifier now "
                + Safely.Get(() => s.RunBaseAmountModifierValue.ToString("0.##"), "?")
                + ", current deal count "
                + Safely.Get(() => s.Value.ToString("0.##"), "?"));
        }

        /// <summary>
        /// Add coins to the persistent shop wallet (the between-runs currency), which is a
        /// different pot from the run's own coin count that AddCoins touches.
        /// </summary>
        internal static void AddShopCoins(GameContext ctx, long amount)
        {
            var progression = ctx.Progression;
            if (progression == null) return;
            Safely.Run(() => progression.AddCoins(amount));
        }
    }
}
