using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>What the pointer did over a row this frame.</summary>
    internal struct RowInput
    {
        internal bool Hover;
        internal bool Clicked;       // pressed and released without moving -- a real click
        internal bool RightClicked;
        internal float Wheel;        // notches: +1 per scroll step up, -1 per step down
        internal float DragDelta;    // horizontal pixels moved this frame while dragging
        internal bool Dragging;
    }

    /// <summary>
    /// Immediate-mode drawing helpers built on manual rects (never GUILayout, so the
    /// Layout/Repaint event pairing can't desync).
    ///
    /// The one rule this enforces everywhere: a drag is not a click. A press that moves
    /// past the threshold becomes a drag and never fires the row's click action on release.
    /// </summary>
    internal sealed class Gui
    {
        private int _activeId = -1;
        private Vector2 _pressPos;
        private bool _moved;

        private GUIStyle _label, _labelRight, _title, _small;

        internal void EnsureStyles()
        {
            if (_label != null && _label.fontSize == Theme.Font(14)) return;

            GUIStyle basis;
            try { basis = new GUIStyle(GUI.skin.label); }
            catch (System.Exception) { basis = new GUIStyle(); }

            _label = new GUIStyle(basis)
            {
                fontSize = Theme.Font(14),
                alignment = TextAnchor.MiddleLeft,
                richText = false,
                wordWrap = false
            };
            _label.normal.textColor = Theme.Text;

            _labelRight = new GUIStyle(_label) { alignment = TextAnchor.MiddleRight };
            _labelRight.normal.textColor = Theme.Text;

            _title = new GUIStyle(_label) { fontSize = Theme.Font(15), fontStyle = FontStyle.Bold };
            _title.normal.textColor = Theme.Accent;

            _small = new GUIStyle(_label) { fontSize = Theme.Font(12) };
            _small.normal.textColor = Theme.TextMuted;
        }

        internal GUIStyle Label => _label;
        internal GUIStyle LabelRight => _labelRight;
        internal GUIStyle Title => _title;
        internal GUIStyle Small => _small;

        internal void Text(Rect r, string s, GUIStyle style, Color color)
            => Painter.Text(r, s, style, color);

        internal Vector2 Measure(string s, GUIStyle style) => Painter.Measure(s, style);

        /// <summary>
        /// Process pointer interaction for one row. <paramref name="id"/> must be stable
        /// across frames for the same row (its index in the drawn list is fine).
        /// </summary>
        internal RowInput Interact(Rect r, int id)
        {
            var e = Event.current;
            var res = new RowInput();
            if (e == null) return res;

            bool inside = r.Contains(e.mousePosition);
            res.Hover = inside;

            float threshold = 3f * Theme.Scale;

            switch (e.type)
            {
                case EventType.MouseDown:
                    if (inside && e.button == 0)
                    {
                        _activeId = id;
                        _pressPos = e.mousePosition;
                        _moved = false;
                        e.Use();
                    }
                    else if (inside && e.button == 1)
                    {
                        res.RightClicked = true;
                        e.Use();
                    }
                    break;

                case EventType.MouseDrag:
                    if (_activeId == id)
                    {
                        if (!_moved && (e.mousePosition - _pressPos).magnitude > threshold)
                            _moved = true;
                        if (_moved)
                        {
                            res.Dragging = true;
                            res.DragDelta = e.delta.x;
                        }
                        e.Use();
                    }
                    break;

                case EventType.MouseUp:
                    if (_activeId == id)
                    {
                        // Only a press that never became a drag counts as a click.
                        if (!_moved && inside) res.Clicked = true;
                        _activeId = -1;
                        _moved = false;
                        e.Use();
                    }
                    break;

                case EventType.ScrollWheel:
                    if (inside)
                    {
                        // Unity reports positive delta.y when scrolling *down*; invert so
                        // "wheel up" reads as a positive increment.
                        res.Wheel = -Mathf.Sign(e.delta.y);
                        e.Use();
                    }
                    break;
            }

            return res;
        }

        /// <summary>Row background: alternating base, brightened while hovered.</summary>
        internal void RowBackground(Rect r, int index, bool hover)
        {
            if (index % 2 == 1) Theme.Fill(r, Theme.RowAlt);
            if (hover) Theme.Fill(r, Theme.RowHover);
        }

        internal void Panel(Rect r)
        {
            Theme.Fill(r, Theme.Backdrop);
            Theme.Outline(r, Theme.Border);
        }
    }
}
