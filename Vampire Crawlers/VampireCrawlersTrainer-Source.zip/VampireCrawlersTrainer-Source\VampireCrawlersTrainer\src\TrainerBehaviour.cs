using StatId = Nosebleed.Pancake.GameLogic.PlayerStats.Stats;
using System;
using System.Collections.Generic;
using System.Text;
using Il2CppInterop.Runtime.Attributes;
using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// Drives the trainer: reads hotkeys, runs per-frame upkeep for held cheats, and draws
    /// the two surfaces -- a compact always-on status strip, and the full panel on demand.
    /// </summary>
    internal sealed class TrainerBehaviour : MonoBehaviour
    {
        public TrainerBehaviour(IntPtr ptr) : base(ptr) { }

        private readonly GameContext _ctx = new GameContext();
        private readonly Gui _gui = new Gui();
        private TrainerConfig _cfg;

        private bool _panelOpen;
        private bool _stripOpen = true;
        private bool _cursorSaved;
        private bool _prevCursorVisible;
        private CursorLockMode _prevCursorLock;

        private const float RowH = 26f;

        /// <summary>
        /// Cheats a panel click asked for. Clicks arrive during OnGUI, but nothing may
        /// mutate game state from there, so they are drained on the next Update.
        /// </summary>
        private readonly List<ICheat> _queued = new List<ICheat>();

        [HideFromIl2Cpp]
        internal void Configure(TrainerConfig cfg)
        {
            _cfg = cfg;
            _stripOpen = cfg.StripVisibleByDefault;
        }

        private void Update()
        {
            if (_cfg == null) return;

            Hotkeys.LogBackendsOnce();
            _ctx.Refresh();

            if (Hotkeys.Down(_cfg.KeyPanel)) TogglePanel();
            if (Hotkeys.Down(_cfg.KeyStrip)) _stripOpen = !_stripOpen;

            // Panel clicks queued during OnGUI run here, on the main update step.
            for (int i = 0; i < _queued.Count; i++)
            {
                var queued = _queued[i];
                if (queued.Available(_ctx)) queued.Activate(_ctx);
            }
            _queued.Clear();

            // Hotkeys and upkeep both just walk the registry.
            var all = CheatCatalog.All;
            for (int i = 0; i < all.Count; i++)
            {
                var cheat = all[i];
                if (cheat.Hotkey != KeyCode.None && Hotkeys.Down(cheat.Hotkey))
                {
                    if (cheat.Available(_ctx)) cheat.Activate(_ctx);
                    else TrainerPlugin.Info(cheat.Label + ": not available right now (no active run?)");
                }
                cheat.Tick(_ctx);
            }

            Hotkeys.EndFrame();
        }

        [HideFromIl2Cpp]
        private void TogglePanel()
        {
            _panelOpen = !_panelOpen;
            if (_panelOpen)
            {
                _prevCursorVisible = Cursor.visible;
                _prevCursorLock = Cursor.lockState;
                _cursorSaved = true;
                Cursor.visible = true;
                Cursor.lockState = CursorLockMode.None;
            }
            else if (_cursorSaved)
            {
                Cursor.visible = _prevCursorVisible;
                Cursor.lockState = _prevCursorLock;
                _cursorSaved = false;
            }
        }

        private void OnGUI()
        {
            if (_cfg == null) return;
            // IMGUI's event stream is the primary hotkey source; capture keys before
            // any early-out so bindings work even if drawing is unavailable.
            var ev = Event.current;
            if (ev != null && ev.type == EventType.KeyDown) Hotkeys.NoteGuiKey(ev.keyCode);

            try { GUI.depth = -1000; } catch (Exception) { }
            _gui.EnsureStyles();
            Painter.Resolve();
            if (!Painter.Usable) return;

            if (_stripOpen) DrawStrip();
            if (_panelOpen) DrawPanel();
        }

        // ------------------------------------------------------------------
        // Always-on strip: the few values you actually decide on, no interaction needed.
        // ------------------------------------------------------------------
        [HideFromIl2Cpp]
        private void DrawStrip()
        {
            string line = BuildStripText();
            var style = _gui.Small;
            Vector2 size = _gui.Measure(line, style);

            float padX = Theme.Px(10f), padY = Theme.Px(5f);
            var rect = new Rect(Theme.Px(12f), Theme.Px(12f),
                                size.x + padX * 2f, size.y + padY * 2f);

            Theme.Fill(rect, Theme.BackdropSoft);
            Theme.Outline(rect, Theme.BorderSoft);
            _gui.Text(new Rect(rect.x + padX, rect.y + padY, size.x, size.y),
                      line, style, Theme.Text);
        }

        [HideFromIl2Cpp]
        private string BuildStripText()
        {
            var sb = new StringBuilder();
            sb.Append("VC Trainer  ").Append(Hotkeys.Name(_cfg.KeyPanel)).Append(" menu");

            if (_ctx.InRun)
            {
                sb.Append("   |   HP ").Append(_ctx.HpText);
                sb.Append("  Coins ").Append(_ctx.CoinsText);
                sb.Append("  Lv ").Append(_ctx.LevelText);
                sb.Append("  Mana ").Append(_ctx.ManaText);
            }
            else
            {
                // Out of a run the shop wallet is the number that matters, since that is
                // what the between-runs shops spend.
                sb.Append("   |   no run   Shop ").Append(_ctx.ShopCoinsText);
            }

            // Active cheats announce themselves rather than needing the panel opened.
            var badges = new List<string>();
            var all = CheatCatalog.All;
            for (int i = 0; i < all.Count; i++)
            {
                string b = all[i].Badge;
                if (!string.IsNullOrEmpty(b)) badges.Add(b);
            }
            if (badges.Count > 0)
            {
                sb.Append("   |   ");
                int shown = Mathf.Min(badges.Count, 4);
                for (int i = 0; i < shown; i++)
                {
                    if (i > 0) sb.Append(", ");
                    sb.Append(badges[i]);
                }
                if (badges.Count > shown) sb.Append(" +").Append(badges.Count - shown);
            }

            return sb.ToString();
        }

        // ------------------------------------------------------------------
        // Full panel
        // ------------------------------------------------------------------
        [HideFromIl2Cpp]
        private void DrawPanel()
        {
            float w = Theme.Px(760f);
            float rowH = Theme.Px(RowH);
            float headerH = Theme.Px(38f);
            float footerH = Theme.Px(30f);

            var stats = new List<ICheat>();
            var byCategory = new List<KeyValuePair<string, List<ICheat>>>();
            SplitCheats(stats, byCategory);

            int leftRows = 0;
            for (int i = 0; i < byCategory.Count; i++) leftRows += byCategory[i].Value.Count + 1;
            int rightRows = stats.Count + 1;
            int bodyRows = Mathf.Max(leftRows, rightRows);

            float h = headerH + bodyRows * rowH + footerH + Theme.Px(10f);
            var panel = new Rect(Theme.Px(12f), Theme.Px(58f), w, h);
            _gui.Panel(panel);

            // Header
            _gui.Text(new Rect(panel.x + Theme.Px(12f), panel.y + Theme.Px(6f),
                               panel.width - Theme.Px(24f), headerH - Theme.Px(8f)),
                      "VAMPIRE CRAWLERS TRAINER", _gui.Title, Theme.Accent);
            Theme.Fill(new Rect(panel.x + Theme.Px(10f), panel.y + headerH - Theme.Px(2f),
                                panel.width - Theme.Px(20f), Mathf.Max(1f, Theme.Scale)),
                       Theme.BorderSoft);

            float bodyY = panel.y + headerH + Theme.Px(4f);
            float colGap = Theme.Px(14f);
            float leftW = (panel.width - Theme.Px(20f) - colGap) * 0.46f;
            float rightW = (panel.width - Theme.Px(20f) - colGap) * 0.54f;
            float leftX = panel.x + Theme.Px(10f);
            float rightX = leftX + leftW + colGap;

            int rowId = 0;

            // Left: grouped action/toggle cheats
            float y = bodyY;
            for (int c = 0; c < byCategory.Count; c++)
            {
                var group = byCategory[c];
                _gui.Text(new Rect(leftX + Theme.Px(10f), y, leftW, rowH),
                          group.Key.ToUpperInvariant(), _gui.Small, Theme.AccentDim);
                y += rowH;

                for (int i = 0; i < group.Value.Count; i++)
                {
                    var row = new Rect(leftX, y, leftW, rowH);
                    DrawCheatRow(group.Value[i], row, rowId++, i);
                    y += rowH;
                }
            }

            // Right: the stat editor
            y = bodyY;
            _gui.Text(new Rect(rightX + Theme.Px(10f), y, rightW, rowH),
                      "STATS   wheel / drag to change", _gui.Small, Theme.AccentDim);
            y += rowH;
            for (int i = 0; i < stats.Count; i++)
            {
                var row = new Rect(rightX, y, rightW, rowH);
                DrawCheatRow(stats[i], row, rowId++, i);
                y += rowH;
            }

            // Footer: the discoverability cost of gestures, paid once, compactly.
            var footer = new Rect(panel.x + Theme.Px(12f), panel.yMax - footerH,
                                  panel.width - Theme.Px(24f), footerH);
            _gui.Text(footer,
                      "click a row to fire or hold   -   wheel or drag a stat to change it   -   "
                      + "right-click a stat to release   -   " + Hotkeys.Name(_cfg.KeyPanel) + " closes",
                      _gui.Small, Theme.TextMuted);
        }

        [HideFromIl2Cpp]
        private void DrawCheatRow(ICheat cheat, Rect row, int rowId, int stripeIndex)
        {
            RowInput input = _gui.Interact(row, rowId);
            _gui.RowBackground(row, stripeIndex, input.Hover);

            // Stat rows consume drag/wheel themselves; a plain click still means "activate".
            // Queue it rather than firing here -- see _queued.
            if (input.Clicked && cheat.Available(_ctx) && !_queued.Contains(cheat)) _queued.Add(cheat);

            cheat.Draw(row, stripeIndex, _gui, _ctx, input);
        }

        [HideFromIl2Cpp]
        private static void SplitCheats(List<ICheat> stats, List<KeyValuePair<string, List<ICheat>>> byCategory)
        {
            var all = CheatCatalog.All;
            for (int i = 0; i < all.Count; i++)
            {
                var cheat = all[i];
                if (cheat.Category == "Stats") { stats.Add(cheat); continue; }

                List<ICheat> bucket = null;
                for (int j = 0; j < byCategory.Count; j++)
                    if (byCategory[j].Key == cheat.Category) { bucket = byCategory[j].Value; break; }

                if (bucket == null)
                {
                    bucket = new List<ICheat>();
                    byCategory.Add(new KeyValuePair<string, List<ICheat>>(cheat.Category, bucket));
                }
                bucket.Add(cheat);
            }
        }
    }
}
