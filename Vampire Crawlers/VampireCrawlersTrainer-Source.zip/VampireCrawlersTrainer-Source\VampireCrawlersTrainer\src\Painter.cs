using System;
using System.Collections.Generic;
using UnityEngine;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// Draws the overlay's two primitives -- a filled rect and a run of text -- against
    /// whatever IMGUI surface survived this build's managed-code stripping.
    ///
    /// Vampire Crawlers never calls IMGUI itself, so Unity's linker removed most of
    /// UnityEngine.GUI from the il2cpp binary; the interop shims for those methods throw
    /// NotSupportedException ("Method unstripping failed") rather than drawing. Which ones
    /// survive is a property of the shipped build, not something that can be known ahead of
    /// time, so each primitive is resolved once at runtime by trying the candidates
    /// off-screen in order and keeping the first that does not throw.
    ///
    /// Adding another fallback means adding one entry to the candidate list.
    /// </summary>
    internal static class Painter
    {
        private sealed class Candidate<T>
        {
            internal string Name;
            internal T Draw;
        }

        private static Action<Rect, Texture> _fill;
        private static Action<Rect, string, GUIStyle> _text;
        private static bool _resolved;
        private static GUIStyle _bgStyle;

        /// <summary>True once a usable fill and text primitive were found.</summary>
        internal static bool Usable => _fill != null && _text != null;

        private static Texture White
        {
            get
            {
                try { if (Texture2D.whiteTexture != null) return Texture2D.whiteTexture; }
                catch (Exception) { }
                return Theme.Solid;
            }
        }

        private static GUIStyle BgStyle
        {
            get
            {
                if (_bgStyle == null)
                {
                    _bgStyle = new GUIStyle();
                    try { _bgStyle.normal.background = Theme.Solid; } catch (Exception) { }
                }
                return _bgStyle;
            }
        }

        // ---- candidate primitives, most direct first --------------------------------
        private static List<Candidate<Action<Rect, Texture>>> FillCandidates()
        {
            return new List<Candidate<Action<Rect, Texture>>>
            {
                new Candidate<Action<Rect, Texture>> {
                    Name = "GUI.DrawTexture",
                    Draw = (r, t) => GUI.DrawTexture(r, t) },

                new Candidate<Action<Rect, Texture>> {
                    Name = "GUI.DrawTextureWithTexCoords",
                    Draw = (r, t) => GUI.DrawTextureWithTexCoords(r, t, new Rect(0f, 0f, 1f, 1f)) },

                new Candidate<Action<Rect, Texture>> {
                    Name = "GUI.Label(bg style)",
                    Draw = (r, t) => GUI.Label(r, GUIContent.none, BgStyle) },

                new Candidate<Action<Rect, Texture>> {
                    Name = "GUI.Box(bg style)",
                    Draw = (r, t) => GUI.Box(r, GUIContent.none, BgStyle) },

                new Candidate<Action<Rect, Texture>> {
                    Name = "GUI.Box(empty string)",
                    Draw = (r, t) => GUI.Box(r, string.Empty) },
            };
        }

        private static List<Candidate<Action<Rect, string, GUIStyle>>> TextCandidates()
        {
            return new List<Candidate<Action<Rect, string, GUIStyle>>>
            {
                new Candidate<Action<Rect, string, GUIStyle>> {
                    Name = "GUI.Label(string, style)",
                    Draw = (r, s, st) => GUI.Label(r, s, st) },

                new Candidate<Action<Rect, string, GUIStyle>> {
                    Name = "GUI.Label(GUIContent, style)",
                    Draw = (r, s, st) => GUI.Label(r, new GUIContent(s), st) },

                new Candidate<Action<Rect, string, GUIStyle>> {
                    Name = "GUI.Label(string)",
                    Draw = (r, s, st) => GUI.Label(r, s) },

                new Candidate<Action<Rect, string, GUIStyle>> {
                    Name = "GUI.Box(string, style)",
                    Draw = (r, s, st) => GUI.Box(r, s, st) },
            };
        }

        /// <summary>
        /// Resolve both primitives by drawing off-screen. Must be called from inside OnGUI.
        /// </summary>
        internal static void Resolve()
        {
            if (_resolved) return;
            _resolved = true;

            var probe = new Rect(-4000f, -4000f, 2f, 2f);
            Texture white = White;

            foreach (var c in FillCandidates())
            {
                try
                {
                    c.Draw(probe, white);
                    _fill = c.Draw;
                    TrainerPlugin.Info("Painter: fill via " + c.Name);
                    break;
                }
                catch (Exception ex)
                {
                    TrainerPlugin.Info("Painter: fill candidate " + c.Name + " unavailable (" + ex.GetType().Name + ")");
                }
            }

            GUIStyle style;
            try { style = new GUIStyle(GUI.skin.label); }
            catch (Exception) { style = new GUIStyle(); }

            foreach (var c in TextCandidates())
            {
                try
                {
                    c.Draw(probe, "probe", style);
                    _text = c.Draw;
                    TrainerPlugin.Info("Painter: text via " + c.Name);
                    break;
                }
                catch (Exception ex)
                {
                    TrainerPlugin.Info("Painter: text candidate " + c.Name + " unavailable (" + ex.GetType().Name + ")");
                }
            }

            if (!Usable)
                TrainerPlugin.Warn("Painter: no usable IMGUI primitive in this build; "
                                   + "hotkeys still work but the overlay cannot draw.");
        }

        internal static void Fill(Rect r, Color c)
        {
            if (_fill == null) return;
            Color prev = GUI.color;
            GUI.color = c;
            try { _fill(r, White); }
            catch (Exception) { _fill = null; }
            finally { GUI.color = prev; }
        }

        internal static void Text(Rect r, string s, GUIStyle style, Color color)
        {
            if (_text == null || style == null) return;
            Color prev = style.normal.textColor;
            style.normal.textColor = color;
            try { _text(r, s, style); }
            catch (Exception) { _text = null; }
            finally { style.normal.textColor = prev; }
        }

        /// <summary>Measure text, falling back to a rough estimate if CalcSize is stripped.</summary>
        internal static Vector2 Measure(string s, GUIStyle style)
        {
            try { return style.CalcSize(new GUIContent(s)); }
            catch (Exception)
            {
                float h = Mathf.Max(12f, style.fontSize <= 0 ? 12f : style.fontSize);
                return new Vector2(s.Length * h * 0.52f, h * 1.35f);
            }
        }
    }
}
