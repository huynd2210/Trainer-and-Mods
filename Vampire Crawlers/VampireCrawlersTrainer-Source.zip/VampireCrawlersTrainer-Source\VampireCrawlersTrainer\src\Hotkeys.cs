using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace VampireCrawlersTrainer
{
    /// <summary>
    /// Keyboard edge-detection that works whichever input backend the player build enabled.
    ///
    /// Primary source is IMGUI's own key events, fed in from OnGUI. That path is used
    /// because it is the one this build demonstrably supports: Vampire Crawlers ships the
    /// new Input System, but polling Keyboard.current from a plugin returned nothing here,
    /// while IMGUI's event stream works. The Input System poll is kept as a secondary
    /// source so the plugin still responds if IMGUI events ever stop arriving.
    ///
    /// Keys seen in OnGUI are buffered and consumed by the next Update, so a press fires
    /// exactly once with at most one frame of latency.
    /// </summary>
    internal static class Hotkeys
    {
        // Only the keys the trainer can bind need a mapping for the Input System path.
        private static readonly Dictionary<KeyCode, Key> Map = new Dictionary<KeyCode, Key>
        {
            { KeyCode.F1,  Key.F1  }, { KeyCode.F2,  Key.F2  }, { KeyCode.F3,  Key.F3  },
            { KeyCode.F4,  Key.F4  }, { KeyCode.F5,  Key.F5  }, { KeyCode.F6,  Key.F6  },
            { KeyCode.F7,  Key.F7  }, { KeyCode.F8,  Key.F8  }, { KeyCode.F9,  Key.F9  },
            { KeyCode.F10, Key.F10 }, { KeyCode.F11, Key.F11 }, { KeyCode.F12, Key.F12 },
            { KeyCode.Insert, Key.Insert }, { KeyCode.Delete, Key.Delete },
            { KeyCode.Home, Key.Home }, { KeyCode.End, Key.End },
            { KeyCode.PageUp, Key.PageUp }, { KeyCode.PageDown, Key.PageDown },
            { KeyCode.Backslash, Key.Backslash },
        };

        private static readonly HashSet<KeyCode> _fromGui = new HashSet<KeyCode>();
        private static bool _inputSystemUsable = true;
        private static bool _legacyUsable = true;
        private static bool _logged;

        /// <summary>Called from OnGUI for every KeyDown event Unity delivers.</summary>
        internal static void NoteGuiKey(KeyCode code)
        {
            if (code != KeyCode.None) _fromGui.Add(code);
        }

        /// <summary>True if <paramref name="code"/> went down since the last EndFrame.</summary>
        internal static bool Down(KeyCode code)
        {
            if (code == KeyCode.None) return false;
            if (_fromGui.Contains(code)) return true;

            if (_inputSystemUsable)
            {
                try
                {
                    var kb = Keyboard.current;
                    if (kb != null && Map.TryGetValue(code, out Key key))
                    {
                        var ctrl = kb[key];
                        if (ctrl != null && ctrl.wasPressedThisFrame) return true;
                    }
                }
                catch (Exception)
                {
                    _inputSystemUsable = false;
                }
            }

            if (_legacyUsable)
            {
                try { if (Input.GetKeyDown(code)) return true; }
                catch (Exception) { _legacyUsable = false; }
            }

            return false;
        }

        /// <summary>Drop this frame's buffered GUI keys. Call once per Update, after polling.</summary>
        internal static void EndFrame()
        {
            if (_fromGui.Count > 0) _fromGui.Clear();
        }

        /// <summary>One-time note of which backends answered, to make diagnosis cheap.</summary>
        internal static void LogBackendsOnce()
        {
            if (_logged) return;
            _logged = true;

            string ks;
            try { ks = Keyboard.current != null ? "available" : "null"; }
            catch (Exception ex) { ks = "threw " + ex.GetType().Name; }

            string legacy;
            try { Input.GetKeyDown(KeyCode.F13); legacy = "available"; }
            catch (Exception ex) { legacy = "threw " + ex.GetType().Name; }

            TrainerPlugin.Info("Hotkeys: InputSystem Keyboard.current = " + ks
                               + "; legacy Input = " + legacy + "; IMGUI events = primary");
        }

        internal static string Name(KeyCode code) => code == KeyCode.None ? "--" : code.ToString();
    }
}
