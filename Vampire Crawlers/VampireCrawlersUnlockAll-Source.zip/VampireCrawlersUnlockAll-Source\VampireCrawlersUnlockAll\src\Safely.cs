using System;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// Guards every read of il2cpp state. Managed exceptions crossing the interop boundary
    /// are routine here -- a config with a null field, a collection mid-rebuild, a property
    /// whose implementation Unity's linker stripped out of the shipped build -- and none of
    /// them should take down a category, let alone the plugin.
    ///
    /// This cannot save us from a native access violation (touching a freed il2cpp object
    /// kills the process outright, uncatchably). That hazard is handled separately, by only
    /// ever touching progression from Update and never from OnGUI.
    /// </summary>
    internal static class Safely
    {
        internal static T Get<T>(Func<T> read, T fallback)
        {
            try { return read(); }
            catch (Exception) { return fallback; }
        }

        /// <summary>Run an action, swallow and log a managed failure. Returns success.</summary>
        internal static bool Do(string what, Action act)
        {
            try { act(); return true; }
            catch (Exception ex)
            {
                UnlockAllPlugin.Warn(what + " failed: " + ex.GetType().Name + ": " + ex.Message);
                return false;
            }
        }
    }
}
