using Nosebleed.Pancake.Achievements;
using Nosebleed.Pancake.MetaProgression;

namespace VampireCrawlersUnlockAll.Categories
{
    /// <summary>
    /// Every achievement marked unlocked. This is the category that does most of the work:
    /// relics, arcanas and the content gated behind them all ask whether their required
    /// achievement is unlocked (AchievementUnlockType.HasMetUnlockCriteria reads this very
    /// dictionary), so flipping these flags opens all of it without this mod needing to
    /// know what any individual relic or arcana is.
    ///
    /// The flags are written straight into the dictionary rather than through
    /// ForceUnlockAchievement, on purpose. That method also pays out coin rewards, fires
    /// the unlock toast for each one, and pushes the achievement to the platform (Steam).
    /// Going around it keeps the operation silent and, more importantly, keeps it exactly
    /// reversible: nothing is granted that a revert could not take back.
    ///
    /// A platform achievement that was already earned on Steam stays earned there. This
    /// mod only touches the local save, and it cannot un-earn a Steam achievement.
    /// </summary>
    internal sealed class AchievementsCategory : FlagMapCategory<AchievementConfig>
    {
        internal override string Id => "Achievements";
        internal override string Label => "Achievements";
        internal override string Note =>
            "Mark every achievement unlocked. This is what opens relics and arcanas, "
            + "because they are gated on achievements. No coin rewards are paid out and "
            + "nothing is sent to Steam.";

        protected override Il2CppSystem.Collections.Generic.Dictionary<AchievementConfig, bool> Map(ProgressionData d) =>
            d._achievementsUnlocked;

        protected override string KeyId(AchievementConfig key) => ProgressionAccess.IdOf(key);
    }
}
