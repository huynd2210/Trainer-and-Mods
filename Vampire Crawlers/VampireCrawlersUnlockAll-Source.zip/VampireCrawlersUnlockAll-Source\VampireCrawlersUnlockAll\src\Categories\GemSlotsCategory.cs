using Nosebleed.Pancake.GameConfig;
using Nosebleed.Pancake.MetaProgression;

namespace VampireCrawlersUnlockAll.Categories
{
    /// <summary>
    /// Every card opened up to the most gem slots it is allowed.
    ///
    /// The ceiling comes from each card's own MaxGemSlotsAllowed, so cards that are not
    /// meant to take gems stay at zero rather than being forced to some invented number.
    ///
    /// Like the power-ups, these are bought rather than unlocked, and buying them here
    /// spends no coins -- so the jeweller's refund would pay out for slots that were never
    /// paid for. Switch the category off in the config if that matters to you.
    ///
    /// Cards already in play keep whatever slot count they were dealt with; the new
    /// ceiling applies from the next run.
    /// </summary>
    internal sealed class GemSlotsCategory : LevelMapCategory<CardConfig>
    {
        internal override string Id => "CardGemSlots";
        internal override string Label => "Gem slots";
        internal override string Note =>
            "Open every card up to the most gem slots it allows, without spending coins.";

        protected override Il2CppSystem.Collections.Generic.Dictionary<CardConfig, int> Map(ProgressionData d) =>
            d._cardGemSlots;

        protected override string KeyId(CardConfig key) => ProgressionAccess.IdOf(key);

        protected override int UnlockedValue(CardConfig key) =>
            Safely.Get(() => key.MaxGemSlotsAllowed, 0);
    }
}
