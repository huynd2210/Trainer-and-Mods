using System;
using System.Collections.Generic;
using Il2CppDict = Il2CppSystem.Collections.Generic.Dictionary<Il2CppSystem.Object, Il2CppSystem.Object>;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// Copying il2cpp collections out into plain managed lists before touching them.
    ///
    /// Two reasons this exists rather than using foreach at the call sites. First, every
    /// category mutates the dictionary it is walking, and an il2cpp Dictionary invalidates
    /// its enumerator on write exactly like the managed one -- so the keys have to be
    /// snapshotted first. Second, the enumerator itself is interop-generated and is the
    /// most fragile thing in this plugin; isolating it here means one place to fix if a
    /// future game build changes it, instead of eight.
    /// </summary>
    internal static class Interop
    {
        /// <summary>
        /// Every key of an il2cpp dictionary, copied into a managed list.
        /// Returns an empty list (never null) if the collection cannot be walked.
        /// </summary>
        internal static List<TKey> Keys<TKey, TValue>(
            Il2CppSystem.Collections.Generic.Dictionary<TKey, TValue> dict)
        {
            var keys = new List<TKey>();
            if (dict == null) return keys;

            try
            {
                var e = dict.Keys.GetEnumerator();
                while (e.MoveNext())
                {
                    TKey k = e.Current;
                    if (k != null) keys.Add(k);
                }
            }
            catch (Exception ex)
            {
                UnlockAllPlugin.Warn("Could not enumerate dictionary keys ("
                                     + typeof(TKey).Name + "): " + ex.GetType().Name + ": " + ex.Message);
            }
            return keys;
        }

        /// <summary>Every member of an il2cpp HashSet, copied into a managed list.</summary>
        internal static List<T> Members<T>(Il2CppSystem.Collections.Generic.HashSet<T> set)
        {
            var items = new List<T>();
            if (set == null) return items;

            try
            {
                var e = set.GetEnumerator();
                while (e.MoveNext())
                {
                    T v = e.Current;
                    if (v != null) items.Add(v);
                }
            }
            catch (Exception ex)
            {
                UnlockAllPlugin.Warn("Could not enumerate set (" + typeof(T).Name + "): "
                                     + ex.GetType().Name + ": " + ex.Message);
            }
            return items;
        }

        /// <summary>
        /// Every asset in one of the game's multi-databases, copied into a managed list.
        ///
        /// Takes the backing List rather than the IReadOnlyList the database exposes
        /// publicly: the interop-generated generic interface carries none of its members,
        /// so Count and the indexer are only reachable on the concrete type. Indexing also
        /// beats enumerating here -- fewer interop objects, and nothing to invalidate.
        /// </summary>
        internal static List<T> Assets<T>(Il2CppSystem.Collections.Generic.List<T> list)
        {
            var items = new List<T>();
            if (list == null) return items;

            try
            {
                int n = list.Count;
                for (int i = 0; i < n; i++)
                {
                    T v = Safely.Get(() => list[i], default(T));
                    if (v != null) items.Add(v);
                }
            }
            catch (Exception ex)
            {
                UnlockAllPlugin.Warn("Could not read database (" + typeof(T).Name + "): "
                                     + ex.GetType().Name + ": " + ex.Message);
            }
            return items;
        }
    }
}
