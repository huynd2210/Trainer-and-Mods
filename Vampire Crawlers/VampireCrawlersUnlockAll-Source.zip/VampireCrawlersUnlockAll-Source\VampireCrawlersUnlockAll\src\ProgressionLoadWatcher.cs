using System;
using HarmonyLib;
using Nosebleed.Pancake.MetaProgression;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// Knows whether the progression object currently in memory is the player's, or just
    /// the empty defaults the game starts with.
    ///
    /// This exists because of a trap that cost a save's worth of nerve. `Globals.Progression`
    /// is a ScriptableObject that exists from the first frame, at the title screen, before
    /// any profile is chosen -- and at that point it is blank. Unlocking then writes into an
    /// object the game is about to throw away: pressing Continue calls ProcessLoadedData,
    /// which replaces every value with the one from the save, and the unlock silently
    /// evaporates.
    ///
    /// Worse than losing the unlock: had the game flushed while that blank object was live,
    /// it would have written near-empty progression over a real save. So this is a safety
    /// gate, not a convenience -- the unlock refuses to run until a load has been seen.
    ///
    /// ProcessLoadedData is the signal because it is the exact moment the save's contents
    /// land in the live object. OnNewGame counts too: it resets progression deliberately,
    /// and from then on memory is the authority for that profile.
    /// </summary>
    internal static class ProgressionLoadWatcher
    {
        /// <summary>True once the game has put a real profile into the live progression.</summary>
        internal static bool Loaded { get; private set; }

        /// <summary>True if the patches could not be applied, so Loaded can never be trusted.</summary>
        internal static bool Broken { get; private set; }

        /// <summary>
        /// Bumped every time the game replaces the live progression. The engine compares it
        /// against the value at unlock time to notice that a load has wiped the unlocks.
        /// </summary>
        internal static int Generation { get; private set; }

        internal static void Install(Harmony harmony)
        {
            try
            {
                harmony.PatchAll(typeof(ProgressionLoadWatcher));

                // PatchAll reports nothing useful on failure, so confirm by asking Harmony
                // what it actually patched rather than assuming it worked.
                var target = AccessTools.Method(typeof(ProgressionData), nameof(ProgressionData.ProcessLoadedData));
                if (target == null || Harmony.GetPatchInfo(target)?.Postfixes == null)
                {
                    Broken = true;
                    UnlockAllPlugin.Warn("Could not hook ProgressionData.ProcessLoadedData. Without it "
                                         + "there is no way to tell a loaded profile from the blank one "
                                         + "the title screen starts with, so unlocking will refuse to run.");
                    return;
                }

                UnlockAllPlugin.Info("Watching for progression loads.");
            }
            catch (Exception ex)
            {
                Broken = true;
                UnlockAllPlugin.Warn("Could not install the progression-load hook (" + ex.GetType().Name
                                     + ": " + ex.Message + "). Unlocking will refuse to run.");
            }
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(ProgressionData), nameof(ProgressionData.ProcessLoadedData))]
        private static void AfterLoad()
        {
            Loaded = true;
            Generation++;
            UnlockAllPlugin.Info("Progression loaded from save (generation " + Generation + ").");
        }

        [HarmonyPostfix]
        [HarmonyPatch(typeof(ProgressionData), nameof(ProgressionData.OnNewGame))]
        private static void AfterNewGame()
        {
            Loaded = true;
            Generation++;
            UnlockAllPlugin.Info("Progression reset for a new game (generation " + Generation + ").");
        }
    }
}
