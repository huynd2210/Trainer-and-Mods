using System.Collections.Generic;
using UnityEngine;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// The panel: what is unlocked right now, whether a baseline exists, and the two keys
    /// that change either.
    ///
    /// Keyboard-driven with no buttons. The two operations here rewrite a save file, so
    /// they are not gestures to be stumbled into -- each asks for its key a second time
    /// before doing anything, and the confirm lapses on its own after a few seconds. The
    /// counts next to every category are the point of the panel: the state you are about
    /// to change is on screen before you change it, not behind a menu.
    ///
    /// Draws with manual rects and never GUILayout, so the Layout/Repaint event pairing
    /// cannot desync, and reads nothing from the game -- every value it shows was copied
    /// out of il2cpp during Update. See UnlockAllBehaviour for why that matters.
    /// </summary>
    internal sealed class Panel
    {
        private GUIStyle _label, _right, _title, _small;

        /// <summary>One row of the snapshot the panel renders; plain managed data only.</summary>
        internal struct Row
        {
            internal string Label;
            internal string Tally;
            internal bool Complete;
            internal bool Enabled;
        }

        internal bool Visible;

        // Everything below is filled once per frame from Update and is safe to read here.
        internal string Profile = "--";
        internal bool ProgressionReady;
        internal bool Unlocked;
        internal bool NeedsReapply;

        /// <summary>Why unlocking cannot run right now; empty when it can.</summary>
        internal string Blocker = "";
        internal string SnapshotPath = "";
        internal readonly List<Row> Rows = new List<Row>();
        internal string Status = "";
        internal bool StatusIsError;
        internal string Pending = "";       // "unlock", "revert", or empty
        internal string KeyHint = "";

        private void EnsureStyles()
        {
            if (_label != null && _label.fontSize == Theme.Font(14)) return;

            GUIStyle basis;
            try { basis = new GUIStyle(GUI.skin.label); }
            catch (System.Exception) { basis = new GUIStyle(); }

            _label = new GUIStyle(basis)
            {
                fontSize = Theme.Font(14),
                alignment = TextAnchor.MiddleLeft,
                richText = false,
                wordWrap = false
            };
            _label.normal.textColor = Theme.Text;

            _right = new GUIStyle(_label) { alignment = TextAnchor.MiddleRight };
            _title = new GUIStyle(_label) { fontSize = Theme.Font(15), fontStyle = FontStyle.Bold };
            _small = new GUIStyle(_label) { fontSize = Theme.Font(12) };
        }

        internal void Draw()
        {
            if (!Visible || !Painter.Usable) return;
            EnsureStyles();

            float pad = Theme.Px(10f);
            float rowH = Theme.Px(20f);
            float width = Theme.Px(330f);

            int lines = Rows.Count;
            float height = pad * 2f
                         + rowH                                  // title
                         + Theme.Px(6f)                          // rule
                         + lines * rowH
                         + Theme.Px(6f)                          // rule
                         + rowH                                  // state line
                         + (string.IsNullOrEmpty(Status) ? 0f : rowH)
                         + rowH;                                 // hint strip

            // Sits below the trainer's always-on status strip, which owns the top-left
            // corner. The two mods are normally installed together, and a panel drawn on
            // top of that strip hides the coin count it exists to show.
            var panel = new Rect(Theme.Px(16f), Theme.Px(44f), width, height);

            Theme.Fill(panel, Theme.Backdrop);
            Theme.Outline(panel, Theme.Border);

            float x = panel.x + pad;
            float w = panel.width - pad * 2f;
            float y = panel.y + pad;

            // ---- title: what this is, and which profile it will act on ----------------
            Painter.Text(new Rect(x, y, w * 0.6f, rowH), "UNLOCK ALL", _title, Theme.Accent);
            Painter.Text(new Rect(x + w * 0.4f, y, w * 0.6f, rowH), Profile, _right, Theme.TextMuted);
            y += rowH;

            Theme.Fill(new Rect(x, y + Theme.Px(2f), w, Mathf.Max(1f, Theme.Px(1f))), Theme.BorderSoft);
            y += Theme.Px(6f);

            // ---- the ambient layer: every category and how much of it is open ---------
            for (int i = 0; i < Rows.Count; i++)
            {
                Row r = Rows[i];
                var line = new Rect(x, y, w, rowH);
                if (i % 2 == 1) Theme.Fill(line, Theme.RowAlt);

                Color nameColor = r.Enabled ? Theme.Text : Theme.TextMuted;
                Color tallyColor = !r.Enabled ? Theme.TextMuted
                                 : r.Complete ? Theme.Good
                                 : Theme.Text;

                // A switched-off category is drawn dimmed with a hollow marker rather than
                // hidden, so "why did that not unlock" is answerable from the panel.
                string marker = r.Enabled ? "●  " : "○  ";
                Painter.Text(new Rect(line.x + Theme.Px(2f), line.y, w * 0.62f, rowH),
                             marker + r.Label, _label, nameColor);
                Painter.Text(new Rect(line.x, line.y, w - Theme.Px(2f), rowH),
                             r.Tally, _right, tallyColor);
                y += rowH;
            }

            Theme.Fill(new Rect(x, y + Theme.Px(2f), w, Mathf.Max(1f, Theme.Px(1f))), Theme.BorderSoft);
            y += Theme.Px(6f);

            // ---- state: can this run, and is there a way back from here? --------------
            //
            // The blocker is shown here rather than only after a failed attempt. The
            // commonest one -- no profile loaded yet -- used to look identical to a working
            // panel, right up until the unlock quietly evaporated on the next load.
            string state;
            Color stateColor;
            if (!string.IsNullOrEmpty(Blocker))
            {
                state = Blocker;
                stateColor = Theme.Danger;
            }
            else if (NeedsReapply)
            {
                state = "Reloaded since unlocking — press U to re-apply";
                stateColor = Theme.Danger;
            }
            else if (Unlocked)
            {
                state = "Unlocked — baseline saved, revert available";
                stateColor = Theme.Accent;
            }
            else
            {
                state = "Original — nothing changed yet";
                stateColor = Theme.TextMuted;
            }
            Painter.Text(new Rect(x, y, w, rowH), state, _small, stateColor);
            y += rowH;

            if (!string.IsNullOrEmpty(Status))
            {
                Painter.Text(new Rect(x, y, w, rowH), Status, _small,
                             StatusIsError ? Theme.Danger : Theme.Good);
                y += rowH;
            }

            // ---- the one hint strip that pays for the lack of buttons -----------------
            if (!string.IsNullOrEmpty(Pending))
            {
                Painter.Text(new Rect(x, y, w, rowH),
                             "Press " + Pending + " again to confirm — this rewrites your save",
                             _small, Theme.Danger);
            }
            else
            {
                Painter.Text(new Rect(x, y, w, rowH), KeyHint, _small, Theme.TextMuted);
            }
        }
    }
}
