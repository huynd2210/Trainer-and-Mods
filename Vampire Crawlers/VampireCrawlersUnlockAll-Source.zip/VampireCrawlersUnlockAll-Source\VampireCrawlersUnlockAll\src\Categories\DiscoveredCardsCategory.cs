using System.Collections.Generic;
using Nosebleed.Pancake.GameConfig;

namespace VampireCrawlersUnlockAll.Categories
{
    /// <summary>
    /// Every card marked discovered, so the collection reads as complete instead of showing
    /// silhouettes.
    ///
    /// This is the one category that has to consult the content database. Discovery is a
    /// set, not a map -- the game only ever adds to it, so there is no pre-built list of
    /// every card to walk the way the other categories have. The card database is that
    /// list.
    ///
    /// Restoring clears the set and re-adds exactly what the snapshot recorded, which makes
    /// the revert exact rather than approximate: cards discovered before the unlock come
    /// back, and nothing else does.
    /// </summary>
    internal sealed class DiscoveredCardsCategory : UnlockCategory
    {
        internal override string Id => "Cards";
        internal override string Label => "Card collection";
        internal override string Note => "Mark every card as discovered in the collection.";

        private static Il2CppSystem.Collections.Generic.HashSet<CardConfig> Set(ProgressionAccess p)
        {
            var d = p.Data;
            return d == null ? null : Safely.Get(() => d._discoveredCards, null);
        }

        /// <summary>
        /// Every card this build ships, from the multi-database.
        ///
        /// Reads the database's backing _assetList rather than its public Assets property,
        /// because the interop-generated IReadOnlyList the latter returns has no usable
        /// members. Same objects, reachable type.
        /// </summary>
        private static List<CardConfig> AllCards(ProgressionAccess p)
        {
            var multi = Safely.Get<CardConfigMultiDatabase>(
                () => Nosebleed.Pancake.GameConfig.Accessors.Databases.CardConfigs, null);
            if (multi == null) return new List<CardConfig>();
            return Interop.Assets(
                Safely.Get<Il2CppSystem.Collections.Generic.List<CardConfig>>(() => multi._assetList, null));
        }

        internal override void Capture(ProgressionAccess p, Snapshot snap)
        {
            var set = Set(p);
            if (set == null) return;

            foreach (CardConfig card in Interop.Members(set))
            {
                string id = ProgressionAccess.IdOf(card);
                if (!string.IsNullOrEmpty(id)) snap.Set(Id, id, true);
            }
        }

        internal override int Apply(ProgressionAccess p)
        {
            var set = Set(p);
            if (set == null) return 0;

            var cards = AllCards(p);
            if (cards.Count == 0)
            {
                UnlockAllPlugin.Warn("Card database is empty or unreadable; no cards were discovered.");
                return 0;
            }

            int added = 0;
            foreach (CardConfig card in cards)
            {
                CardConfig c = card;
                if (Safely.Get(() => set.Contains(c), false)) continue;
                if (Safely.Do("Discovering " + ProgressionAccess.IdOf(c), () => set.Add(c))) added++;
            }
            return added;
        }

        internal override int Restore(ProgressionAccess p, Snapshot snap)
        {
            var set = Set(p);
            if (set == null) return 0;

            var recorded = snap.Category(Id);

            // Nothing recorded means the category was off when the snapshot was taken, so
            // this mod never added to the set and must not now empty it.
            if (!snap.Has(Id)) return 0;

            int before = Safely.Get(() => set.Count, 0);
            var byId = ProgressionAccess.ById(AllCards(p), ProgressionAccess.IdOf);

            if (!Safely.Do("Clearing the discovered-card set", () => set.Clear())) return 0;

            int restored = 0;
            foreach (string id in recorded.Keys)
            {
                if (!byId.TryGetValue(id, out CardConfig card))
                {
                    UnlockAllPlugin.Warn("Snapshot names card '" + id + "', which this build's "
                                         + "database does not contain; it cannot be restored.");
                    continue;
                }
                CardConfig c = card;
                if (Safely.Do("Restoring discovered card " + id, () => set.Add(c))) restored++;
            }

            int after = Safely.Get(() => set.Count, 0);
            UnlockAllPlugin.Info("Cards: " + before + " discovered -> " + after + " restored.");
            return System.Math.Abs(before - after) == 0 ? 0 : restored;
        }

        internal override Tally Count(ProgressionAccess p)
        {
            var set = Set(p);
            if (set == null) return new Tally(0, 0);
            return new Tally(Safely.Get(() => set.Count, 0), AllCards(p).Count);
        }
    }
}
