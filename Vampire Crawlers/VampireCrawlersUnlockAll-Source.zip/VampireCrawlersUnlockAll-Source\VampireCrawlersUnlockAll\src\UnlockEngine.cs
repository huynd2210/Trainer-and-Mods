using System;
using System.Collections.Generic;
using System.Globalization;

namespace VampireCrawlersUnlockAll
{
    /// <summary>What an unlock or revert did, in one line the panel can show.</summary>
    internal struct Outcome
    {
        internal bool Ok;
        internal string Message;

        internal static Outcome Fail(string why) => new Outcome { Ok = false, Message = why };
        internal static Outcome Done(string what) => new Outcome { Ok = true, Message = what };
    }

    /// <summary>
    /// Runs the two operations, in an order chosen so that there is never a moment where
    /// the profile has been changed and no record of the old values exists.
    ///
    /// Unlocking is: refuse unless a real profile is loaded, back up the save file, capture
    /// the baseline, write it, read it back and check it, and only then change anything.
    /// Every one of those is a hard gate -- if the baseline cannot be written and verified,
    /// nothing is unlocked at all. An unlock that cannot be undone is worse than no unlock.
    ///
    /// Reverting restores every category the snapshot has data for, including ones that
    /// have since been switched off in the config. Whatever was changed gets put back,
    /// regardless of what the settings say today.
    /// </summary>
    internal sealed class UnlockEngine
    {
        private readonly ProgressionAccess _p;

        /// <summary>
        /// Which load generation the last unlock was applied to. When the game loads a
        /// profile it replaces every value in the live progression, so an unlock applied
        /// before that load is simply gone -- this is how the panel can say so rather than
        /// leaving the player to guess why everything is locked again.
        /// </summary>
        private int _appliedGeneration = -1;

        internal UnlockEngine(ProgressionAccess progression) { _p = progression; }

        /// <summary>True when a baseline exists, i.e. this profile has been unlocked.</summary>
        internal bool IsUnlocked => SnapshotStore.Exists(_p.ProfileKey);

        /// <summary>
        /// True when there is a baseline but the game has reloaded progression since the
        /// unlock was applied, so the unlocks are no longer in memory.
        /// </summary>
        internal bool NeedsReapply =>
            IsUnlocked && _appliedGeneration >= 0 && ProgressionLoadWatcher.Generation != _appliedGeneration;

        /// <summary>Where the baseline for the current profile lives.</summary>
        internal string SnapshotPath => SnapshotStore.SnapshotPath(_p.ProfileKey);

        /// <summary>
        /// The reason unlocking cannot run right now, or null if it can.
        ///
        /// Separated out so the panel can say what is wrong before the player commits to
        /// anything, instead of only after they have pressed the key twice.
        /// </summary>
        internal string Blocker
        {
            get
            {
                if (ProgressionLoadWatcher.Broken)
                    return "Cannot tell whether a profile is loaded (the game hook failed). See the log.";
                if (!_p.Exists)
                    return "Progression does not exist yet.";
                if (!ProgressionLoadWatcher.Loaded)
                    return "No profile loaded yet — press Continue or start a run first.";
                return null;
            }
        }

        internal Outcome Unlock()
        {
            string blocked = Blocker;
            if (blocked != null) return Outcome.Fail(blocked);

            string profile = _p.ProfileKey;

            var active = UnlockCatalog.Active();
            if (active.Count == 0)
                return Outcome.Fail("Every category is switched off in the config; nothing to do.");

            // --- 1. the baseline, but only the first time --------------------------------
            //
            // A second unlock must never re-record the baseline: it would capture the
            // already-unlocked state as the thing to revert to and destroy the only copy of
            // the real progress. So capture is skipped when one exists, and the unlock is
            // simply re-applied -- which is what a load-then-unlock needs anyway.
            if (!SnapshotStore.Exists(profile))
            {
                Outcome recorded = RecordBaseline(profile, active);
                if (!recorded.Ok) return recorded;
            }
            else
            {
                UnlockAllPlugin.Info("Baseline already recorded for " + profile
                                     + "; re-applying without touching it.");
            }

            // --- 2. now it is safe to change things --------------------------------------
            int total = 0;
            var parts = new List<string>();
            foreach (UnlockCategory c in active)
            {
                int n = 0;
                Safely.Do("Unlocking " + c.Id, () => n = c.Apply(_p));
                total += n;
                if (n > 0) parts.Add(c.Label + " " + n);
            }

            _appliedGeneration = ProgressionLoadWatcher.Generation;
            _p.MarkDirtyAndSave();

            string summary = total == 0
                ? "Everything was already unlocked; nothing changed."
                : "Unlocked " + total + " entries (" + string.Join(", ", parts) + ").";
            UnlockAllPlugin.Info(summary);
            return Outcome.Done(summary);
        }

        /// <summary>
        /// The save copy and the baseline, both verified, before a single value changes.
        /// </summary>
        private Outcome RecordBaseline(string profile, List<UnlockCategory> active)
        {
            // The blunt safety net first.
            string backup = SnapshotStore.BackupSave(profile, out string backupError);
            if (backup == null)
                return Outcome.Fail("Could not back up the save (" + backupError + "). Nothing was changed.");
            UnlockAllPlugin.Info("Save backed up to " + backup);

            // Then the precise one.
            var snap = new Snapshot
            {
                ProfileId = profile,
                TakenUtc = DateTime.UtcNow.ToString("u", CultureInfo.InvariantCulture),
            };

            foreach (UnlockCategory c in active)
                Safely.Do("Capturing " + c.Id, () => c.Capture(_p, snap));

            if (snap.Count == 0)
                return Outcome.Fail("Captured nothing to revert to, so nothing was unlocked.");

            if (!SnapshotStore.Take(snap, out string writeError))
                return Outcome.Fail("Could not write the baseline (" + writeError + "). Nothing was changed.");

            // Writing a file is not the same as having a usable record: a truncated or
            // unparseable snapshot would leave the profile unlocked with no way back. So it
            // is read from disk and checked before a single value is touched.
            Snapshot verify = SnapshotStore.Load(profile, out string readError);
            if (verify == null || verify.Count != snap.Count)
            {
                string detail = verify == null
                    ? readError
                    : "read back " + verify.Count + " of " + snap.Count + " entries";
                SnapshotStore.Archive(profile);
                return Outcome.Fail("The baseline did not survive a read-back (" + detail
                                    + "). Nothing was unlocked.");
            }

            UnlockAllPlugin.Info("Baseline written and verified: " + snap.Count
                                 + " entries at " + SnapshotStore.SnapshotPath(profile));
            return Outcome.Done("baseline recorded");
        }

        internal Outcome Revert()
        {
            string blocked = Blocker;
            if (blocked != null) return Outcome.Fail(blocked);

            string profile = _p.ProfileKey;

            Snapshot snap = SnapshotStore.Load(profile, out string error);
            if (snap == null)
                return Outcome.Fail("No baseline for " + profile + " (" + error + "), so there is "
                                    + "nothing to revert to.");

            if (!string.IsNullOrEmpty(snap.ProfileId) && snap.ProfileId != profile)
                return Outcome.Fail("That baseline belongs to " + snap.ProfileId + ", not " + profile
                                    + ". Refusing to cross profiles.");

            // Every category with recorded data, not just the ones switched on now: a
            // category turned off after unlocking still has changes on disk to undo.
            int total = 0;
            var parts = new List<string>();
            foreach (UnlockCategory c in UnlockCatalog.All)
            {
                if (!snap.Has(c.Id)) continue;
                int n = 0;
                Safely.Do("Restoring " + c.Id, () => n = c.Restore(_p, snap));
                total += n;
                if (n > 0) parts.Add(c.Label + " " + n);
            }

            _appliedGeneration = -1;
            _p.MarkDirtyAndSave();
            SnapshotStore.Archive(profile);

            string summary = total == 0
                ? "Nothing needed changing; the profile already matched the baseline."
                : "Restored " + total + " entries (" + string.Join(", ", parts) + ").";
            UnlockAllPlugin.Info(summary + " Baseline archived.");
            return Outcome.Done(summary);
        }
    }
}
