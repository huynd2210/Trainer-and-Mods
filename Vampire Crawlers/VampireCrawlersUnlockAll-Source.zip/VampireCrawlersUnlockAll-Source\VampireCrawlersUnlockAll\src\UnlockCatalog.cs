using System.Collections.Generic;
using VampireCrawlersUnlockAll.Categories;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// Everything this mod can unlock, in the order the panel lists it.
    ///
    /// This is the only place that names the categories. Adding one is a new file plus a
    /// line here; the snapshot, the config file, the panel and the apply/revert sequence
    /// pick it up without changes.
    ///
    /// Deliberately absent, because they are preferences rather than progress and inventing
    /// values for them would be putting words in the player's mouth:
    ///
    ///   gem frequencies   how often each gem is offered -- a tuning choice, and there is
    ///                     no "unlocked" value for it, only a preferred one
    ///   sealed gems       which gems you have chosen to stop seeing
    ///   gem rarity costs  written by the jeweller as part of the same preference
    ///   coins             untouched in both directions, so no unlock or revert can cost
    ///                     you a balance you earned
    /// </summary>
    internal static class UnlockCatalog
    {
        internal static readonly IReadOnlyList<UnlockCategory> All = new List<UnlockCategory>
        {
            new CharactersCategory(),
            new AchievementsCategory(),
            new DiscoveredCardsCategory(),
            new DungeonsCategory(),
            new BuildingsCategory(),
            new PowerUpsCategory(),
            new GemSlotsCategory(),
            new TutorialsCategory(),
        };

        /// <summary>The categories the player left switched on.</summary>
        internal static List<UnlockCategory> Active()
        {
            var active = new List<UnlockCategory>();
            foreach (UnlockCategory c in All)
                if (c.Enabled) active.Add(c);
            return active;
        }
    }
}
