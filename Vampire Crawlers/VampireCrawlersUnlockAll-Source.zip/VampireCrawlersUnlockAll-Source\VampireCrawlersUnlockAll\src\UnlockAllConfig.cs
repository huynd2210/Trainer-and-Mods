using BepInEx.Configuration;
using UnityEngine;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// User-editable settings, persisted to
    /// BepInEx/config/nosebleed.vampirecrawlers.unlockall.cfg.
    ///
    /// The per-category switches are generated from the catalog rather than listed here,
    /// so a new category appears in the config file without this class being touched.
    /// </summary>
    internal sealed class UnlockAllConfig
    {
        internal KeyCode KeyPanel { get; private set; }
        internal KeyCode KeyPanelAlt { get; private set; }
        internal KeyCode KeyUnlock { get; private set; }
        internal KeyCode KeyRevert { get; private set; }
        internal bool OpenPanelOnStart { get; private set; }

        internal UnlockAllConfig(ConfigFile file)
        {
            // Deliberately not F-keys: the Vampire Crawlers Trainer, which most people run
            // alongside this, binds F1 to F12.
            KeyPanel = file.Bind("Hotkeys", "Panel", KeyCode.Insert,
                "Show/hide the unlock panel.").Value;
            // Insert is missing, or needs Fn, on a lot of laptop keyboards, and a mod whose
            // only way in is a key you do not have looks identical to a mod that is broken.
            // Backslash is on every layout and the trainer does not bind it.
            KeyPanelAlt = file.Bind("Hotkeys", "PanelAlt", KeyCode.Backslash,
                "A second key that also shows/hides the panel, for keyboards without a "
                + "usable Insert. Set to None to disable.").Value;
            KeyUnlock = file.Bind("Hotkeys", "Unlock", KeyCode.U,
                "Unlock everything. Only while the panel is open, and it asks for the key twice.").Value;
            KeyRevert = file.Bind("Hotkeys", "Revert", KeyCode.R,
                "Put the unlocks back as they were. Only while the panel is open, and it asks "
                + "for the key twice.").Value;

            OpenPanelOnStart = file.Bind("Display", "OpenPanelOnStart", false,
                "Open the panel as soon as the game reaches the menu.").Value;

            foreach (UnlockCategory c in UnlockCatalog.All)
                c.Enabled = file.Bind("Categories", c.Id, true, c.Note).Value;
        }
    }
}
