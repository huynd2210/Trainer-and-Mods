using Nosebleed.Pancake.GameConfig.ShopConfigs;
using Nosebleed.Pancake.MetaProgression;

namespace VampireCrawlersUnlockAll.Categories
{
    /// <summary>Every town building marked visited, so all the shops are open in town.</summary>
    internal sealed class BuildingsCategory : FlagMapCategory<TownBuildingConfig>
    {
        internal override string Id => "Buildings";
        internal override string Label => "Town buildings";
        internal override string Note => "Mark every town building as already visited.";

        protected override Il2CppSystem.Collections.Generic.Dictionary<TownBuildingConfig, bool> Map(ProgressionData d) =>
            d._buildingsVisited;

        protected override string KeyId(TownBuildingConfig key) => ProgressionAccess.IdOf(key);
    }
}
