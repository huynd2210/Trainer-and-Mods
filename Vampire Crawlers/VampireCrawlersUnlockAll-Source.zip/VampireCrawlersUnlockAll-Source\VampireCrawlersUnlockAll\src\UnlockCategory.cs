using System;
using System.Collections.Generic;
using Nosebleed.Pancake.MetaProgression;

namespace VampireCrawlersUnlockAll
{
    /// <summary>How much of a category is unlocked, for the panel's ambient readout.</summary>
    internal struct Tally
    {
        internal int Done;
        internal int Total;

        internal Tally(int done, int total) { Done = done; Total = total; }
        internal bool Complete => Total > 0 && Done >= Total;
        public override string ToString() => Total > 0 ? Done + " / " + Total : "--";
    }

    /// <summary>
    /// One kind of unlockable thing, and everything this mod knows how to do with it:
    /// record it, unlock it, and put it back.
    ///
    /// Adding a new kind of unlock means writing one of these and adding a line to
    /// <see cref="UnlockCatalog"/>. Nothing else in the mod learns about it -- the
    /// snapshot, the config toggles, the panel and the apply/revert sequence all iterate
    /// the catalog, so none of them grows a branch per category.
    ///
    /// Capture/Apply/Restore are always run as three passes over the whole catalog, never
    /// interleaved per category, so the baseline is complete on disk before the first
    /// value changes.
    /// </summary>
    internal abstract class UnlockCategory
    {
        /// <summary>Stable key, used in the snapshot file and the config. Never rename.</summary>
        internal abstract string Id { get; }

        /// <summary>Short name for the panel.</summary>
        internal abstract string Label { get; }

        /// <summary>Sentence for the generated config file, saying what unlocking does.</summary>
        internal abstract string Note { get; }

        /// <summary>Off means this category is left alone entirely: not captured, not changed.</summary>
        internal bool Enabled { get; set; } = true;

        /// <summary>Record the current values into the snapshot.</summary>
        internal abstract void Capture(ProgressionAccess p, Snapshot snap);

        /// <summary>Unlock everything in this category. Returns how many entries changed.</summary>
        internal abstract int Apply(ProgressionAccess p);

        /// <summary>Put the snapshot's values back. Returns how many entries changed.</summary>
        internal abstract int Restore(ProgressionAccess p, Snapshot snap);

        /// <summary>Unlocked-out-of-total, for the panel.</summary>
        internal abstract Tally Count(ProgressionAccess p);
    }

    /// <summary>
    /// Shared behaviour for the categories that are a dictionary of config to value on
    /// ProgressionData: characters, achievements, dungeons, town buildings, power-ups,
    /// gem slots.
    ///
    /// These all walk the dictionary the game itself built during load rather than the
    /// content databases. That is deliberate: the game's own Init methods have already
    /// filtered the databases down to what this build actually ships, so iterating their
    /// output cannot unlock demo-only or disabled content the save was never meant to
    /// contain.
    /// </summary>
    /// <typeparam name="TKey">The config type keying the dictionary.</typeparam>
    /// <typeparam name="TValue">bool for "is it unlocked", int for "how many levels".</typeparam>
    internal abstract class MapCategory<TKey, TValue> : UnlockCategory
        where TValue : struct
    {
        /// <summary>The live dictionary, or null when progression is not built yet.</summary>
        protected abstract Il2CppSystem.Collections.Generic.Dictionary<TKey, TValue> Map(ProgressionData d);

        /// <summary>The config's stable asset id -- the key written to the snapshot.</summary>
        protected abstract string KeyId(TKey key);

        /// <summary>The fully-unlocked value for this entry (all levels, bought, visited).</summary>
        protected abstract TValue UnlockedValue(TKey key);

        /// <summary>Does this value count as unlocked, for the panel's tally?</summary>
        protected abstract bool IsUnlocked(TKey key, TValue value);

        protected abstract void Write(Snapshot snap, string category, string id, TValue value);
        protected abstract TValue Read(string raw, TValue fallback);

        private List<TKey> LiveKeys(
            ProgressionAccess p,
            out Il2CppSystem.Collections.Generic.Dictionary<TKey, TValue> map)
        {
            var data = p.Data;
            map = data == null ? null : Safely.Get(() => Map(data), null);
            return Interop.Keys(map);
        }

        internal override void Capture(ProgressionAccess p, Snapshot snap)
        {
            var keys = LiveKeys(p, out var map);
            if (map == null) return;

            var live = map;
            foreach (TKey key in keys)
            {
                string id = KeyId(key);
                if (string.IsNullOrEmpty(id)) continue;
                TKey k = key;
                TValue current = Safely.Get(() => live[k], default(TValue));
                Write(snap, Id, id, current);
            }
        }

        internal override int Apply(ProgressionAccess p)
        {
            var keys = LiveKeys(p, out var map);
            if (map == null) return 0;

            var live = map;
            int changed = 0;
            foreach (TKey key in keys)
            {
                TKey k = key;
                TValue target = Safely.Get(() => UnlockedValue(k), default(TValue));
                TValue current = Safely.Get(() => live[k], default(TValue));
                if (current.Equals(target)) continue;
                if (Safely.Do("Unlocking " + Id + "/" + KeyId(k), () => live[k] = target)) changed++;
            }
            return changed;
        }

        internal override int Restore(ProgressionAccess p, Snapshot snap)
        {
            var keys = LiveKeys(p, out var map);
            if (map == null) return 0;

            var live = map;
            var recorded = snap.Category(Id);
            int changed = 0;

            foreach (TKey key in keys)
            {
                string id = KeyId(key);
                if (string.IsNullOrEmpty(id)) continue;

                // A key with no recorded value did not exist when the snapshot was taken.
                // Leaving it alone is the only honest option: the baseline never said
                // anything about it, and inventing a value would be a guess written into
                // the player's save.
                if (!recorded.TryGetValue(id, out string raw)) continue;

                TKey k = key;
                TValue current = Safely.Get(() => live[k], default(TValue));
                TValue want = Read(raw, current);
                if (current.Equals(want)) continue;
                if (Safely.Do("Restoring " + Id + "/" + id, () => live[k] = want)) changed++;
            }
            return changed;
        }

        internal override Tally Count(ProgressionAccess p)
        {
            var keys = LiveKeys(p, out var map);
            if (map == null) return new Tally(0, 0);

            var live = map;
            int done = 0;
            foreach (TKey key in keys)
            {
                TKey k = key;
                TValue v = Safely.Get(() => live[k], default(TValue));
                if (Safely.Get(() => IsUnlocked(k, v), false)) done++;
            }
            return new Tally(done, keys.Count);
        }
    }

    /// <summary>A config to bool map: owned, unlocked, or visited.</summary>
    internal abstract class FlagMapCategory<TKey> : MapCategory<TKey, bool>
    {
        protected override bool UnlockedValue(TKey key) => true;
        protected override bool IsUnlocked(TKey key, bool value) => value;
        protected override void Write(Snapshot snap, string category, string id, bool value) =>
            snap.Set(category, id, value);
        protected override bool Read(string raw, bool fallback) => Snapshot.AsBool(raw, fallback);
    }

    /// <summary>A config to int map: how many levels or slots have been bought.</summary>
    internal abstract class LevelMapCategory<TKey> : MapCategory<TKey, int>
    {
        protected override bool IsUnlocked(TKey key, int value) => value >= UnlockedValue(key);
        protected override void Write(Snapshot snap, string category, string id, int value) =>
            snap.Set(category, id, value);
        protected override int Read(string raw, int fallback) => Snapshot.AsInt(raw, fallback);
    }
}
