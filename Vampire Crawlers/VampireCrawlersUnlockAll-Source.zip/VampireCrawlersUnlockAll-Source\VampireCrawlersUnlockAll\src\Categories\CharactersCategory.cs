using Nosebleed.Pancake.GameConfig;
using Nosebleed.Pancake.MetaProgression;

namespace VampireCrawlersUnlockAll.Categories
{
    /// <summary>
    /// Every crawler marked as purchased, so the character select offers all of them.
    ///
    /// This is the shop's ownership flag, not the coin balance -- nothing here spends or
    /// refunds coins, and reverting gives the characters back up exactly as they were.
    /// </summary>
    internal sealed class CharactersCategory : FlagMapCategory<FccConfig>
    {
        internal override string Id => "Characters";
        internal override string Label => "Crawlers";
        internal override string Note => "Mark every crawler as purchased, without spending coins.";

        protected override Il2CppSystem.Collections.Generic.Dictionary<FccConfig, bool> Map(ProgressionData d) =>
            d._charactersPurchased;

        protected override string KeyId(FccConfig key) => ProgressionAccess.IdOf(key);
    }
}
