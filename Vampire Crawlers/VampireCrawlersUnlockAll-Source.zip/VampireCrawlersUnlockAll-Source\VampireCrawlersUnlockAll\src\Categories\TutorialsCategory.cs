namespace VampireCrawlersUnlockAll.Categories
{
    /// <summary>
    /// The two tutorial-complete flags. Small, but they gate menus and first-run prompts,
    /// so an otherwise fully unlocked profile still gets nagged without them.
    ///
    /// Marking a tutorial complete does not skip a tutorial already in progress.
    /// </summary>
    internal sealed class TutorialsCategory : UnlockCategory
    {
        internal override string Id => "Tutorials";
        internal override string Label => "Tutorials";
        internal override string Note => "Mark the tutorial and the wildcard tutorial as complete.";

        private const string Main = "IsTutorialComplete";
        private const string WildCard = "IsWildCardTutorialComplete";

        internal override void Capture(ProgressionAccess p, Snapshot snap)
        {
            var d = p.Data;
            if (d == null) return;
            snap.Set(Id, Main, Safely.Get(() => d._isTutorialComplete, false));
            snap.Set(Id, WildCard, Safely.Get(() => d._isWildCardTutorialComplete, false));
        }

        internal override int Apply(ProgressionAccess p)
        {
            var d = p.Data;
            if (d == null) return 0;

            int changed = 0;
            if (!Safely.Get(() => d._isTutorialComplete, true))
                if (Safely.Do("Completing the tutorial", () => d._isTutorialComplete = true)) changed++;
            if (!Safely.Get(() => d._isWildCardTutorialComplete, true))
                if (Safely.Do("Completing the wildcard tutorial", () => d._isWildCardTutorialComplete = true)) changed++;
            return changed;
        }

        internal override int Restore(ProgressionAccess p, Snapshot snap)
        {
            var d = p.Data;
            if (d == null) return 0;

            var recorded = snap.Category(Id);
            int changed = 0;

            if (recorded.TryGetValue(Main, out string main))
            {
                bool want = Snapshot.AsBool(main, true);
                if (Safely.Get(() => d._isTutorialComplete, want) != want)
                    if (Safely.Do("Restoring the tutorial flag", () => d._isTutorialComplete = want)) changed++;
            }

            if (recorded.TryGetValue(WildCard, out string wild))
            {
                bool want = Snapshot.AsBool(wild, true);
                if (Safely.Get(() => d._isWildCardTutorialComplete, want) != want)
                    if (Safely.Do("Restoring the wildcard tutorial flag", () => d._isWildCardTutorialComplete = want)) changed++;
            }

            return changed;
        }

        internal override Tally Count(ProgressionAccess p)
        {
            var d = p.Data;
            if (d == null) return new Tally(0, 0);

            int done = 0;
            if (Safely.Get(() => d._isTutorialComplete, false)) done++;
            if (Safely.Get(() => d._isWildCardTutorialComplete, false)) done++;
            return new Tally(done, 2);
        }
    }
}
