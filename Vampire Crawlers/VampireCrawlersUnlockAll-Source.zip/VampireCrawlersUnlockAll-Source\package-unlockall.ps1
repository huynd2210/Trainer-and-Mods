# Packages the Vampire Crawlers Unlock All mod for distribution.
#
# Produces three zips -- the two required by the standing BepInEx packaging convention,
# plus the buildable source:
#   VampireCrawlersUnlockAll.zip         mod only  -> for people who already have BepInEx
#   VampireCrawlersUnlockAll-Pack.zip    BepInEx + the mod, self-contained
#   VampireCrawlersUnlockAll-Source.zip  the C# project, buildable against any install
#
# The -Pack exists because getting BepInEx installed (right build, right folder, right
# doorstop) is the single most common failure point; it ships a known-good build so the
# mod-only zip stays self-serve for anyone who already has one installed.
#
# This writes into the same dist\ folder as package.ps1 (the trainer's). It clears only its
# own artifacts, so building one mod never deletes the other's zips.

$ErrorActionPreference = 'Stop'

$Root     = Split-Path -Parent $MyInvocation.MyCommand.Path
$ModName  = 'VampireCrawlersUnlockAll'
$Project  = Join-Path $Root $ModName
# The install to build against -- assumed to sit next to this folder. Edit if yours differs.
$GameDir  = Join-Path (Split-Path -Parent $Root) 'game'
$Out      = Join-Path $Root 'dist'
$Staging  = Join-Path $Root "_staging-unlockall"

# BepInEx build bundled into the -Pack zip. Must match what the mod was built against.
$BepInExZip = Join-Path $Root 'bepinex\BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.788.zip'

Write-Host "==> Building $ModName (Release)"
Push-Location $Project
dotnet build -c Release -o build --nologo -p:GameDir="$GameDir" | Out-Null
Pop-Location

$Dll = Join-Path $Project "build\$ModName.dll"
if (-not (Test-Path $Dll)) { throw "build produced no DLL at $Dll" }

$Readme = Join-Path $Project 'README.md'

# Staging is ours alone; dist is shared, so only this mod's zips are cleared from it.
if (Test-Path $Staging) { Remove-Item $Staging -Recurse -Force }
New-Item -ItemType Directory -Path $Staging -Force | Out-Null
New-Item -ItemType Directory -Path $Out -Force | Out-Null
Get-ChildItem $Out -Filter "$ModName*.zip" -ErrorAction SilentlyContinue | Remove-Item -Force

# ---------------------------------------------------------------- mod-only zip
Write-Host "==> Staging mod-only zip"
$ModStage = Join-Path $Staging 'mod'
$ModPlugins = Join-Path $ModStage 'BepInEx\plugins'
New-Item -ItemType Directory -Path $ModPlugins -Force | Out-Null
Copy-Item $Dll    (Join-Path $ModPlugins "$ModName.dll") -Force
Copy-Item $Readme (Join-Path $ModPlugins "$ModName-README.md") -Force

$ModZip = Join-Path $Out "$ModName.zip"
Compress-Archive -Path (Join-Path $ModStage '*') -DestinationPath $ModZip -Force
Write-Host "    $ModZip"

# ------------------------------------------------------------------- pack zip
if (Test-Path $BepInExZip) {
  Write-Host "==> Staging self-contained pack (BepInEx + mod)"
  $PackStage = Join-Path $Staging 'pack'
  New-Item -ItemType Directory -Path $PackStage -Force | Out-Null

  Expand-Archive -Path $BepInExZip -DestinationPath $PackStage -Force

  $PackPlugins = Join-Path $PackStage 'BepInEx\plugins'
  New-Item -ItemType Directory -Path $PackPlugins -Force | Out-Null
  Copy-Item $Dll    (Join-Path $PackPlugins "$ModName.dll") -Force
  Copy-Item $Readme (Join-Path $PackPlugins "$ModName-README.md") -Force

  # Each pack ships an INSTALL.txt covering only the mods it contains.
  $install = @"
Vampire Crawlers -- Unlock All -- self-contained pack
=====================================================

Contains BepInEx 6 (IL2CPP, win-x64, build be.788) and the Unlock All mod.
Nothing else needs installing.

INSTALL
  1. Extract everything in this zip into your Vampire Crawlers game folder --
     the folder that contains "Vampire Crawlers.exe".
     You should end up with "winhttp.dll" and a "BepInEx" folder next to the exe.
  2. Run the game once and wait. The first launch is slow (a minute or more): BepInEx
     has to dump the game's assemblies before any mod can load. The window may look
     frozen -- let it finish.
  3. In game, press Insert for the panel. It works from the main menu.

KEYS
  Insert  show/hide the panel
  U       unlock everything   (press U again to confirm)
  R       revert to the state you had before unlocking (press R again to confirm)
  Esc     cancel a pending confirm, or close the panel

  Keys and per-category switches:
  BepInEx\config\nosebleed.vampirecrawlers.unlockall.cfg (written on first launch).

REVERTING
  Before it changes anything, the first unlock copies your save files aside and records
  every value it is about to change, then reads that record back to check it. If the
  record cannot be written and verified, nothing is unlocked at all.

  Revert puts back the unlock state you had at that moment -- not a fresh save. Coins,
  metrics and run progress are never touched in either direction, and progress you make
  after unlocking is kept.

  Both live in: BepInEx\VampireCrawlersUnlockAll\

ADDING MORE MODS
  Drop any other mod's BepInEx\plugins\*.dll into this install's BepInEx\plugins.
  This mod avoids F1-F12 so it can sit alongside the Vampire Crawlers Trainer.

UNINSTALL
  Delete winhttp.dll, doorstop_config.ini, .doorstop_version, changelog.txt, and the
  BepInEx and dotnet folders. The game itself is untouched.

  Uninstalling does NOT revert anything -- unlocks are written into your save. Revert
  first (R in the panel) if you want your old progress back.

TROUBLESHOOTING
  No panel? Open BepInEx\LogOutput.log and look for "Vampire Crawlers Unlock All".
  If it is not listed, BepInEx did not load -- confirm winhttp.dll sits beside the exe.
"@
  Set-Content -Path (Join-Path $PackStage 'INSTALL.txt') -Value $install -Encoding utf8

  $PackZip = Join-Path $Out "$ModName-Pack.zip"
  Compress-Archive -Path (Join-Path $PackStage '*') -DestinationPath $PackZip -Force
  Write-Host "    $PackZip"
} else {
  Write-Warning "BepInEx zip not found at $BepInExZip -- skipping the -Pack zip."
  Write-Warning "Place the BepInEx IL2CPP win-x64 build there and re-run to produce it."
}

# ---------------------------------------------------------------- source zip
Write-Host "==> Staging source zip"
$SrcStage = Join-Path $Staging "src\$ModName-Source"
New-Item -ItemType Directory -Path $SrcStage -Force | Out-Null

$ProjStage = Join-Path $SrcStage $ModName
New-Item -ItemType Directory -Path $ProjStage -Force | Out-Null
Copy-Item (Join-Path $Project 'src')             $ProjStage -Recurse -Force
Copy-Item (Join-Path $Project "$ModName.csproj") $ProjStage -Force
Copy-Item $Readme                                $ProjStage -Force

Copy-Item (Join-Path $Root 'package-unlockall.ps1') $SrcStage -Force

# The -Pack zip's BepInEx build is not shipped in source form; leave a note where it goes.
$BepStage = Join-Path $SrcStage 'bepinex'
New-Item -ItemType Directory -Path $BepStage -Force | Out-Null
Set-Content -Path (Join-Path $BepStage 'PLACE-BEPINEX-ZIP-HERE.txt') -Encoding utf8 -Value @'
package-unlockall.ps1 bundles a BepInEx build into VampireCrawlersUnlockAll-Pack.zip. That
build is not redistributed in this source archive.

To produce the -Pack zip yourself, download the BepInEx 6 IL2CPP win-x64 build and drop the
zip in this folder under exactly this name:

  BepInEx-Unity.IL2CPP-win-x64-6.0.0-be.788.zip

  https://builds.bepinex.dev/projects/bepinex_be

Without it, package-unlockall.ps1 still builds the mod-only and -Source zips and just warns
about this one.
'@

Set-Content -Path (Join-Path $SrcStage 'BUILDING.txt') -Encoding utf8 -Value @'
Vampire Crawlers Unlock All -- source
=====================================

Layout
  VampireCrawlersUnlockAll\src\        the mod's C# sources
  VampireCrawlersUnlockAll\*.csproj    the project
  VampireCrawlersUnlockAll\README.md   what it does, keys, how reverting works
  package-unlockall.ps1                builds Release and writes the release zips
  bepinex\                             where the bundled BepInEx build goes (see note there)

Requirements
  .NET 8 SDK (the project targets net6.0; the SDK builds it).
  A Vampire Crawlers install with BepInEx 6 IL2CPP installed that has been LAUNCHED AT
  LEAST ONCE -- that first launch generates BepInEx\interop, which this project references
  directly instead of NuGet packages.

Build
  cd VampireCrawlersUnlockAll
  dotnet build -c Release -o build -p:GameDir="D:\Games\Vampire Crawlers"

  GameDir is the folder containing "Vampire Crawlers.exe". It is also read from an
  environment variable of the same name; the fallback baked into the csproj is the author's
  own path, so set it one way or the other. A wrong path or a missing interop dump fails the
  build with a message saying which, not a wall of type errors.

  Then copy build\VampireCrawlersUnlockAll.dll into <game>\BepInEx\plugins\.

Release
  powershell -ExecutionPolicy Bypass -File package-unlockall.ps1

  Writes dist\VampireCrawlersUnlockAll.zip, -Pack.zip and -Source.zip. It shares dist\ with
  the trainer's package.ps1 but only clears its own artifacts.

Where the code is
  UnlockCatalog.cs     the list of categories -- the only place they are named
  UnlockCategory.cs    the category contract, and the shared dictionary/set behaviour
  Categories\          one file per kind of unlock
  UnlockEngine.cs      the order of operations for unlock and revert, and its safety gates
  Snapshot.cs          the baseline file format
  SnapshotStore.cs     where baselines and save backups live, and the write rules
'@

$SrcZip = Join-Path $Out "$ModName-Source.zip"
Compress-Archive -Path (Join-Path $Staging 'src\*') -DestinationPath $SrcZip -Force
Write-Host "    $SrcZip"

Remove-Item $Staging -Recurse -Force
Write-Host ""
Write-Host "==> Done. Artifacts in $Out"
Get-ChildItem $Out -Filter "$ModName*.zip" | Select-Object Name, @{n='MB';e={[math]::Round($_.Length/1MB,2)}} | Format-Table -AutoSize
