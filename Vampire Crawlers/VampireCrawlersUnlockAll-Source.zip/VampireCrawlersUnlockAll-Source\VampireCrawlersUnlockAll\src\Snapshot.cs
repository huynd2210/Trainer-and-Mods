using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// The record of what was unlocked before this mod touched anything -- the thing that
    /// makes "revert" mean "back to where I was", not "back to a fresh save".
    ///
    /// Format is one tab-separated line per entry, "category  key  value", under a few
    /// "#" header lines. Plain text on purpose: the file is the user's safety net, so it
    /// has to be readable and hand-fixable without this mod, and it has to survive being
    /// written by a process that might be killed mid-write. Keys are config asset ids,
    /// which are bare identifiers -- no tabs or newlines to escape.
    ///
    /// A snapshot is written exactly once, on the first unlock, and kept until a revert
    /// consumes it. Re-writing it on a second unlock would capture the already-unlocked
    /// state and quietly destroy the only copy of the real baseline; that is the single
    /// worst thing this mod could do, so <see cref="SnapshotStore.Take"/> refuses to
    /// overwrite an existing file.
    /// </summary>
    internal sealed class Snapshot
    {
        /// <summary>
        /// Bumped to 2 to make every version-1 file unreadable, on purpose.
        ///
        /// Version 1 was written by a build that could capture the title screen's blank
        /// progression and call it a baseline -- restoring from one of those would wipe the
        /// profile it claimed to protect. There is no way to tell a good v1 file from a bad
        /// one after the fact, so none of them are trusted.
        /// </summary>
        internal const int FormatVersion = 2;

        internal string ProfileId = "";
        internal string TakenUtc = "";

        /// <summary>Format version read from the file; 0 when the header was missing.</summary>
        internal int Version = FormatVersion;

        // category -> key -> value
        private readonly Dictionary<string, Dictionary<string, string>> _entries =
            new Dictionary<string, Dictionary<string, string>>(StringComparer.Ordinal);

        internal int Count
        {
            get
            {
                int n = 0;
                foreach (var c in _entries.Values) n += c.Count;
                return n;
            }
        }

        internal void Set(string category, string key, string value)
        {
            if (string.IsNullOrEmpty(category) || string.IsNullOrEmpty(key)) return;
            if (!_entries.TryGetValue(category, out var bucket))
            {
                bucket = new Dictionary<string, string>(StringComparer.Ordinal);
                _entries[category] = bucket;
            }
            bucket[key] = value ?? "";
        }

        internal void Set(string category, string key, bool value) =>
            Set(category, key, value ? "1" : "0");

        internal void Set(string category, string key, int value) =>
            Set(category, key, value.ToString(CultureInfo.InvariantCulture));

        /// <summary>Entries recorded for a category; empty when the category was not captured.</summary>
        internal IReadOnlyDictionary<string, string> Category(string category)
        {
            if (_entries.TryGetValue(category, out var bucket)) return bucket;
            return EmptyCategory;
        }

        internal bool Has(string category) =>
            _entries.TryGetValue(category, out var b) && b.Count > 0;

        private static readonly Dictionary<string, string> EmptyCategory =
            new Dictionary<string, string>(StringComparer.Ordinal);

        // ---- value readers used by the categories when restoring ----------------------

        internal static bool AsBool(string raw, bool fallback)
        {
            if (raw == "1") return true;
            if (raw == "0") return false;
            return fallback;
        }

        internal static int AsInt(string raw, int fallback)
        {
            if (int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out int v)) return v;
            return fallback;
        }

        // ---- serialisation ------------------------------------------------------------

        internal string Serialise()
        {
            var sb = new StringBuilder();
            sb.Append("#vampire-crawlers-unlock-all\tsnapshot\t")
              .Append(FormatVersion.ToString(CultureInfo.InvariantCulture)).Append('\n');
            sb.Append("#profile\t").Append(ProfileId).Append('\n');
            sb.Append("#taken\t").Append(TakenUtc).Append('\n');
            sb.Append("#\tThe unlock state this profile had before the mod changed anything.\n");
            sb.Append("#\tReverting restores exactly these values. Do not hand-edit unless you\n");
            sb.Append("#\tmean to change what a revert will produce.\n");

            // Sorted so the file diffs cleanly between runs and is easy to read.
            var categories = new List<string>(_entries.Keys);
            categories.Sort(StringComparer.Ordinal);
            foreach (string cat in categories)
            {
                var bucket = _entries[cat];
                var keys = new List<string>(bucket.Keys);
                keys.Sort(StringComparer.Ordinal);
                foreach (string k in keys)
                    sb.Append(cat).Append('\t').Append(k).Append('\t').Append(bucket[k]).Append('\n');
            }
            return sb.ToString();
        }

        internal static Snapshot Parse(string text)
        {
            // Starts at 0, not the current version: a file with no version header is from
            // before versioning existed, and must not be mistaken for a current one.
            var snap = new Snapshot { Version = 0 };
            if (string.IsNullOrEmpty(text)) return snap;

            foreach (string rawLine in text.Split('\n'))
            {
                string line = rawLine.TrimEnd('\r');
                if (line.Length == 0) continue;

                if (line[0] == '#')
                {
                    string[] head = line.Split('\t');
                    if (head.Length >= 2 && head[0] == "#profile") snap.ProfileId = head[1];
                    else if (head.Length >= 2 && head[0] == "#taken") snap.TakenUtc = head[1];
                    else if (head.Length >= 3 && head[0] == "#vampire-crawlers-unlock-all")
                        snap.Version = AsInt(head[2], 0);
                    continue;
                }

                string[] parts = line.Split('\t');
                if (parts.Length < 3) continue;
                snap.Set(parts[0], parts[1], parts[2]);
            }
            return snap;
        }
    }
}
