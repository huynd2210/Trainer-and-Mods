using BepInEx;
using BepInEx.Logging;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using Il2CppInterop.Runtime.Injection;
using UnityEngine;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// BepInEx entry point. Registers the behaviour with the il2cpp domain and parks it on
    /// a hidden, scene-persistent GameObject.
    /// </summary>
    [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
    public class UnlockAllPlugin : BasePlugin
    {
        public const string PluginGuid = "nosebleed.vampirecrawlers.unlockall";
        public const string PluginName = "Vampire Crawlers Unlock All";
        public const string PluginVersion = "1.1.0";

        private static ManualLogSource _log;

        internal static void Info(string msg) => _log?.LogInfo(msg);
        internal static void Warn(string msg) => _log?.LogWarning(msg);

        public override void Load()
        {
            _log = Log;

            var cfg = new UnlockAllConfig(Config);

            // Must be in place before the title screen finishes loading: it is the only
            // way to tell a loaded profile from the blank progression the game boots with.
            ProgressionLoadWatcher.Install(new Harmony(PluginGuid));

            ClassInjector.RegisterTypeInIl2Cpp<UnlockAllBehaviour>();

            var host = new GameObject("VampireCrawlersUnlockAll");
            Object.DontDestroyOnLoad(host);
            host.hideFlags = HideFlags.HideAndDontSave;

            var behaviour = host.AddComponent<UnlockAllBehaviour>();
            behaviour.Configure(cfg);

            Info($"{PluginName} {PluginVersion} loaded -- {UnlockCatalog.Active().Count} of "
                 + $"{UnlockCatalog.All.Count} categories switched on. "
                 + $"Press {Hotkeys.Name(cfg.KeyPanel)} or {Hotkeys.Name(cfg.KeyPanelAlt)} in game for the panel.");
            Info("Baselines and save backups: " + SnapshotStore.Root);
        }
    }
}
