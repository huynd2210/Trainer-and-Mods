using System.Collections.Generic;
using Nosebleed.Pancake.GameConfig.ShopConfigs.PowerUps;
using Nosebleed.Pancake.MetaProgression;

namespace VampireCrawlersUnlockAll.Categories
{
    /// <summary>
    /// Every power-up bought up to its last level, and switched on.
    ///
    /// Strictly this is "buy everything" rather than "unlock everything" -- power-ups are
    /// not gated, they are purchased -- but a shop full of affordable upgrades is what
    /// people mean by unlocking the shop, so it is included and can be switched off on its
    /// own in the config.
    ///
    /// Two things worth knowing. The levels are written directly, so no coins are spent;
    /// the game's CoinsSpentAtPowerupShop counter is left alone, which means the shop's
    /// "refund all power-ups" button would pay out for levels that were never paid for.
    /// And the enabled flags are a player preference, not progress: switching them all on
    /// is the point of the category, and the snapshot puts your own choices back on revert.
    /// </summary>
    internal sealed class PowerUpsCategory : LevelMapCategory<PowerUpConfig>
    {
        internal override string Id => "PowerUpLevels";
        internal override string Label => "Power-ups";
        internal override string Note =>
            "Raise every power-up to its highest level and switch it on, without spending "
            + "coins. Note that the shop's refund button would then pay out for levels you "
            + "never bought.";

        protected override Il2CppSystem.Collections.Generic.Dictionary<PowerUpConfig, int> Map(ProgressionData d) =>
            d._powerUpLevelsUnlocked;

        protected override string KeyId(PowerUpConfig key) => ProgressionAccess.IdOf(key);

        /// <summary>
        /// The shop sells availableLevels levels on top of baseLevel, so the top of the
        /// track is their sum. Read from the config rather than assumed, because the two
        /// differ per power-up.
        /// </summary>
        protected override int UnlockedValue(PowerUpConfig key) =>
            Safely.Get(() => key.baseLevel + key.availableLevels, 0);

        // ---- the enabled flags ride along with the levels ------------------------------
        //
        // They live in a second dictionary keyed the same way. Keeping them in this
        // category rather than inventing a separate one means a single switch covers "the
        // power-up shop", which is how a player thinks about it. Snapshot keys are prefixed
        // so the two key spaces cannot collide in the file.

        private const string EnabledPrefix = "enabled:";

        private static Il2CppSystem.Collections.Generic.Dictionary<PowerUpConfig, bool> EnabledMap(ProgressionAccess p)
        {
            var d = p.Data;
            return d == null ? null : Safely.Get(() => d._powerUpsEnabled, null);
        }

        internal override void Capture(ProgressionAccess p, Snapshot snap)
        {
            base.Capture(p, snap);

            var map = EnabledMap(p);
            if (map == null) return;
            foreach (PowerUpConfig key in Interop.Keys(map))
            {
                string id = KeyId(key);
                if (string.IsNullOrEmpty(id)) continue;
                PowerUpConfig k = key;
                snap.Set(Id, EnabledPrefix + id, Safely.Get(() => map[k], false));
            }
        }

        internal override int Apply(ProgressionAccess p)
        {
            int changed = base.Apply(p);

            var map = EnabledMap(p);
            if (map == null) return changed;
            foreach (PowerUpConfig key in Interop.Keys(map))
            {
                PowerUpConfig k = key;
                if (Safely.Get(() => map[k], false)) continue;
                if (Safely.Do("Enabling power-up " + KeyId(k), () => map[k] = true)) changed++;
            }
            return changed;
        }

        internal override int Restore(ProgressionAccess p, Snapshot snap)
        {
            int changed = base.Restore(p, snap);

            var map = EnabledMap(p);
            if (map == null) return changed;

            var recorded = snap.Category(Id);
            foreach (PowerUpConfig key in Interop.Keys(map))
            {
                string id = KeyId(key);
                if (string.IsNullOrEmpty(id)) continue;
                if (!recorded.TryGetValue(EnabledPrefix + id, out string raw)) continue;

                PowerUpConfig k = key;
                bool current = Safely.Get(() => map[k], false);
                bool want = Snapshot.AsBool(raw, current);
                if (current == want) continue;
                if (Safely.Do("Restoring power-up switch " + id, () => map[k] = want)) changed++;
            }
            return changed;
        }
    }
}
