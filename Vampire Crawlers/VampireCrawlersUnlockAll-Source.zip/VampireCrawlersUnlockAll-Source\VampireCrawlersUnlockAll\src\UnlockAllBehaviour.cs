using System;
using System.Text;
using Il2CppInterop.Runtime.Attributes;
using UnityEngine;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// The mod's only MonoBehaviour: reads input, refreshes what the panel shows, and runs
    /// the two operations.
    ///
    /// The division of labour with <see cref="Panel"/> is a safety rule, not tidiness.
    /// OnGUI runs several times per frame -- once per input event, plus layout and repaint
    /// -- and during a scene change the game objects it would be reading are mid-
    /// destruction. Touching a freed il2cpp object is a native access violation that no
    /// try/catch can intercept: the process simply dies. So every read of game state
    /// happens here, once, from Update, and the panel only ever renders values already
    /// copied into plain managed fields.
    ///
    /// Update and OnGUI are the only methods Unity calls, so everything else carries
    /// [HideFromIl2Cpp]: a method taking a managed type or returning a struct cannot be
    /// marshalled into the il2cpp domain, and leaving them visible only produces warnings
    /// at injection time about methods that were never meant to be injected.
    /// </summary>
    internal sealed class UnlockAllBehaviour : MonoBehaviour
    {
        /// <summary>Required by Il2CppInterop for an injected type.</summary>
        public UnlockAllBehaviour(IntPtr ptr) : base(ptr) { }

        private UnlockAllConfig _cfg;
        private ProgressionAccess _progression;
        private UnlockEngine _engine;
        private readonly Panel _panel = new Panel();

        // A confirm that never lapses is a trap waiting for the next keypress, so it does.
        private const float ConfirmWindow = 5f;
        private const float StatusDuration = 12f;

        private string _pending = "";
        private float _pendingUntil;
        private float _statusUntil;
        private bool _describedOnce;

        // Refreshing the tallies walks several il2cpp dictionaries, which is far too much
        // to do every frame for a panel that is usually closed.
        private const float RefreshInterval = 0.5f;
        private float _nextRefresh;

        [HideFromIl2Cpp]
        internal void Configure(UnlockAllConfig cfg)
        {
            _cfg = cfg;
            _progression = new ProgressionAccess();
            _engine = new UnlockEngine(_progression);
            _panel.Visible = cfg.OpenPanelOnStart;
            _panel.KeyHint = Hotkeys.Name(cfg.KeyUnlock) + " unlock everything    "
                           + Hotkeys.Name(cfg.KeyRevert) + " revert    Esc close";
        }

        private void Update()
        {
            if (_cfg == null) return;

            try
            {
                Hotkeys.LogBackendsOnce();
                ReadInput();
                if (_panel.Visible) Refresh();
            }
            catch (Exception ex)
            {
                UnlockAllPlugin.Warn("Update failed: " + ex.GetType().Name + ": " + ex.Message);
            }
            finally
            {
                Hotkeys.EndFrame();
            }
        }

        [HideFromIl2Cpp]
        private void ReadInput()
        {
            if (Hotkeys.Down(_cfg.KeyPanel) || Hotkeys.Down(_cfg.KeyPanelAlt))
            {
                _panel.Visible = !_panel.Visible;
                ClearPending();
                UnlockAllPlugin.Info("Panel " + (_panel.Visible ? "opened" : "closed") + ".");
                if (_panel.Visible)
                {
                    _nextRefresh = 0f;
                    Refresh();
                    DescribeOnce();
                }
            }

            if (!_panel.Visible) return;

            if (Hotkeys.Down(KeyCode.Escape))
            {
                if (!string.IsNullOrEmpty(_pending)) ClearPending();
                else _panel.Visible = false;
                return;
            }

            if (Time.unscaledTime > _pendingUntil) ClearPending();

            if (Hotkeys.Down(_cfg.KeyUnlock)) Arm("unlock", Hotkeys.Name(_cfg.KeyUnlock), true);
            else if (Hotkeys.Down(_cfg.KeyRevert)) Arm("revert", Hotkeys.Name(_cfg.KeyRevert), false);
        }

        /// <summary>
        /// First press arms, second press within the window commits. Both operations
        /// rewrite the save, so neither happens on a single keystroke.
        /// </summary>
        [HideFromIl2Cpp]
        private void Arm(string id, string keyName, bool isUnlock)
        {
            if (_pending != id)
            {
                _pending = id;
                _panel.Pending = keyName;
                _pendingUntil = Time.unscaledTime + ConfirmWindow;
                UnlockAllPlugin.Info("Armed " + id + "; press " + keyName + " again within "
                                     + ConfirmWindow + "s to confirm.");
                return;
            }

            ClearPending();
            UnlockAllPlugin.Info("Confirmed " + id + "; running it now.");

            Outcome result = isUnlock ? RunUnlock() : RunRevert();

            // Every outcome is logged, not just the good ones. A failure that only ever
            // appeared in the panel for twelve seconds is a failure nobody can diagnose
            // afterwards.
            if (result.Ok) UnlockAllPlugin.Info(id + " finished: " + result.Message);
            else UnlockAllPlugin.Warn(id + " did nothing: " + result.Message);

            _panel.Status = result.Message;
            _panel.StatusIsError = !result.Ok;
            _statusUntil = Time.unscaledTime + StatusDuration;
            _nextRefresh = 0f;
        }

        [HideFromIl2Cpp]
        private void ClearPending()
        {
            _pending = "";
            _panel.Pending = "";
            _pendingUntil = 0f;
        }

        [HideFromIl2Cpp]
        private Outcome RunUnlock()
        {
            try { return _engine.Unlock(); }
            catch (Exception ex)
            {
                UnlockAllPlugin.Warn("Unlock threw: " + ex);
                return Outcome.Fail("Unlock failed: " + ex.GetType().Name + ". See the BepInEx log.");
            }
        }

        [HideFromIl2Cpp]
        private Outcome RunRevert()
        {
            try { return _engine.Revert(); }
            catch (Exception ex)
            {
                UnlockAllPlugin.Warn("Revert threw: " + ex);
                return Outcome.Fail("Revert failed: " + ex.GetType().Name + ". See the BepInEx log.");
            }
        }

        /// <summary>
        /// Log what the mod can actually see, the first time the panel opens.
        ///
        /// This is the line that answers "it did nothing" without another round trip: if a
        /// category reports zero of zero, the dictionary behind it could not be read, and
        /// that is a different bug from an unlock that ran and changed nothing.
        /// </summary>
        [HideFromIl2Cpp]
        private void DescribeOnce()
        {
            if (_describedOnce) return;
            _describedOnce = true;

            var sb = new StringBuilder();
            string blocker = Safely.Get(() => _engine.Blocker, null);
            sb.Append("Visible state on profile ").Append(Safely.Get(() => _progression.ProfileKey, "?"))
              .Append(blocker == null ? " (ready): " : " (BLOCKED: " + blocker + "): ");
            foreach (UnlockCategory c in UnlockCatalog.All)
            {
                Tally t = Safely.Get(() => c.Count(_progression), new Tally(0, 0));
                sb.Append(c.Id).Append(' ').Append(t.Done).Append('/').Append(t.Total)
                  .Append(c.Enabled ? "" : " (off)").Append("   ");
            }
            UnlockAllPlugin.Info(sb.ToString());
            UnlockAllPlugin.Info("Baseline for this profile: "
                                 + (_engine.IsUnlocked ? "present at " : "none yet at ") + _engine.SnapshotPath);
        }

        /// <summary>Copy everything the panel needs out of il2cpp, once.</summary>
        [HideFromIl2Cpp]
        private void Refresh()
        {
            if (Time.unscaledTime < _nextRefresh) return;
            _nextRefresh = Time.unscaledTime + RefreshInterval;

            if (!string.IsNullOrEmpty(_panel.Status) && Time.unscaledTime > _statusUntil)
                _panel.Status = "";

            _panel.ProgressionReady = _progression.Ready;
            _panel.Profile = Safely.Get(() => _progression.ProfileKey, "--");
            _panel.Unlocked = Safely.Get(() => _engine.IsUnlocked, false);
            _panel.NeedsReapply = Safely.Get(() => _engine.NeedsReapply, false);
            _panel.Blocker = Safely.Get(() => _engine.Blocker, null) ?? "";

            _panel.Rows.Clear();
            foreach (UnlockCategory c in UnlockCatalog.All)
            {
                Tally t = _panel.ProgressionReady
                    ? Safely.Get(() => c.Count(_progression), new Tally(0, 0))
                    : new Tally(0, 0);

                _panel.Rows.Add(new Panel.Row
                {
                    Label = c.Label,
                    Tally = _panel.ProgressionReady ? t.ToString() : "--",
                    Complete = t.Complete,
                    Enabled = c.Enabled,
                });
            }
        }

        private void OnGUI()
        {
            if (_cfg == null) return;

            // IMGUI's event stream is the primary hotkey source; capture keys before any
            // early-out, so the bindings keep working even if drawing turns out to be
            // unavailable in this build.
            Event e = Event.current;
            if (e != null && e.type == EventType.KeyDown) Hotkeys.NoteGuiKey(e.keyCode);

            try
            {
                // The game's own UI is drawn by uGUI over a full-screen canvas. Without an
                // explicit depth the panel can end up underneath it and simply never be
                // seen -- which looks exactly like the mod doing nothing.
                try { GUI.depth = -1000; } catch (Exception) { }

                Painter.Resolve();
                _panel.Draw();
            }
            catch (Exception)
            {
                // A throw here would repeat for every event of every frame. The panel not
                // drawing is survivable; a log flood is not.
            }
        }
    }
}
