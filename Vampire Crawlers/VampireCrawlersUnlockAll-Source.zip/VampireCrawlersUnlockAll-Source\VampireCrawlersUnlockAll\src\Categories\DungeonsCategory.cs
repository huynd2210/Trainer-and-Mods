using Nosebleed.Pancake.GameConfig;
using Nosebleed.Pancake.MetaProgression;

namespace VampireCrawlersUnlockAll.Categories
{
    /// <summary>Every dungeon marked visited, so none of them reads as new or hidden.</summary>
    internal sealed class DungeonsCategory : FlagMapCategory<DungeonConfig>
    {
        internal override string Id => "Dungeons";
        internal override string Label => "Dungeons";
        internal override string Note => "Mark every dungeon as already visited.";

        protected override Il2CppSystem.Collections.Generic.Dictionary<DungeonConfig, bool> Map(ProgressionData d) =>
            d._dungeonsVisited;

        protected override string KeyId(DungeonConfig key) => ProgressionAccess.IdOf(key);
    }
}
