using System;
using System.Globalization;
using System.IO;
using System.Text;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// Where snapshots and save backups live on disk, and the rules about writing them.
    ///
    /// Both sit under BepInEx\VampireCrawlersUnlockAll\ next to the game, not in the
    /// game's own save folder: a stray file there is one more thing the game's save system
    /// can trip over, and keeping the safety net out of the thing it is protecting is the
    /// whole point.
    /// </summary>
    internal static class SnapshotStore
    {
        private static string _root;

        /// <summary>BepInEx\VampireCrawlersUnlockAll, created on demand.</summary>
        internal static string Root
        {
            get
            {
                if (_root == null)
                {
                    string bep = Safely.Get(() => BepInEx.Paths.BepInExRootPath, null);
                    if (string.IsNullOrEmpty(bep))
                        bep = Path.Combine(Directory.GetCurrentDirectory(), "BepInEx");
                    _root = Path.Combine(bep, "VampireCrawlersUnlockAll");
                }
                try { Directory.CreateDirectory(_root); } catch (Exception) { }
                return _root;
            }
        }

        internal static string SnapshotPath(string profileId) =>
            Path.Combine(Root, "snapshot-" + Sanitise(profileId) + ".tsv");

        /// <summary>True when this profile is currently unlocked by the mod.</summary>
        internal static bool Exists(string profileId) =>
            Safely.Get(() => File.Exists(SnapshotPath(profileId)), false);

        /// <summary>
        /// Write the baseline for a profile. Refuses if one is already there -- see the note
        /// on <see cref="Snapshot"/> for why overwriting would be the worst possible bug.
        /// Writes to a temp file and moves it into place, so a kill mid-write cannot leave a
        /// half-written baseline behind.
        /// </summary>
        internal static bool Take(Snapshot snap, out string error)
        {
            error = null;
            string path = SnapshotPath(snap.ProfileId);

            if (File.Exists(path))
            {
                error = "a snapshot already exists at " + path;
                return false;
            }

            try
            {
                string tmp = path + ".writing";
                File.WriteAllText(tmp, snap.Serialise(), new UTF8Encoding(false));
                File.Move(tmp, path);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.GetType().Name + ": " + ex.Message;
                return false;
            }
        }

        internal static Snapshot Load(string profileId, out string error)
        {
            error = null;
            string path = SnapshotPath(profileId);
            try
            {
                if (!File.Exists(path)) { error = "no snapshot at " + path; return null; }

                Snapshot snap = Snapshot.Parse(File.ReadAllText(path, Encoding.UTF8));

                // A baseline in an older format is refused rather than read best-effort.
                // Version 1 files could hold the title screen's blank progression, and
                // restoring one would wipe the profile it was meant to protect -- see the
                // note on Snapshot.FormatVersion.
                if (snap.Version != Snapshot.FormatVersion)
                {
                    error = "the baseline at " + path + " is format version " + snap.Version
                          + ", not " + Snapshot.FormatVersion + "; refusing to restore from it";
                    return null;
                }
                return snap;
            }
            catch (Exception ex)
            {
                error = ex.GetType().Name + ": " + ex.Message;
                return null;
            }
        }

        /// <summary>
        /// Retire a consumed snapshot by renaming it, never by deleting it. If the restore
        /// turns out to have gone wrong, the file that says what the values should have been
        /// is the only way to find out -- deleting it would turn a recoverable mistake into
        /// an unanswerable one.
        /// </summary>
        internal static void Archive(string profileId)
        {
            string path = SnapshotPath(profileId);
            Safely.Do("Archiving the snapshot", () =>
            {
                if (!File.Exists(path)) return;
                File.Move(path, path + ".reverted-" + Stamp());
            });
        }

        /// <summary>
        /// Copy the profile's save file aside before the first unlock.
        ///
        /// The structured snapshot is the precise way back; this is the blunt one. If this
        /// mod's understanding of the progression model is wrong in some way nobody has hit
        /// yet, a byte copy of the save still puts the player back exactly where they were.
        /// Returns the folder written, or null on failure -- and failure is fatal to the
        /// unlock, by design.
        /// </summary>
        internal static string BackupSave(string profileId, out string error)
        {
            error = null;
            try
            {
                string saveDir = ProgressionAccess.SaveFolder;
                if (string.IsNullOrEmpty(saveDir) || !Directory.Exists(saveDir))
                {
                    error = "save folder not found at " + (saveDir ?? "<null>");
                    return null;
                }

                string dest = Path.Combine(Root, "save-backup-" + Sanitise(profileId) + "-" + Stamp());
                Directory.CreateDirectory(dest);

                // The exact source path is logged, not assumed. Tooling outside the game can
                // see a different AppData than the game does -- a packaged/containerised
                // process gets a virtualised view -- so "the save folder" is only
                // unambiguous when the game itself says which one it used.
                UnlockAllPlugin.Info("Save folder in use: " + saveDir);

                int copied = 0;
                foreach (string file in Directory.GetFiles(saveDir, "*.save"))
                {
                    var info = new FileInfo(file);
                    File.Copy(file, Path.Combine(dest, info.Name), false);
                    UnlockAllPlugin.Info("  copied " + info.Name + " (" + info.Length + " bytes, written "
                                         + info.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss",
                                                                       CultureInfo.InvariantCulture) + ")");
                    copied++;
                }

                if (copied == 0)
                {
                    error = "no .save files in " + saveDir;
                    return null;
                }

                File.WriteAllText(Path.Combine(dest, "README.txt"),
                    "Vampire Crawlers save files copied by VampireCrawlersUnlockAll\n"
                    + "before it unlocked anything on profile " + profileId + ".\n\n"
                    + "Taken (UTC): " + DateTime.UtcNow.ToString("u", CultureInfo.InvariantCulture) + "\n"
                    + "Source:      " + saveDir + "\n\n"
                    + "To restore by hand: close the game, then copy these files back over\n"
                    + "the ones in the source folder. That undoes everything the mod did,\n"
                    + "and everything you played since, back to the moment above.\n\n"
                    + "The mod's own revert (its panel) is the better first choice: it puts\n"
                    + "the unlocks back as they were without discarding progress you made\n"
                    + "afterwards.\n",
                    new UTF8Encoding(false));

                return dest;
            }
            catch (Exception ex)
            {
                error = ex.GetType().Name + ": " + ex.Message;
                return null;
            }
        }

        private static string Stamp() =>
            DateTime.Now.ToString("yyyy-MM-dd_HHmmss", CultureInfo.InvariantCulture);

        private static string Sanitise(string s)
        {
            if (string.IsNullOrEmpty(s)) return "unknown";
            var sb = new StringBuilder(s.Length);
            foreach (char c in s)
                sb.Append(char.IsLetterOrDigit(c) || c == '-' || c == '_' ? c : '_');
            return sb.ToString();
        }
    }
}
