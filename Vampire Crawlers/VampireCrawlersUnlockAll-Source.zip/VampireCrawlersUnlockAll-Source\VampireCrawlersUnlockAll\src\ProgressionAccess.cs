using System;
using System.Collections.Generic;
using Nosebleed.Pancake.GameConfig;
using Nosebleed.Pancake.GameConfig.Accessors;
using Nosebleed.Pancake.MetaProgression;
using UnityEngine;

namespace VampireCrawlersUnlockAll
{
    /// <summary>
    /// The one place that reaches into the game for persistent progression.
    ///
    /// Everything the categories touch hangs off <see cref="ProgressionData"/>, a
    /// ScriptableObject reached through the Globals singleton. It exists in the menus as
    /// well as mid-run, which is what makes unlocking from the title screen possible --
    /// no run has to be started first.
    ///
    /// Nothing is cached across frames. A scene change can destroy the accessor behind
    /// these references, and a stale il2cpp pointer is a native crash no try/catch can
    /// intercept, so each call re-resolves.
    /// </summary>
    internal sealed class ProgressionAccess
    {
        /// <summary>Live progression, or null when the game has not built it yet.</summary>
        internal ProgressionData Data =>
            Safely.Get<ProgressionData>(() => Globals.Progression, null);

        /// <summary>
        /// True only when the live progression is the player's, not the blank object the
        /// title screen starts with. Both halves matter: the object existing says nothing
        /// about whether a profile has been loaded into it.
        /// </summary>
        internal bool Ready => Data != null && ProgressionLoadWatcher.Loaded;

        /// <summary>The object exists, but may still be holding defaults.</summary>
        internal bool Exists => Data != null;

        /// <summary>
        /// Profile the progression belongs to, e.g. "SaveProfile0". Snapshots are keyed on
        /// it so two profiles cannot restore each other's unlock state.
        ///
        /// Null when the game has not told us -- never a guess. An earlier version defaulted
        /// to "SaveProfile0" here, which made an unloaded title screen look exactly like a
        /// loaded profile and hid the bug that made the first unlock evaporate. A plausible
        /// wrong answer is worse than no answer: this one names the file a revert will read.
        /// </summary>
        internal string ProfileId =>
            Safely.Get<string>(() => Nosebleed.SaveLoadSystem.SaveLoadSystem.CurrentSaveSlot.ProfileId, null);

        /// <summary>
        /// The profile id for display and for keying a snapshot. Falls back to a name that
        /// is obviously not a real profile, so a snapshot written under it cannot be mistaken
        /// for one belonging to SaveProfile0.
        /// </summary>
        internal string ProfileKey
        {
            get
            {
                string id = ProfileId;
                return string.IsNullOrEmpty(id) ? "unnamed-profile" : id;
            }
        }

        /// <summary>Folder the game keeps its .save files in.</summary>
        internal static string SaveFolder =>
            System.IO.Path.Combine(
                Safely.Get(() => Application.persistentDataPath, string.Empty), "Save");

        /// <summary>
        /// Mark progression changed and push it to disk.
        ///
        /// The dirty flag alone only makes the game save at its own next checkpoint, which
        /// may be a long way off (or never, if the player alt-F4s), so the save manager is
        /// asked directly. SaveProgress returns a UniTask that is deliberately not awaited:
        /// this runs from Update, and the write completes on the game's own loop.
        /// </summary>
        internal void MarkDirtyAndSave()
        {
            var data = Data;
            if (data == null) return;

            Safely.Do("Marking progression dirty", () => data._isDirty = true);

            Safely.Do("Firing ProgressionUpdated", () =>
            {
                var updated = data.ProgressionUpdated;
                if (updated != null) updated.Invoke();
            });

            Safely.Do("Requesting a progression save", () =>
            {
                var mgr = UnityEngine.Object
                    .FindFirstObjectByType<Nosebleed.SaveLoadSystem.Pancake.ProgressionSaveLoadManager>();
                if (mgr == null)
                {
                    UnlockAllPlugin.Warn("No ProgressionSaveLoadManager in the scene; progression is "
                                         + "marked dirty and will be written at the game's next save.");
                    return;
                }
                mgr.SaveProgress();
            });
        }

        // ---- config identity ----------------------------------------------------------
        //
        // Every unlockable config is a ScriptableObject carrying an AssetId ("FCC_Antonio",
        // "PowerUp_Area"), and that is the string the game itself writes into the save. The
        // snapshot uses the same key, so a snapshot stays readable next to the save file and
        // survives the objects themselves being reallocated between launches.
        //
        // AssetId is declared separately on each config type rather than on a shared base,
        // so it is read through these small adapters instead of one generic call.

        internal static string IdOf(CardConfig c) => Safely.Get(() => c.AssetId, null);
        internal static string IdOf(DungeonConfig c) => Safely.Get(() => c.AssetId, null);
        internal static string IdOf(Nosebleed.Pancake.GameConfig.ShopConfigs.TownBuildingConfig c) => Safely.Get(() => c.AssetId, null);
        internal static string IdOf(Nosebleed.Pancake.GameConfig.ShopConfigs.PowerUps.PowerUpConfig c) => Safely.Get(() => c.AssetId, null);
        internal static string IdOf(Nosebleed.Pancake.Achievements.AchievementConfig c) =>
            Safely.Get(() => c.AssetId, null);

        /// <summary>Index a list of configs by id, for restoring a set from its snapshot.</summary>
        internal static Dictionary<string, T> ById<T>(List<T> configs, Func<T, string> id)
        {
            var map = new Dictionary<string, T>(StringComparer.Ordinal);
            foreach (T c in configs)
            {
                string key = id(c);
                if (!string.IsNullOrEmpty(key)) map[key] = c;
            }
            return map;
        }
    }
}
