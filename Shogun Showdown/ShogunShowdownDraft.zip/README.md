# Shogun Showdown Draft

A BepInEx mod for **Shogun Showdown** that adds a **draft** option to tile rewards.

When you win a battle and reach the tile-reward screen (the one with 3 random tiles,
Reroll and Skip), a **"Draft a tile"** button now appears at the top-center of the
screen. Click it (or press **D**) to open a menu listing **every tile you have
unlocked** — name, damage, cooldown, and a hover description. Pick one and it is
added straight to your deck at the reward's current level, consuming the reward and
moving on — exactly as if you had picked one of the RNG offers, but you get the tile
you actually want.

- **Free** — no coin cost (unlike Reroll).
- **No RNG** — you choose from your full unlocked pool.
- Already-owned tiles are shown dimmed with an "(already in deck)" tag, but remain
  pickable (duplicates are allowed).
- Works with keyboard + mouse.

## Configuration

Edit `BepInEx/config/dev.shogunshowdown.draft.cfg` (created on first launch):

| Setting | Default | Meaning |
|---|---|---|
| `Hotkeys > OpenDraft` | `D` | Hotkey that opens/closes the draft menu on a reward screen. |
| `Draft > IncludeAllTiles` | `false` | `true` lists **every** tile in the game, including locked and enemy/boss-only ones. `false` (default) lists only tiles you have unlocked — the same pool the game's own reward RNG draws from. |
| `Draft > ShowDraftButton` | `true` | Draw the "Draft a tile" button on the reward screen. The hotkey still works if you turn the button off. |

## How it works

The draft is gated on the reward being active and ready (not mid-reroll / pick
animation) and not yet exhausted, so it can't fire during combat or after the reward
is already taken. Picking a tile runs the same sequence the game uses when you pick a
normal offered tile (`TilesManager.TakeTile` → reward `UpgradeClaimed` + `EndEvent`
→ `RewardsScreenUpgradeChoosen`), so the reward room advances to the next map node
normally and save data stays consistent.

The menu is built with the game's own uGUI system (a Canvas + buttons), so it renders
and handles clicks exactly like the game's native UI. Per-frame state (button
visibility, hover tooltip) is driven from a Harmony hook on the game's
`CombatManager.Update`, which runs in every room. The plugin's own MonoBehaviour
callbacks are not driven in this game, so nothing else runs its own update loop.

## Technical notes

- **No Harmony conflicts**: the plugin hooks only `CombatManager.Update` (the AI plugin
  hooks the same method with a separate patch; multiple postfixes coexist).
- **Only the tile reward** (`NewTileReward`) is affected — the reward screen that has
  the Reroll button. Tile *upgrade* offers (map hammer nodes) are untouched.
- **Level parity**: a drafted tile is created at the same max level as the tiles the
  reward is currently offering, so it matches the run's progression.
- Already-owned tiles remain pickable (duplicates are allowed) but are shown dimmed.

## Compatibility

- Tested against Shogun Showdown **v1.0.2.1g** (Unity 2021.3, BepInEx 5.4.23.2).
- Coexists with the trainer and AI plugins (different plugin GUIDs).
- The tile reward is the `NewTileReward` reward type. Tile *upgrade* offers (the
  hammer nodes on the map) are left untouched.
