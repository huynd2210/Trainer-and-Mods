# Shogun Showdown Trainer

A BepInEx trainer mod for **Shogun Showdown** (Unity Mono build, GOG v1.0.2.1g).

## Features

| Hotkey | Feature | Effect |
|--------|---------|--------|
| `F1` | **Heal to Full** | Restore the hero to full HP. |
| `F2` | **Max Gold** | Set coins to the configured amount (default **99999**). |
| `F3` | **Kill Enemies** | Kill every enemy in the current room. |
| `F4` | **Recharge Special** | Fully recharge the hero's special move. |
| `F5` | **Recharge Tiles** | Recharge every tile in the deck (all off cooldown). |
| `F9` | **Overlay** | Toggle the small on-screen state display. |

## Install

**Option A — you already have BepInEx installed (any BepInEx 5.x):**
Extract `BepInEx\plugins\ShogunShowdownTrainer.dll` into your game folder's
`BepInEx\plugins\` directory, then launch `ShogunShowdown.exe`.

**Option B — fresh install (recommended):** use the `ShogunShowdownTrainer-Pack.zip`
instead. It ships a known-good BepInEx 5.4.23.2 x64 build plus this mod. Extract
the zip so its contents land **inside** the game folder (the folder containing
`ShogunShowdown.exe`), then run the game.

## Configuration

On first launch a config file is created at:
`BepInEx\config\dev.shogunshowdown.trainer.cfg`

You can rebind any hotkey (accepts `Key` or `KeyCode` names, e.g. `F1`, `K`,
`Home`) and change `MaxGoldAmount`. Editing the file takes effect after a restart.

## Uninstall

Delete `BepInEx\plugins\ShogunShowdownTrainer.dll` and
`BepInEx\config\dev.shogunshowdown.trainer.cfg`. If you installed the `-Pack`
version and want BepInEx gone too, delete the `BepInEx` folder plus `winhttp.dll`,
`.doorstop_version`, and `doorstop_config.ini` from the game folder.

## Notes

- Toggles affect the **current run only**; save / meta progression is untouched.
- Requires the x64 Mono build of Shogun Showdown (the default GOG/Steam build).
