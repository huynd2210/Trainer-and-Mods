# Shogun Showdown AI (BepInEx minimax bot)

A fully-autonomous AI that plays **Shogun Showdown** (Unity Mono, GOG v1.0.2.1g) through
BepInEx. As a first proof-of-concept it **starts a run by itself and clears the first
combat room** (`bg-1`, BambooGrove: 4 waves of Ashigaru/TwinTachi), then stops.

## What it does

- **Toggle on demand** (default hotkey `F6`): press it mid-run to hand the game to the AI;
  press again to take back control. The game boots normally — you can play yourself whenever
  you like.
- **Plays combat itself**: each hero turn it reads the live game state, searches a few turns
  ahead with **minimax + alpha-beta** over a deterministic model of the battle, and executes
  the best decision (queue a tile / attack / move / flip / wait) through the game's own
  combat API. It hands control back the moment you toggle it off (at the next input window).
- Logs progress to `BepInEx\LogOutput.log` with an `[AI]` prefix.

## How it works

The game is turn-based and its enemy intents are telegraphed in advance, which makes the
battle effectively deterministic. The AI keeps a pure-C# model of the combat rules
(`ShogunShowdownAiCore`):

- `Simulator` — resolves a hero decision + the enemy turn (movement, attacks, cooldowns,
  waves), ported from the decompiled game.
- `EnemyBrain` — exact port of the Ashigaru / TwinTachi `AIPickAction`.
- `Minimax` — alpha-beta search (depth 6, ~100k nodes) with an evaluation that values
  hero HP, enemy damage done, attack readiness, and facing alignment (Arrow is forward-only).

The live layer (`ShogunShowdownAI.dll`) hooks `CombatManager.Update` (the plugin's own
`Update` is not driven in this game) and drives decisions only inside hero input windows.
It re-plans after every turn, so wave composition changes and room layout don't matter —
it adapts to whatever the game presents.

## Install

**Option A — you already have BepInEx (or installed the Trainer `-Pack`):**
Extract `BepInEx\plugins\ShogunShowdownAI.dll` and `BepInEx\plugins\ShogunShowdownAiCore.dll`
into your game folder's `BepInEx\plugins\`, then launch `ShogunShowdown.exe`. Start a run as
normal; press `F6` in combat to let the AI play.

**Option B — fresh install:** use the `ShogunShowdownAI-Pack.zip` (ships BepInEx + the AI).
Extract into the game folder (the folder containing `ShogunShowdown.exe`).

## Two modes

The same plugin DLL adapts to how you launch the game:

**1. Play mode (default)** — launch `ShogunShowdown.exe` normally:
- The game boots to the title screen as usual; nothing changes.
- Press **`F6`** in a combat to hand the turn to the AI; press **`F6`** again to take back control.
- Config: `AI / Enabled = false`, `AI / AutoStart = false`.

**2. Headless / test mode** — launch with `-batchmode -nographics` (the `run_headless.sh` / `train_headless.sh` scripts do this):
- The AI auto-starts a run, auto-engages, mutes audio and runs at ~20x speed.
- Used for unattended iteration and Q-learning training.
- Detected automatically via `Application.isBatchMode`, so you don't need to change the config.

The Q-learning table (`BepInEx/ai_ql.txt`) is shared and accumulates across runs in both modes.

The AI only supports the first-battle model (Ashigaru/TwinTachi, Swirl/Arrow/Katana). If you
toggle it on somewhere else, it logs a warning and idles.

## Headless / background running

The game has **no built-in headless mode** (no batchmode handling in its code). It runs
windowed; the plugin sets `Application.runInBackground = true` so the game keeps updating
when the window is minimized or unfocused. To run "headless-ish":

- Launch the game normally; the AI drives everything. The window can be minimized or sent
  to another virtual desktop.
- Optionally try `ShogunShowdown.exe -batchmode -nographics` — Unity may run it without a
  window, but this is untested with this game.

## Configuration

`BepInEx\config\dev.shogunshowdown.ai.cfg`:
- `AI / Enabled` (default `false`) — whether the AI starts on. Toggle it live with the hotkey.
- `Hotkeys / ToggleAI` (default `F6`) — the on/off key.

## Scope notes

- Only the **first battle** is supported: if the run ever presents mechanics outside the
  first-battle model (unknown enemy types, tiles, or a non-wave room), the AI bails out
  safely (logs a warning and idles) rather than mis-playing.
- Deliberately simple for the POC: no potions, skills, special moves, or map/location
  navigation (those come next).
