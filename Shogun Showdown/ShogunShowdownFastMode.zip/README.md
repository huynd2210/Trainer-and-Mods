# Shogun Showdown — Fast Mode

Speeds up the game's combat animations for a faster-paced run. Press a key to toggle
between normal speed and a configurable multiplier (default **4x**). Everything in a
battle — the hero's dashes, enemy movement, projectiles, damage numbers — plays out
4 times faster. Works alongside the other Shogun Showdown mods (Trainer, Draft, AI).

## Hotkey

| Action | Key (configurable) |
|--------|--------------------|
| Toggle fast speed on/off | **F8** |

Press **F8** once to turn turbo on, again to turn it off. A small indicator in the
top-right corner shows the current state: **gold `4x`** = turbo on, **grey `1x`** = off.
It also logs a line to the BepInEx console.

## What gets sped up

- All **combat animations** (the slow part) — hero and enemy turns, attacks, projectiles.
- Victory / enemy-turn transitions inside a battle.

Turbo only takes effect **while a fight is in progress**. In menus, the map, the shop and
reward screens the game runs at normal speed, so tooltips and text stay readable. When you
die or quit back to the title screen, speed is always reset to normal.

## What is NOT sped up (by design)

- **Pause menu** — the game pauses normally even while turbo is on; it resumes at turbo speed.
- **Headless/batchmode runs** (e.g. the AI plugin's automated training) — the AI owns game
  speed there, so Fast Mode stands aside and never interferes.
- **Sound pitch** — `Time.timeScale` doesn't change audio pitch, so effects still play at
  normal pitch over 4x visuals.

## Configuration

The plugin's settings live in `BepInEx\config\dev.shogunshowdown.fastmode.cfg`
(created on first launch). Edit while the game is closed:

| Setting | Section | Default | Meaning |
|---------|---------|---------|---------|
| `Toggle`  | `Hotkeys` | `F8` | Key that toggles fast speed. |
| `Enabled` | `Speed`   | `false` | Start with turbo on. The hotkey switches it at runtime; the choice is remembered between sessions. |
| `Multiplier` | `Speed` | `4` | How many times normal speed combat runs when turbo is on. |
| `ShowLabel`  | `UI`    | `true` | Show the small `1x` / `4x` indicator in the top-right corner. |

`Multiplier` accepts any value ≥ 1 (e.g. `2` for a gentler speed-up, `8` for very fast).
It is clamped to at most `100`.

## How it works

Combat speed is `UnityEngine.Time.timeScale` — the same lever the game's own
`DeveloperUtilsUI` uses and the AI plugin already uses at 20x in headless mode. A Harmony
postfix on the game's `CombatManager.Update` (which runs every frame in the combat scene)
applies the multiplier whenever a combat is in progress, leaves `timeScale` alone while the
game is paused (`PauseMenu` sets it to 0), and a scene-load hook resets it to 1 so turbo
never leaks into the title screen or menus.

## Install

- If you already have **BepInEx 5.4.23.2** installed: drop `ShogunShowdownFastMode.dll`
  into `BepInEx\plugins\`.
- Otherwise use the `-Pack.zip` (BepInEx + this mod), which is self-contained — extract into
  the game folder and you're ready to go. See `INSTALL.txt`.

## Build

`dotnet build -c Release` against the game's managed assemblies (netstandard 2.1, Unity 2021.3).
