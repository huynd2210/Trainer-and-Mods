# Shogun Showdown — Meta Progression

Spend **skulls** on **permanent upgrades** that apply to every new run: extra starting coins, extra
starting max HP, and bonus starting tiles/skills. Press **M** (or the "Meta (M)" button, top-right)
to open the shop.

This mod uses the game's **own** skull economy — the same persistent skull pool you already spend in
the base game's unlock shop (bosses grant skulls; they're saved in `SaveData.dat`). Buying a meta
upgrade here takes skulls out of that same pool, so you choose: unlock new tiles/skills, or buy a
meta upgrade. Both persist between sessions.

## How to use

1. Press **M** anywhere (title screen, camp, mid-run) to open the shop. The first time you open it,
   the small **Meta (M)** button appears top-right and stays there.
2. Each upgrade row shows its rank, its effect and its skull cost. Click **Buy** — the cost is
   taken from your skulls immediately and the rank goes up. The upgrade applies to **every new run**
   from then on (not the current one).
3. **Refund all** gives every spent skull back and zeroes the upgrades.

## The upgrades

| Upgrade | Effect per rank | Cost | Max rank |
|---------|-----------------|------|----------|
| Golden Purse | Start with +40 coins | 25 skulls | 20 |
| Iron Constitution | Start with +3 max HP | 30 skulls | 20 |
| Warrior's Cache | Start with a bonus unlocked tile | 50 skulls | 5 |
| Sage's Wisdom | Start with a bonus unlocked skill | 60 skulls | 5 |

Bonus tiles/skills are picked randomly from your **unlocked** tiles/skills (never duplicate what the
deck/hero already has). Costs, values and max ranks are all configurable (see below).

Skulls are earned the same way as in the base game: defeating bosses. A full clear nets roughly
40–60 skulls, so the early ranks are one to two runs and the later ones are a long-term grind.

## Configuration

`BepInEx\config\dev.shogunshowdown.meta.cfg` (created on first launch; edit while the game is
closed, or just use the in-game shop):

| Setting | Default | Meaning |
|---------|---------|---------|
| `Enabled` | `true` | Apply purchased upgrades at the start of each new run. |
| `OpenMeta` | `M` | Hotkey that opens/closes the shop. |
| `GoldenPurse` / `IronConstitution` / `WarriorsCache` / `SagesWisdom` | `0` | Current rank of each upgrade (the shop edits these). |
| `GoldenPurseCost` / `...Max` / `...Value` | `25` / `20` / `40` | Cost per rank, max rank, coins per rank. |
| `IronConstitutionCost` / `...Max` / `...Value` | `30` / `20` / `3` | Cost per rank, max rank, HP per rank. |
| `WarriorsCacheCost` / `...Max` | `50` / `5` | Cost per rank, max rank. |
| `SagesWisdomCost` / `...Max` | `60` / `5` | Cost per rank, max rank. |

## Notes

- Nothing is applied on a **continued** run (it keeps its saved state) and nothing is applied if
  `Enabled` is off.
- Buying costs skulls immediately and writes the reduced pool into `SaveData.dat`, so the spend
  survives restarts. Uninstalling the mod keeps your skulls and unlocks untouched — only the
  upgrade ranks (in the config file) go away.

## How it works

- The skull balance is `Globals.KillCount`, the game's persistent meta currency (saved in
  `SaveData.metaCurrency`).
- Buying calls `SaveDataManager.StoreSaveData()` — the exact call the game uses at run start and
  on unlocks — so the reduced pool is persisted by the game's own save system.
- Upgrades are applied at run start from `EventsManager.BeginRun`, using the same calls as the
  game's own code: `Globals.Coins +=` for coins, `Agent.AddToMaxHealth(...)` for HP, and the
  Loadout plugin's tile/skill pickup path for the bonus tile/skill.

This mod deliberately does **not** use Harmony: in this game's BepInEx build only the first-loaded
plugin's Harmony patches are invoked (verified — the AI's patch runs; Loadout/Draft/FastMode
patches are registered but never fire). So everything here is driven by the Input System hotkey and
a direct `EventsManager.BeginRun` subscription (the same mechanisms the other mods use).

## Install

- If you already have **BepInEx 5.4.23.2**: drop `ShogunShowdownMeta.dll` into `BepInEx\plugins\`.
- Otherwise use the `-Pack.zip` (BepInEx + this mod), which is self-contained — extract into the
  game folder and you're ready. See `INSTALL.txt`.

## Build

`dotnet build -c Release` against the game's managed assemblies (netstandard 2.1, Unity 2021.3).
