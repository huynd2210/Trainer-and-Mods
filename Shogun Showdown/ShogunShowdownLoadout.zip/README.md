# Shogun Showdown — Loadout

Pick which **tiles** (attack deck) and **skills** (perks) you start a run with, before the run
begins. Press **L** (or the "Loadout" button, top-right, once it's on screen) to open a picker
where you toggle tiles and skills on and off; your picks are applied automatically when the run
starts. Works alongside the other Shogun Showdown mods (Trainer, Draft, AI, Fast Mode).

## How to use

1. Press **L** anywhere (title screen, camp, mid-run) to open the loadout picker. The first time
   you open it, the small **Loadout (L)** button appears top-right and stays there.
2. In the picker, switch between the **Tiles** and **Skills** tabs and click entries to toggle
   them on (gold, ticked) or off. Selected-first ordering keeps your picks on top.
3. Close the picker, then start a **new** run. Your picked tiles and skills are applied at the start.

The choice is remembered between sessions (stored in the config file).

> Note: open the picker once before starting a run so the run-start hook is armed. If you only
> hand-edit the config file and never press L in a session, the loadout may not be applied that
> session.

## What gets applied

- **Tiles** you picked are added to your starting deck (or replace it — see below), at the same
  level the game uses for starting-deck tiles.
- **Skills** you picked are picked up at level 1, exactly like the game's own skill rewards.

Nothing is applied on a **continued** run (it keeps its saved state), and nothing is applied if
`Enabled` is off.

## Configuration

`BepInEx\config\dev.shogunshowdown.loadout.cfg` (created on first launch; edit while the game
is closed, or just use the in-game picker):

| Setting | Default | Meaning |
|---------|---------|---------|
| `Enabled`            | `true`  | Apply the loadout at the start of each new run. |
| `Tiles`              | *(empty)* | Starting tiles, comma-separated enum names (e.g. `Katana, Swirl, Bomb`). The picker edits this. |
| `Skills`             | *(empty)* | Starting skills, comma-separated enum names (e.g. `BackStabber, BigPockets`). |
| `ReplaceStarterDeck` | `false` | If `true`, the picked tiles **replace** the hero's starter deck. If `false`, they are **added** on top of it. |
| `IncludeLockedTiles` | `false` | List not-yet-unlocked tiles in the picker too. |
| `IncludeLockedSkills`| `false` | List not-yet-unlocked skills in the picker too. |
| `OpenLoadout`        | `L`     | Hotkey that opens/closes the picker. |

Notes:
- Hand-editing `Tiles`/`Skills` is supported (invalid names are ignored). Tile/skill enum names
  are the game's internal names, e.g. `Katana`, `Arrow`, `Swirl`, `Bomb`, `BackStabber`,
  `BigPockets`, `IronSkin`. The in-game picker shows the localized display names.
- If `ReplaceStarterDeck` is `true`, only pick enough tiles to be your deck — the hero's starter
  tiles are dropped.

## How it works

When a run begins (`EventsManager.BeginRun` — the event the game fires exactly once per run when
you leave the pre-run camp), the picks are applied using the **same calls the game's own code
uses** — the shipped-but-unused `CustomLoadout` class and the camp's `StartingDeckSelection`:
- Tiles: `TilesManager.TakeTile(TilesFactory.Create(...))`.
- Skills: `SkillsManager.PickUpListOfSkills(...)`.
- Replace mode resets the deck/hand exactly like `StartingDeckSelection.DestroyTilesAndReInitializeHand`.

It never touches a continued run, and it skips anything the run already has (so it stays
idempotent). The special move is not changed (only tiles + skills).

This mod deliberately does **not** use Harmony: in this game's BepInEx build only the first-loaded
plugin's Harmony patches are invoked (verified — the AI's patch runs; Loadout/Draft/FastMode
patches are registered but never fire). So everything here is driven by the Input System hotkey
(the same mechanism as the AI's F6, which works) and a direct `EventsManager.BeginRun`
subscription (the same mechanism as the AI's game-over subscription).

## Install

- If you already have **BepInEx 5.4.23.2**: drop `ShogunShowdownLoadout.dll` into
  `BepInEx\plugins\`.
- Otherwise use the `-Pack.zip` (BepInEx + this mod), which is self-contained — extract into the
  game folder and you're ready. See `INSTALL.txt`.

## Build

`dotnet build -c Release` against the game's managed assemblies (netstandard 2.1, Unity 2021.3).
