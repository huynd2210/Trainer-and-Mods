@echo off
cd /d "%~dp0"
python diag.py
pause
