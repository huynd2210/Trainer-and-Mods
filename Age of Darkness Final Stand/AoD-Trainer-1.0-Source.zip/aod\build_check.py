"""Guard against running against a game build the offsets were not generated for.

A patch shifts every RVA and every struct offset. Without this check the trainer
reads plausible-looking garbage out of the wrong addresses, which is far worse than
refusing to run.
"""
import hashlib, os
from .ue import OFF


def sha256(path, chunk=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(chunk), b""):
            h.update(b)
    return h.hexdigest()


def check(proc, full=False):
    """Returns (ok, level, message). level is 'ok' | 'warn' | 'bad'."""
    want_size = OFF.get("exe_size")
    want_hash = OFF.get("exe_sha256")
    path = getattr(proc, "exe_path", None)

    if not path or not os.path.exists(path):
        return True, "warn", "could not locate the game exe to verify the build"

    got_size = os.path.getsize(path)
    if want_size and got_size != want_size:
        return (False, "bad",
                "GAME BUILD MISMATCH - exe is %d bytes, offsets were built for %d.\n"
                "     Re-run  python tools/gen_offsets.py  against this build."
                % (got_size, want_size))

    if full and want_hash:
        got = sha256(path)
        if got != want_hash:
            return (False, "bad",
                    "GAME BUILD MISMATCH - exe hash differs from the one offsets.json\n"
                    "     was generated from. Re-run tools/gen_offsets.py.")
        return True, "ok", "build verified (sha256 match)"

    return True, "ok", "build matches (size check; --verify for full hash)"
