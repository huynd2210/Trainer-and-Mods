"""Age of Darkness: Final Stand - trainer.

Single-player only. The game runs a deterministic lockstep simulation; writing to
simulation state in multiplayer will desync every client.

Input uses GetAsyncKeyState polling rather than RegisterHotKey: it needs no
registration, cannot lose a race with another app for the same chord, and keeps
working when the game holds exclusive fullscreen input.
"""
import ctypes as C
from ctypes import wintypes as W
import sys, time, traceback
import queue
import threading

from aod.game import Game, RESOURCES
from aod.cheats import REGISTRY
from aod.build_check import check as check_build

VERSION = "1.0"

u32 = C.WinDLL("user32", use_last_error=True)
k32 = C.WinDLL("kernel32", use_last_error=True)
u32.GetAsyncKeyState.argtypes = [C.c_int]
u32.GetAsyncKeyState.restype = C.c_short
k32.GetStdHandle.argtypes = [W.DWORD]
k32.GetStdHandle.restype = W.HANDLE
k32.GetConsoleMode.argtypes = [W.HANDLE, C.POINTER(W.DWORD)]
k32.GetConsoleMode.restype = W.BOOL
k32.SetConsoleMode.argtypes = [W.HANDLE, W.DWORD]
k32.SetConsoleMode.restype = W.BOOL

VK_CONTROL, VK_MENU, VK_SHIFT = 0x11, 0x12, 0x10
VK_R, VK_Q = 0x52, 0x51


def down(vk):
    return bool(u32.GetAsyncKeyState(vk) & 0x8000)


class Keys:
    """Edge-triggered chord detection. Fires once per press, not per poll."""

    def __init__(self, mods=(VK_CONTROL, VK_MENU)):
        self.mods = mods
        self._prev = set()

    @property
    def mods_held(self):
        return all(down(m) for m in self.mods)

    def pressed(self, vks):
        """Return the subset of `vks` that transitioned to down this poll while the
        modifiers were held. Either key order completes the chord."""
        now = {vk for vk in vks if down(vk)} if self.mods_held else set()
        fired = now - self._prev
        self._prev = now
        return fired


def hotkey_vks():
    count = min(len(REGISTRY), 9)
    return [0x31 + i for i in range(count)] + [0x61 + i for i in range(count)] + [VK_R, VK_Q]


def canonical_key(vk):
    return vk - 0x30 if 0x61 <= vk <= 0x69 else vk


class KeyPoller:
    """Capture input independently of slow discovery and console output.

    Only the main thread handles actions and accesses game memory.
    """
    def __init__(self):
        self.keys = Keys()
        self.events = queue.SimpleQueue()
        self.stop = threading.Event()
        self.thread = threading.Thread(target=self._run, name="hotkeys", daemon=True)

    def _run(self):
        vks = hotkey_vks()
        while not self.stop.is_set():
            for vk in sorted({canonical_key(v) for v in self.keys.pressed(vks)}):
                self.events.put(vk)
            self.stop.wait(0.005)

    def start(self):
        self.thread.start()

    def drain(self):
        while True:
            try:
                yield self.events.get_nowait()
            except queue.Empty:
                return

    def close(self):
        self.stop.set()
        self.thread.join()


def enable_vt():
    h = k32.GetStdHandle(-11)
    m = W.DWORD()
    if k32.GetConsoleMode(h, C.byref(m)):
        k32.SetConsoleMode(h, m.value | 0x0004)


CLR = "\033[H\033[J"
DIM, BOLD, GREEN, YELLOW, RED, CYAN, RESET = (
    "\033[2m", "\033[1m", "\033[32m", "\033[33m", "\033[31m", "\033[36m", "\033[0m")

MODNAME = "Ctrl+Alt"


class Trainer:
    def __init__(self):
        self.game = None
        self.status = "starting"
        self.last_action = ""
        self.keys = KeyPoller()
        self.quit = False
        self.seen = ""
        self.build = (True, "ok", "")
        self.verify_hash = "--verify" in sys.argv

    # ---------- input ----------
    def handle_input(self):
        fired = self.keys.drain()
        self.seen = ("%s %s" % ("CTRL" if down(VK_CONTROL) else "    ",
                                "ALT" if down(VK_MENU) else "   "))
        for vk in fired:
            if vk == VK_Q:
                self.quit = True; return
            if vk == VK_R:
                self.attach(force=True)
                self.last_action = "re-scanned"; continue
            i = vk - 0x31
            if 0 <= i < len(REGISTRY):
                c = REGISTRY[i]
                if c.needs_match and (not self.game or self.game.world is None):
                    self.last_action = "%s: not in a match" % c.label
                    continue
                on = c.toggle(self.game)
                self.last_action = "%s -> %s" % (c.label, "ON" if on else "off")

    # ---------- game ----------
    def attach(self, force=False):
        try:
            if self.game is None or force:
                if self.game:
                    try: self.game.close()
                    except Exception: pass
                self.game = Game()
                self.build = check_build(self.game.p, full=self.verify_hash)
            live = self.game.locate()
            self.status = "in match" if live else "attached (menu / loading)"
        except Exception as e:
            self.game = None
            self.status = "waiting for game: %s" % e

    def tick(self):
        if self.game is None:
            self.attach(); return
        try:
            if self.game.world is None or not self.game._plausible_world(self.game.world):
                self.game.locate()
            if self.game.world is not None:
                for c in REGISTRY:
                    if c.enabled:
                        c.tick(self.game)
                self.status = "in match"
            else:
                self.status = "attached (menu / loading)"
        except Exception as e:
            self.status = "lost game: %s" % e
            self.game = None

    # ---------- render ----------
    def render(self):
        g = self.game
        out = [CLR, BOLD + "Age of Darkness: Final Stand - trainer v%s" % VERSION + RESET,
               DIM + "single-player only; this writes deterministic-sim state" + RESET, ""]
        ok, level, msg = self.build
        if level != "ok":
            out.append("  " + (RED if level == "bad" else YELLOW) + msg + RESET)
            out.append("")
        col = GREEN if self.status == "in match" else YELLOW
        line = "  %s%s%s" % (col, self.status, RESET)
        if g and g.world:
            line += DIM + "   frame=%s player=%s team=%s" % (
                g.frame, g.local_player_index, g.local_team_index) + RESET
        out.append(line)
        out.append("")

        if g and g.world:
            cur, mx = g.read_block("current"), g.read_block("max")
            if cur:
                out.append("  " + BOLD + "resources (team %s)" % g.local_team_index + RESET)
                for r in RESOURCES:
                    out.append("    %-10s %s%8s%s / %-8s" % (
                        r, CYAN, f"{cur[r]:,.0f}", RESET, f"{mx[r]:,.0f}"))
                out.append("")

        out.append("  " + BOLD + "cheats" + RESET + DIM + "   (%s+N)" % MODNAME + RESET)
        for i, c in enumerate(REGISTRY):
            st = c.status(g) if g and g.world else ("ON" if c.enabled else "off")
            mark = GREEN + "*" + RESET if c.enabled else " "
            out.append("   %s %s+%d  %-22s %-12s %s%s%s"
                       % (mark, MODNAME, i + 1, c.label, st, DIM, c.detail, RESET))
        out.append("")
        out.append(DIM + "   %s+R  re-scan       %s+Q  quit       held: [%s]"
                   % (MODNAME, MODNAME, self.seen) + RESET)
        if self.last_action:
            out.append("   " + YELLOW + self.last_action + RESET)
        sys.stdout.write("\n".join(out) + "\n")
        sys.stdout.flush()

    def run(self):
        enable_vt()
        self.keys.start()
        last = 0.0
        try:
            self.attach()
            while not self.quit:
                self.handle_input()
                if self.quit:
                    break
                self.tick()
                now = time.time()
                if now - last > 0.25:
                    self.render(); last = now
                time.sleep(0.02)
        except KeyboardInterrupt:
            pass
        finally:
            self.keys.close()
            if self.game:
                try: self.game.close()
                except Exception: pass
            print("\nbye.")


def keytest():
    """Standalone input check: prints every chord it sees for 20 seconds."""
    print("Hold %s and tap 1..4, R or Q. Ctrl-C to stop. 20s..." % MODNAME)
    ks = Keys()
    vks = hotkey_vks()
    t0 = time.time()
    while time.time() - t0 < 20:
        f = {canonical_key(v) for v in ks.pressed(vks)}
        if f:
            print("  saw: %s   (ctrl=%s alt=%s)"
                  % (sorted(chr(v) for v in f), down(VK_CONTROL), down(VK_MENU)), flush=True)
        time.sleep(0.02)
    print("done.")


if __name__ == "__main__":
    try:
        if "--keytest" in sys.argv:
            keytest()
        elif "--diag" in sys.argv:
            import diag
            diag.main()
        else:
            Trainer().run()
    except Exception:
        traceback.print_exc()
        input("\npress Enter to close...")
