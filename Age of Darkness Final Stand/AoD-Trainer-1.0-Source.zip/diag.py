"""Verify the trainer's view of the running game. Run this first."""
import sys, struct, time
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
from aod.game import Game, RESOURCES, RESOURCE_BLOCKS, from_fixed
from aod.ue import OFF, o


def main():
    print("=== attaching ===")
    try:
        g = Game()
    except Exception as e:
        print("FAIL:", e); return 1
    p = g.p
    print("pid=%d base=0x%X size=0x%X" % (p.pid, p.base, p.size))

    print("\n=== FName pool ===")
    print("pool @ 0x%X   CurrentBlock=%s" % (g.names.pool, g.names.cur_block))
    print("   id 0 -> %r  (must be 'None')" % g.names.get(0))

    print("\n=== GUObjectArray ===")
    ob = g.objs
    print("Objects=0x%X NumElements=%d NumChunks=%d MaxElements=%d per_chunk=%d"
          % (ob.objects_ptr or 0, ob.num_elements, ob.num_chunks, ob.max_elements, ob.per_chunk))
    t = time.time()
    n = 0
    sample = []
    for i, obj in ob.iter_objects():
        n += 1
        if len(sample) < 5:
            sample.append((i, obj, ob.obj_name(obj), ob.class_name(ob.obj_class(obj))))
    print("walked %d objects in %.2fs" % (n, time.time() - t))
    for i, a, nm, cn in sample:
        print("   [%d] 0x%X %s (%s)" % (i, a, nm, cn))

    print("\n=== class census (top 15) ===")
    from collections import Counter
    c = Counter()
    for i, obj in ob.iter_objects():
        cls = ob.obj_class(obj)
        if cls:
            c[ob.class_name(cls)] += 1
    for k, v in c.most_common(15):
        print("   %-40s %d" % (k, v))

    print("\n=== simulation ===")
    ok = g.locate(verbose=True)
    if not ok:
        print("no live world_data -> not in a match (main menu?)")
        for k in ("SimulationHandler", "AchillesGameState", "AchillesPlayerController",
                  "AchillesHUD", "AchillesGlobals"):
            print("   %-30s found=%d" % (k, len(ob.find_by_class(k))))
        return 0

    print("frame=%s sim_tick=%s is_server=%s local_player=%s local_team=%s"
          % (g.frame, g.sim_tick, g.is_server, g.local_player_index, g.local_team_index))
    sp = g.resources_ptr()
    print("resources sim_ptr:", sp)
    print("expected stride 0x%X (sizeof sim_state_data)" % OFF["sizeof"]["world_resources::sim_state_data"])
    for team in g.teams_with_state():
        cur = g.read_block("current", team)
        mx = g.read_block("max", team)
        if cur is None:
            continue
        print("\n  --- team %d @ 0x%X ---" % (team, g.team_state(team)))
        for r in RESOURCES:
            print("     %-10s %12.2f / %-12.2f" % (r, cur[r], mx[r]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
