"""Disassemble a function from the running process by PDB symbol name."""
import sys, capstone
sys.path.insert(0, r"C:\Users\Admin\AoD-Trainer")
from aod.mem import Proc
import pdbdump as P

def func(name, count=400, exact=True):
    hits = [s for s in P.find_symbols(name, limit=200)
            if s["tag"] == 5 and (s["name"] == name if exact else True)]
    if not hits:
        print("no function", name); return
    s = hits[0]
    p = Proc()
    addr = p.base + s["rva"]
    size = max(s["size"], 16)
    code = p.read(addr, min(size, 8192))
    md = capstone.Cs(capstone.CS_ARCH_X86, capstone.CS_MODE_64)
    md.detail = False
    print("=== %s  rva=0x%X live=0x%X size=%d ===" % (s["name"], s["rva"], addr, s["size"]))
    for i, ins in enumerate(md.disasm(code, addr)):
        if i >= count: break
        print("  +0x%-5X %-24s %s %s" % (ins.address - addr,
              ins.bytes.hex(), ins.mnemonic, ins.op_str))

if __name__ == "__main__":
    func(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 400)
