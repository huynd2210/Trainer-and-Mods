"""External process memory access (read/write) for a 64-bit Windows target."""
import ctypes as C
from ctypes import wintypes as W
import struct

k32 = C.WinDLL("kernel32", use_last_error=True)
psapi = C.WinDLL("psapi", use_last_error=True)

PROCESS_ALL_ACCESS = 0x1F0FFF
TH32CS_SNAPPROCESS = 0x2
TH32CS_SNAPMODULE = 0x8
TH32CS_SNAPMODULE32 = 0x10
MAX_PATH = 260


class PROCESSENTRY32(C.Structure):
    _fields_ = [("dwSize", W.DWORD), ("cntUsage", W.DWORD), ("th32ProcessID", W.DWORD),
                ("th32DefaultHeapID", C.POINTER(C.c_ulong)), ("th32ModuleID", W.DWORD),
                ("cntThreads", W.DWORD), ("th32ParentProcessID", W.DWORD),
                ("pcPriClassBase", C.c_long), ("dwFlags", W.DWORD),
                ("szExeFile", C.c_char * MAX_PATH)]


class MODULEENTRY32(C.Structure):
    _fields_ = [("dwSize", W.DWORD), ("th32ModuleID", W.DWORD), ("th32ProcessID", W.DWORD),
                ("GlblcntUsage", W.DWORD), ("ProccntUsage", W.DWORD),
                ("modBaseAddr", C.POINTER(C.c_byte)), ("modBaseSize", W.DWORD),
                ("hModule", W.HMODULE), ("szModule", C.c_char * 256),
                ("szExePath", C.c_char * MAX_PATH)]


def find_pid(exe_name):
    snap = k32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    e = PROCESSENTRY32(); e.dwSize = C.sizeof(e)
    hits = []
    if k32.Process32First(snap, C.byref(e)):
        while True:
            if e.szExeFile.decode(errors="replace").lower() == exe_name.lower():
                hits.append(e.th32ProcessID)
            if not k32.Process32Next(snap, C.byref(e)):
                break
    k32.CloseHandle(snap)
    return hits[0] if hits else None


def find_module(pid, mod_name):
    snap = k32.CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid)
    m = MODULEENTRY32(); m.dwSize = C.sizeof(m)
    res = None
    if k32.Module32First(snap, C.byref(m)):
        while True:
            if m.szModule.decode(errors="replace").lower() == mod_name.lower():
                res = (C.cast(m.modBaseAddr, C.c_void_p).value, m.modBaseSize)
                break
            if not k32.Module32Next(snap, C.byref(m)):
                break
    k32.CloseHandle(snap)
    return res


class Proc:
    def __init__(self, exe="Achilles-Win64-Shipping.exe"):
        self.pid = find_pid(exe)
        if self.pid is None:
            raise RuntimeError(f"process not running: {exe}")
        self.h = k32.OpenProcess(PROCESS_ALL_ACCESS, False, self.pid)
        if not self.h:
            raise OSError(f"OpenProcess failed ({C.get_last_error()}) - run as Administrator?")
        mod = find_module(self.pid, exe)
        if not mod:
            raise RuntimeError("main module not found")
        self.base, self.size = mod
        self.exe_path = self._image_path()

    def _image_path(self):
        """Full path of the target's main image (so we can check the build)."""
        buf = C.create_unicode_buffer(MAX_PATH * 4)
        n = W.DWORD(len(buf))
        k32.QueryFullProcessImageNameW.argtypes = [W.HANDLE, W.DWORD,
                                                   C.c_wchar_p, C.POINTER(W.DWORD)]
        if k32.QueryFullProcessImageNameW(self.h, 0, buf, C.byref(n)):
            return buf.value
        return None

    # ---- raw ----
    def read(self, addr, n):
        buf = (C.c_char * n)()
        got = C.c_size_t(0)
        ok = k32.ReadProcessMemory(self.h, C.c_void_p(addr), buf, n, C.byref(got))
        if not ok or got.value != n:
            return None
        return bytes(buf)

    def write(self, addr, data):
        n = len(data)
        buf = (C.c_char * n).from_buffer_copy(data)
        put = C.c_size_t(0)
        ok = k32.WriteProcessMemory(self.h, C.c_void_p(addr), buf, n, C.byref(put))
        return bool(ok) and put.value == n

    # ---- typed helpers ----
    def _r(self, addr, fmt, size):
        b = self.read(addr, size)
        return None if b is None else struct.unpack(fmt, b)[0]

    def u8(self, a):     return self._r(a, "<B", 1)
    def i8(self, a):     return self._r(a, "<b", 1)
    def u16(self, a):    return self._r(a, "<H", 2)
    def i32(self, a):    return self._r(a, "<i", 4)
    def u32(self, a):    return self._r(a, "<I", 4)
    def i64(self, a):    return self._r(a, "<q", 8)
    def u64(self, a):    return self._r(a, "<Q", 8)
    def f32(self, a):    return self._r(a, "<f", 4)
    def f64(self, a):    return self._r(a, "<d", 8)
    def ptr(self, a):
        v = self._r(a, "<Q", 8)
        return None if v is None else v

    def w_i32(self, a, v):   return self.write(a, struct.pack("<i", int(v)))
    def w_u32(self, a, v):   return self.write(a, struct.pack("<I", int(v) & 0xFFFFFFFF))
    def w_f32(self, a, v):   return self.write(a, struct.pack("<f", float(v)))
    def w_f64(self, a, v):   return self.write(a, struct.pack("<d", float(v)))
    def w_i64(self, a, v):   return self.write(a, struct.pack("<q", int(v)))
    def w_u8(self, a, v):    return self.write(a, struct.pack("<B", int(v) & 0xFF))

    def rva(self, off):
        return self.base + off

    def close(self):
        if getattr(self, "h", None):
            k32.CloseHandle(self.h); self.h = None
