"""Minimal DbgHelp/ctypes wrapper for querying the Achilles shipping PDB.

Loads the shipping exe + its PDB into a dbghelp symbol session so we can look up
global symbol RVAs and walk UDT (struct/class) field layouts.
"""
import ctypes as C
from ctypes import wintypes as W
import os, sys

# Override with the AOD_GAME_DIR environment variable for a non-default install.
GAME = os.environ.get(
    "AOD_GAME_DIR",
    r"C:\Program Files (x86)\Steam\steamapps\common\Age of Darkness - Final Stand")
BIN  = os.path.join(GAME, r"Achilles\Binaries\Win64")
EXE  = os.path.join(BIN, "Achilles-Win64-Shipping.exe")
DBGHELP = os.path.join(GAME, r"Engine\Binaries\ThirdParty\DbgHelp\dbghelp.dll")

BASE = 0x140000000  # nominal load base; RVA = Address - BASE

# ---- constants ----
SYMOPT_UNDNAME          = 0x00000002
SYMOPT_DEFERRED_LOADS   = 0x00000004
SYMOPT_LOAD_ANYTHING    = 0x00000040
SYMOPT_NO_PROMPTS       = 0x00080000
SYMOPT_EXACT_SYMBOLS    = 0x00000400

TI_GET_SYMTAG, TI_GET_SYMNAME, TI_GET_LENGTH, TI_GET_TYPE = 0, 1, 2, 3
TI_GET_TYPEID, TI_GET_BASETYPE, TI_FINDCHILDREN = 4, 5, 7
TI_GET_DATAKIND, TI_GET_OFFSET, TI_GET_VALUE = 8, 10, 11
TI_GET_COUNT, TI_GET_CHILDRENCOUNT = 12, 13
TI_GET_CLASSPARENTID, TI_GET_UDTKIND = 18, 24

SymTagFunction, SymTagData, SymTagPublicSymbol = 5, 7, 10
SymTagUDT, SymTagEnum, SymTagFunctionType = 11, 12, 13
SymTagPointerType, SymTagArrayType, SymTagBaseType = 14, 15, 16
SymTagTypedef, SymTagBaseClass = 17, 18

DataIsMember, DataIsStaticMember = 7, 8

MAX_SYM_NAME = 2000

# cvconst.h BasicType
BASETYPE = {0:"<NoType>",1:"void",2:"char",3:"wchar_t",6:"int",7:"uint",8:"float",
            9:"bcd",10:"bool",13:"long",14:"ulong",25:"currency",26:"date",
            27:"variant",28:"complex",29:"bit",30:"BSTR",31:"HRESULT",
            32:"char16_t",33:"char32_t",34:"char8_t"}


class SYMBOL_INFO(C.Structure):
    _fields_ = [
        ("SizeOfStruct", C.c_ulong), ("TypeIndex", C.c_ulong),
        ("Reserved", C.c_ulonglong * 2), ("Index", C.c_ulong),
        ("Size", C.c_ulong), ("ModBase", C.c_ulonglong),
        ("Flags", C.c_ulong), ("Value", C.c_ulonglong),
        ("Address", C.c_ulonglong), ("Register", C.c_ulong),
        ("Scope", C.c_ulong), ("Tag", C.c_ulong),
        ("NameLen", C.c_ulong), ("MaxNameLen", C.c_ulong),
        ("Name", C.c_char * (MAX_SYM_NAME + 1)),
    ]

PSYMBOL_INFO = C.POINTER(SYMBOL_INFO)
ENUMSYMCB = C.WINFUNCTYPE(W.BOOL, PSYMBOL_INFO, C.c_ulong, C.c_void_p)

dh = C.WinDLL(DBGHELP)
_h = C.c_void_p(0xD00D)  # fake process handle: unique session key

dh.SymSetOptions(SYMOPT_UNDNAME | SYMOPT_NO_PROMPTS | SYMOPT_LOAD_ANYTHING)
dh.SymInitialize.argtypes = [C.c_void_p, C.c_char_p, W.BOOL]
if not dh.SymInitialize(_h, BIN.encode(), False):
    raise OSError("SymInitialize failed %d" % C.get_last_error())

dh.SymLoadModuleEx.argtypes = [C.c_void_p, C.c_void_p, C.c_char_p, C.c_char_p,
                               C.c_ulonglong, C.c_ulong, C.c_void_p, C.c_ulong]
dh.SymLoadModuleEx.restype = C.c_ulonglong
_mod = dh.SymLoadModuleEx(_h, None, EXE.encode(), None, BASE, 0, None, 0)
if not _mod:
    raise OSError("SymLoadModuleEx failed %d" % C.GetLastError())

dh.SymGetTypeInfo.argtypes = [C.c_void_p, C.c_ulonglong, C.c_ulong, C.c_int, C.c_void_p]


def _ti(typeid, req, ctype=C.c_ulong):
    v = ctype()
    if not dh.SymGetTypeInfo(_h, BASE, typeid, req, C.byref(v)):
        return None
    return v.value


def _tiname(typeid):
    p = C.c_wchar_p()
    if not dh.SymGetTypeInfo(_h, BASE, typeid, TI_GET_SYMNAME, C.byref(p)):
        return None
    return p.value


def typename(tid, depth=0):
    """Best-effort readable name for a type index."""
    if tid is None or depth > 6:
        return "?"
    tag = _ti(tid, TI_GET_SYMTAG)
    if tag in (SymTagUDT, SymTagEnum, SymTagTypedef):
        return _tiname(tid) or "?"
    if tag == SymTagBaseType:
        bt = _ti(tid, TI_GET_BASETYPE)
        ln = _ti(tid, TI_GET_LENGTH, C.c_ulonglong) or 0
        n = BASETYPE.get(bt, "base%d" % (bt or -1))
        if n == "int":   n = {1:"int8",2:"int16",4:"int32",8:"int64"}.get(ln, n)
        if n == "uint":  n = {1:"uint8",2:"uint16",4:"uint32",8:"uint64"}.get(ln, n)
        if n == "float": n = {4:"float",8:"double"}.get(ln, n)
        return n
    if tag == SymTagPointerType:
        return typename(_ti(tid, TI_GET_TYPE), depth + 1) + "*"
    if tag == SymTagArrayType:
        inner = typename(_ti(tid, TI_GET_TYPE), depth + 1)
        cnt = _ti(tid, TI_GET_COUNT)
        return "%s[%s]" % (inner, cnt if cnt is not None else "")
    if tag == SymTagFunctionType:
        return "func"
    return _tiname(tid) or "tag%s" % tag


def find_symbols(mask, tags=None, limit=100000):
    """Enumerate symbols matching a dbghelp wildcard mask."""
    out = []
    def cb(psym, size, ctx):
        s = psym.contents
        if tags is None or s.Tag in tags:
            out.append({"name": s.Name.decode("utf-8", "replace"),
                        "rva": s.Address - BASE, "size": s.Size,
                        "tag": s.Tag, "typeindex": s.TypeIndex})
        return len(out) < limit
    dh.SymEnumSymbols(_h, C.c_ulonglong(BASE), mask.encode(), ENUMSYMCB(cb), None)
    return out


def get_type(name):
    si = SYMBOL_INFO()
    si.SizeOfStruct = C.sizeof(SYMBOL_INFO) - (MAX_SYM_NAME + 1)
    si.MaxNameLen = MAX_SYM_NAME
    dh.SymGetTypeFromName.argtypes = [C.c_void_p, C.c_ulonglong, C.c_char_p, PSYMBOL_INFO]
    if not dh.SymGetTypeFromName(_h, BASE, name.encode(), C.byref(si)):
        return None
    return si.TypeIndex


def children(tid):
    n = _ti(tid, TI_GET_CHILDRENCOUNT)
    if not n:
        return []
    class P(C.Structure):
        _fields_ = [("Count", C.c_ulong), ("Start", C.c_ulong), ("ChildId", C.c_ulong * n)]
    p = P(); p.Count = n; p.Start = 0
    if not dh.SymGetTypeInfo(_h, BASE, tid, TI_FINDCHILDREN, C.byref(p)):
        return []
    return list(p.ChildId)


def layout(name, _seen=None, base_off=0, depth=0):
    """Return [(offset, size, membername, typename)] for a class, incl. base classes."""
    tid = get_type(name) if isinstance(name, str) else name
    if tid is None:
        return None
    rows = []
    for cid in children(tid):
        tag = _ti(cid, TI_GET_SYMTAG)
        if tag == SymTagBaseClass:
            off = _ti(cid, TI_GET_OFFSET, C.c_long) or 0
            bt = _ti(cid, TI_GET_TYPE)
            sub = layout(bt, base_off=base_off + off, depth=depth + 1) or []
            rows.extend(sub)
        elif tag == SymTagData:
            dk = _ti(cid, TI_GET_DATAKIND)
            if dk != DataIsMember:
                continue
            off = _ti(cid, TI_GET_OFFSET, C.c_long)
            if off is None:
                continue
            mt = _ti(cid, TI_GET_TYPE)
            sz = _ti(mt, TI_GET_LENGTH, C.c_ulonglong) or 0
            rows.append((base_off + off, sz, _tiname(cid), typename(mt)))
    rows.sort(key=lambda r: r[0])
    return rows


def sizeof(name):
    tid = get_type(name)
    return None if tid is None else _ti(tid, TI_GET_LENGTH, C.c_ulonglong)


ENUMTYPECB = ENUMSYMCB


def find_type(mask, limit=200):
    """Look up type (UDT/enum) indices by name mask via SymEnumTypesByName."""
    out = []
    def cb(psym, size, ctx):
        s = psym.contents
        out.append((s.Name.decode("utf-8", "replace"), s.TypeIndex, s.Size))
        return len(out) < limit
    dh.SymEnumTypesByName.argtypes = [C.c_void_p, C.c_ulonglong, C.c_char_p,
                                      ENUMTYPECB, C.c_void_p]
    dh.SymEnumTypesByName(_h, C.c_ulonglong(BASE), mask.encode(), ENUMTYPECB(cb), None)
    return out


def type_id(name):
    """Exact-name type index."""
    for n, tid, sz in find_type(name):
        if n == name:
            return tid
    return None


def show(name_or_tid, title=None):
    tid = name_or_tid if isinstance(name_or_tid, int) else type_id(name_or_tid)
    if tid is None:
        print("### %s: NOT FOUND" % (title or name_or_tid)); return None
    ln = _ti(tid, TI_GET_LENGTH, C.c_ulonglong) or 0
    print("### %s  sizeof=0x%X" % (title or name_or_tid, ln))
    L = layout(tid) or []
    for off, sz, nm, ty in L:
        print("   +0x%04X [%5d] %-34s %s" % (off, sz, nm, ty))
    return L
