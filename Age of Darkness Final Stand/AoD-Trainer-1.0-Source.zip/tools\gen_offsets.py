"""Generate aod/offsets.json from the shipping PDB.

Re-run this after a game patch; everything downstream reads the JSON, so a new
build only needs this one step (assuming the devs keep shipping the PDB).
"""
import json, os, sys, hashlib
import pdbdump as P

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "aod", "offsets.json")

GLOBALS = ["GUObjectArray", "NamePoolData", "GEngine", "GWorld"]

# type -> members we care about
STRUCTS = {
    "FUObjectArray":            ["ObjObjects"],
    "FChunkedFixedUObjectArray":["Objects", "PreAllocatedObjects", "MaxElements",
                                 "NumElements", "MaxChunks", "NumChunks"],
    "FUObjectItem":             ["Object", "Flags", "ClusterRootIndex", "SerialNumber"],
    "UObjectBase":              ["ObjectFlags", "InternalIndex", "ClassPrivate",
                                 "NamePrivate", "OuterPrivate"],
    "UStruct":                  ["SuperStruct", "Children", "ChildProperties",
                                 "PropertiesSize"],
    "UClass":                   ["ClassDefaultObject", "ClassFlags", "ClassCastFlags"],
    "FField":                   ["ClassPrivate", "Owner", "Next", "NamePrivate"],
    "FProperty":                ["ArrayDim", "ElementSize", "PropertyFlags",
                                 "Offset_Internal"],
    "FFieldClass":              ["Name", "Id", "CastFlags", "SuperClass"],
    "FName":                    ["ComparisonIndex", "Number"],
    "FNameEntryAllocator":      ["CurrentBlock", "CurrentByteCursor", "Blocks"],
    "FNamePool":                ["Entries"],
    # --- game simulation ---
    "USimulationHandler":       ["GameStates", "Play", "SimStates", "SimWorld",
                                 "FrameCounter", "SimTickCounter", "LocalPlayerIdx",
                                 "EnableSimTick", "EnableSimRender", "MatchStartTime"],
    "world_data":               ["smp", "local_player_index", "local_player_team_index",
                                 "ue_world", "achilles_hud", "achilles_pc", "globals",
                                 "agents", "buildings", "entities", "projectiles",
                                 "resources", "waves", "research_systems", "objectives",
                                 "triggers", "stats", "time_of_day", "pause_state",
                                 "fog_of_war_map", "darkness_map", "resource_map",
                                 "allegiances", "players", "is_server",
                                 "disable_resources_tick", "disable_building",
                                 "disable_skill_tree", "disable_selling", "disable_repair",
                                 "tickable_resources", "is_starting", "has_finished_setup",
                                 "sim_state", "game_rng"],
    "world_resources":          ["world", "per_team_sim_state"],
    "world_resources::sim_state_data": ["current", "max", "agent_upkeep",
                                        "agent_upkeep_per_tick", "agent_upkeep_count",
                                        "market_current", "market_max",
                                        "market_excess_exchange", "trigger_action_changes"],
    "FFixedResourceCost":       ["food", "gold", "iron", "stone", "villagers",
                                 "wood", "darkness"],
    "FResourceCost":            ["food", "gold", "iron", "stone", "villagers",
                                 "wood", "darkness"],
    "sim_ptr_base":             ["parent", "index_in_parent", "should_serialise",
                                 "is_large", "element_count", "max_element_count",
                                 "bytes_per_element", "element_group_size",
                                 "buffer_offset"],
    "simulation_memory_pool":   ["buffer", "buffer_used", "buffer_size"],
    "per_player_data":          ["team_index", "last_heartbeat_frame"],
}


def main():
    out = {"engine": "UE4.26.2", "globals": {}, "sizeof": {}, "structs": {}}

    exe = P.EXE
    h = hashlib.sha256()
    with open(exe, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    out["exe_sha256"] = h.hexdigest()
    out["exe_size"] = os.path.getsize(exe)

    for g in GLOBALS:
        hits = [s for s in P.find_symbols(g) if s["name"] == g]
        if not hits:
            print("!! missing global", g); continue
        out["globals"][g] = hits[0]["rva"]
        print("global %-16s rva=0x%08X" % (g, hits[0]["rva"]))

    for tname, members in STRUCTS.items():
        tid = P.type_id(tname)
        if tid is None:
            print("!! missing type", tname); continue
        import ctypes as C
        out["sizeof"][tname] = P._ti(tid, P.TI_GET_LENGTH, C.c_ulonglong)
        L = P.layout(tid) or []
        by = {}
        for off, sz, nm, ty in L:
            if nm in members and nm not in by:
                by[nm] = {"off": off, "size": sz, "type": ty}
        miss = [m for m in members if m not in by]
        if miss:
            print("!! %s missing members: %s" % (tname, miss))
        out["structs"][tname] = by
        print("type %-34s sizeof=0x%-6X members=%d" % (tname, out["sizeof"][tname] or 0, len(by)))

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(out, f, indent=1, sort_keys=True)
    print("\nwrote", os.path.abspath(OUT))


if __name__ == "__main__":
    main()
