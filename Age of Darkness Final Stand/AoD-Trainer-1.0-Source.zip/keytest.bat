@echo off
cd /d "%~dp0"
python trainer.py --keytest
pause
