"""UE 4.26 runtime reflection over an external process.

Resolves FNames out of the FNamePool and walks GUObjectArray so objects can be
found by class name. All layout constants come from offsets.json (generated from
the shipping PDB by tools/gen_offsets.py).
"""
import json, os, struct, sys

# Under a PyInstaller onefile build the package lives in the archive, so the data
# file is unpacked next to it in _MEIPASS instead of beside __file__.
if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    _HERE = os.path.join(sys._MEIPASS, "aod")
else:
    _HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_HERE, "offsets.json")) as f:
    OFF = json.load(f)

G = OFF["globals"]
S = OFF["structs"]


def o(struct_name, member):
    return S[struct_name][member]["off"]


# FNamePool block geometry (UE4.25+): FNameEntry alignment is 2, 65536 offsets/block
NAME_STRIDE = 2
NAME_BLOCK_OFFSET_BITS = 16
NAME_BLOCK_SIZE = NAME_STRIDE * (1 << NAME_BLOCK_OFFSET_BITS)


class Names:
    """Lazy FName resolver; caches whole 128 KiB pool blocks."""

    def __init__(self, p):
        self.p = p
        self.pool = p.rva(G["NamePoolData"])
        self.blocks_addr = self.pool + o("FNamePool", "Entries") + o("FNameEntryAllocator", "Blocks")
        self.cur_block = p.u32(self.pool + o("FNamePool", "Entries") + o("FNameEntryAllocator", "CurrentBlock"))
        self._blockcache = {}
        self._cache = {}

    def _block(self, idx):
        b = self._blockcache.get(idx)
        if b is not None:
            return b
        ptr = self.p.ptr(self.blocks_addr + idx * 8)
        if not ptr:
            return None
        data = self.p.read(ptr, NAME_BLOCK_SIZE)
        if data is None:  # tail block may be partially committed
            for sz in (NAME_BLOCK_SIZE // 2, NAME_BLOCK_SIZE // 4, 0x10000, 0x1000):
                data = self.p.read(ptr, sz)
                if data is not None:
                    break
        self._blockcache[idx] = data
        return data

    def get(self, entry_id):
        """Resolve an FNameEntryId (comparison index) to its string."""
        if entry_id in self._cache:
            return self._cache[entry_id]
        blk_i = entry_id >> NAME_BLOCK_OFFSET_BITS
        blk_o = (entry_id & 0xFFFF) * NAME_STRIDE
        data = self._block(blk_i)
        if data is None or blk_o + 2 > len(data):
            return None
        hdr = struct.unpack_from("<H", data, blk_o)[0]
        is_wide = hdr & 1
        ln = hdr >> 6                     # bIsWide:1, LowercaseProbeHash:5, Len:10
        if ln == 0 or ln > 1024:
            return None
        start = blk_o + 2
        nbytes = ln * (2 if is_wide else 1)
        if start + nbytes > len(data):
            return None
        raw = data[start:start + nbytes]
        s = raw.decode("utf-16-le", "replace") if is_wide else raw.decode("utf-8", "replace")
        self._cache[entry_id] = s
        return s

    def fname(self, addr):
        """Read an FName at `addr` and render it (with _N suffix if Number != 0)."""
        v = self.p.read(addr, 8)
        if v is None:
            return None
        idx, num = struct.unpack("<II", v)
        s = self.get(idx)
        if s is None:
            return None
        return s if num == 0 else "%s_%d" % (s, num - 1)


class Objects:
    """GUObjectArray walker."""

    def __init__(self, p, names):
        self.p = p
        self.names = names
        ga = p.rva(G["GUObjectArray"])
        self.chunked = ga + o("FUObjectArray", "ObjObjects")
        c = self.chunked
        self.objects_ptr = p.ptr(c + o("FChunkedFixedUObjectArray", "Objects"))
        self.max_elements = p.i32(c + o("FChunkedFixedUObjectArray", "MaxElements"))
        self.num_elements = p.i32(c + o("FChunkedFixedUObjectArray", "NumElements"))
        self.max_chunks = p.i32(c + o("FChunkedFixedUObjectArray", "MaxChunks"))
        self.num_chunks = p.i32(c + o("FChunkedFixedUObjectArray", "NumChunks"))
        self.per_chunk = (self.max_elements // self.max_chunks) if self.max_chunks else 0
        self.item_size = OFF["sizeof"]["FUObjectItem"]

    def refresh(self):
        c = self.chunked
        self.num_elements = self.p.i32(c + o("FChunkedFixedUObjectArray", "NumElements"))
        self.num_chunks = self.p.i32(c + o("FChunkedFixedUObjectArray", "NumChunks"))

    def iter_objects(self):
        """Yield (index, object_address) for every live UObject."""
        self.refresh()
        n = self.num_elements
        idx = 0
        for ci in range(self.num_chunks):
            chunk = self.p.ptr(self.objects_ptr + ci * 8)
            if not chunk:
                idx += self.per_chunk
                continue
            count = min(self.per_chunk, n - idx)
            if count <= 0:
                break
            blob = self.p.read(chunk, count * self.item_size)
            if blob is None:
                for j in range(count):
                    a = self.p.ptr(chunk + j * self.item_size)
                    if a:
                        yield idx + j, a
                idx += count
                continue
            for j in range(count):
                a = struct.unpack_from("<Q", blob, j * self.item_size)[0]
                if a:
                    yield idx + j, a
            idx += count

    # ---- UObject accessors ----
    def obj_class(self, obj):
        return self.p.ptr(obj + o("UObjectBase", "ClassPrivate"))

    def obj_name(self, obj):
        return self.names.fname(obj + o("UObjectBase", "NamePrivate"))

    def obj_outer(self, obj):
        return self.p.ptr(obj + o("UObjectBase", "OuterPrivate"))

    def class_name(self, cls):
        return self.obj_name(cls) if cls else None

    def super_class(self, cls):
        return self.p.ptr(cls + o("UStruct", "SuperStruct"))

    def class_chain(self, cls, limit=32):
        out = []
        seen = set()
        while cls and cls not in seen and len(out) < limit:
            seen.add(cls)
            out.append(self.class_name(cls))
            cls = self.super_class(cls)
        return out

    def full_name(self, obj):
        parts = []
        cur, guard = obj, 0
        while cur and guard < 16:
            n = self.obj_name(cur)
            if not n:
                break
            parts.append(n)
            cur = self.obj_outer(cur)
            guard += 1
        return ".".join(reversed(parts))

    # ---- lookup ----
    def find_by_class(self, class_name, exact=True, include_defaults=False):
        """All objects whose class (or any ancestor, if exact=False) matches."""
        out = []
        cache = {}
        for i, obj in self.iter_objects():
            cls = self.obj_class(obj)
            if not cls:
                continue
            hit = cache.get(cls)
            if hit is None:
                if exact:
                    hit = (self.class_name(cls) == class_name)
                else:
                    hit = class_name in self.class_chain(cls)
                cache[cls] = hit
            if hit:
                if not include_defaults:
                    nm = self.obj_name(obj) or ""
                    if nm.startswith("Default__"):
                        continue
                out.append(obj)
        return out

    def find_one(self, class_name, exact=True):
        r = self.find_by_class(class_name, exact=exact)
        return r[0] if r else None
