<#
  Builds the two distributables.

    dist\AoD-Trainer-<ver>.zip          runnable - one exe, no Python needed
    dist\AoD-Trainer-<ver>-Source.zip   full source incl. the PDB tooling

  The game's PDB is never redistributed; only the offsets extracted from it.
#>
param([string]$Version = "1.0")

$ErrorActionPreference = "Stop"
$root  = $PSScriptRoot
$dist  = Join-Path $root "dist"
$stage = Join-Path $root "build\stage"

Write-Host "== cleaning ==" -ForegroundColor Cyan
foreach ($d in @($dist, (Join-Path $root "build"))) {
    if (Test-Path $d) { Remove-Item $d -Recurse -Force }
}
New-Item -ItemType Directory -Force -Path $dist  | Out-Null
New-Item -ItemType Directory -Force -Path $stage | Out-Null

# ---------------------------------------------------------------- binary build
Write-Host "== building exe ==" -ForegroundColor Cyan
$addData = "$(Join-Path $root 'aod\offsets.json');aod"

# PyInstaller logs INFO to stderr; under PS 5.1 with ErrorActionPreference=Stop
# that surfaces as a terminating NativeCommandError even on a clean exit 0.
# Scope the preference around the native call and judge it by $LASTEXITCODE.
$prevEAP = $ErrorActionPreference
$ErrorActionPreference = "Continue"
python -m PyInstaller --noconfirm --clean --onefile `
    --name AoDTrainer `
    --distpath (Join-Path $root "build\bin") `
    --workpath (Join-Path $root "build\work") `
    --specpath (Join-Path $root "build") `
    --add-data $addData `
    --hidden-import diag `
    --paths $root `
    (Join-Path $root "trainer.py")
$rc = $LASTEXITCODE
$ErrorActionPreference = $prevEAP
if ($rc -ne 0) { throw "PyInstaller failed (exit $rc)" }

$exe = Join-Path $root "build\bin\AoDTrainer.exe"
if (-not (Test-Path $exe)) { throw "exe not produced" }
Write-Host ("   AoDTrainer.exe {0:N1} MB" -f ((Get-Item $exe).Length / 1MB))

# ------------------------------------------------------------- trainer package
Write-Host "== trainer package ==" -ForegroundColor Cyan
$tdir = Join-Path $stage "AoD-Trainer"
New-Item -ItemType Directory -Force -Path $tdir | Out-Null
Copy-Item $exe $tdir
Copy-Item (Join-Path $root "README-USER.txt") (Join-Path $tdir "README.txt")
@'
@echo off
cd /d "%~dp0"
AoDTrainer.exe
'@ | Set-Content (Join-Path $tdir "run.bat") -Encoding ascii
@'
@echo off
cd /d "%~dp0"
AoDTrainer.exe --diag
pause
'@ | Set-Content (Join-Path $tdir "diagnose.bat") -Encoding ascii

Compress-Archive -Path "$tdir\*" -DestinationPath (Join-Path $dist "AoD-Trainer-$Version.zip") -Force

# -------------------------------------------------------------- source package
Write-Host "== source package ==" -ForegroundColor Cyan
$sdir = Join-Path $stage "AoD-Trainer-Source"
New-Item -ItemType Directory -Force -Path $sdir | Out-Null
foreach ($f in @("trainer.py", "diag.py", "README.md", "README-USER.txt",
                 "package.ps1", "run.bat", "diag.bat", "keytest.bat")) {
    Copy-Item (Join-Path $root $f) $sdir
}
foreach ($sub in @("aod", "tools")) {
    $target = Join-Path $sdir $sub
    Copy-Item (Join-Path $root $sub) $target -Recurse
    Get-ChildItem $target -Recurse -Directory -Filter "__pycache__" |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}
Compress-Archive -Path "$sdir\*" -DestinationPath (Join-Path $dist "AoD-Trainer-$Version-Source.zip") -Force

Write-Host "== done ==" -ForegroundColor Green
Get-ChildItem $dist | ForEach-Object {
    Write-Host ("   {0,-38} {1,8:N0} KB" -f $_.Name, ($_.Length / 1KB))
}
