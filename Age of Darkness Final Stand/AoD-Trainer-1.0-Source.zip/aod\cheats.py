"""Cheat registry.

Every cheat is a self-contained object appended to REGISTRY; the trainer loop only
iterates. Adding a cheat is one entry here and nothing else changes.

Why "hold at max" rather than "set to 999999": world_resources::update() rebuilds
the `max` block from scratch every simulation tick (it zeroes max, then sums each
building's storage contribution back in) and clamps `current` to it. A written max
is gone within one tick, and a written current is capped to the real max. Holding
current at max is therefore the strongest cheat available without patching code --
and it is effectively unlimited, because spending refills within a tick.
"""
from .game import RESOURCES

# Verified by observation against a live match:
#   gold / iron / stone / wood  - real stockpiles; a written value holds.
#   food / villagers            - derived population counters, recomputed every
#                                 tick from live units (see agent_upkeep_count).
#                                 Writing them is pointless; they snap back in
#                                 one tick. Their caps come from buildings.
#   darkness                    - a meter; writes hold.
STOCKPILES = ["gold", "iron", "stone", "wood"]
DERIVED = ["food", "villagers"]

REGISTRY = []


def register(c):
    REGISTRY.append(c)
    return c


class Cheat:
    """A toggleable effect. `tick` re-applies it while enabled, which is what beats
    the simulation writing the value back on its own tick."""
    id = "?"
    label = "?"
    detail = ""
    needs_match = True

    def __init__(self):
        self.enabled = False

    def toggle(self, g):
        self.enabled = not self.enabled
        (self.on_enable if self.enabled else self.on_disable)(g)
        return self.enabled

    def on_enable(self, g):  pass
    def on_disable(self, g): pass
    def tick(self, g):       pass

    def status(self, g):
        return "ON" if self.enabled else "off"


class HoldAtMax(Cheat):
    """Keep the named resources pinned to their current storage cap."""

    def __init__(self, cid, label, resources, detail=None):
        super().__init__()
        self.id, self.label, self.resources = cid, label, resources
        self.detail = detail or ("keep %s at storage cap" % ", ".join(resources))

    def tick(self, g):
        mx = g.read_block("max")
        if not mx:
            return
        g.write_block({r: mx[r] for r in self.resources}, block="current")


class HoldAtValue(Cheat):
    """Keep the named resources at a fixed value. Values above the storage cap are
    clamped by the simulation on its next tick; below the cap they hold."""

    def __init__(self, cid, label, resources, amount, detail=None):
        super().__init__()
        self.id, self.label, self.resources, self.amount = cid, label, resources, amount
        self.detail = detail or ("hold %s at %g" % (", ".join(resources), amount))

    def tick(self, g):
        g.write_block({r: self.amount for r in self.resources}, block="current")


class WorldFlag(Cheat):
    """Flip a bool that lives directly on world_data."""

    def __init__(self, cid, label, member, value=True, detail=""):
        super().__init__()
        self.id, self.label, self.member, self.value = cid, label, member, value
        self.detail = detail or ("world_data.%s = %s" % (member, value))
        self._prev = None

    def on_enable(self, g):
        self._prev = g.get_flag(self.member)
        g.set_flag(self.member, self.value)

    def on_disable(self, g):
        g.set_flag(self.member, self._prev if self._prev is not None else (not self.value))

    def tick(self, g):
        g.set_flag(self.member, self.value)

    def status(self, g):
        live = g.get_flag(self.member)
        base = "ON" if self.enabled else "off"
        return base if live is None else "%s [%d]" % (base, 1 if live else 0)


# --------------------------------------------------------------------------
# The registry. Order here is the order shown in the UI and the hotkey order.
# --------------------------------------------------------------------------
register(HoldAtMax("res_stock", "Stockpiles full", STOCKPILES,
                   "gold, iron, stone, wood pinned to cap - spend freely, refills each tick"))
register(HoldAtMax("res_gold", "Gold full", ["gold"]))
register(HoldAtValue("no_darkness", "Purge darkness", ["darkness"], 0.0,
                     "hold darkness at 0"))
register(WorldFlag("no_tick", "Freeze resource tick", "disable_resources_tick", True,
                   "gates income/upkeep; does NOT lift the storage cap"))


def by_id(cid):
    return next((c for c in REGISTRY if c.id == cid), None)
