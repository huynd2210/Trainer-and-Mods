# Age of Darkness: Final Stand — trainer

External (read/write process memory) trainer. Nothing is injected into the game and
no game file is modified, so there is nothing to uninstall and no DLL to swap — you
can edit and restart the trainer with the game left running.

**Single-player only.** The game runs a deterministic fixed-point lockstep
simulation. Writing simulation state on one client will desync every other client
in multiplayer.

## Run

Start the game, get into a match, then:

```bash
python trainer.py
```

or double-click `run.bat`. Hotkeys are global, so they work while the game has
focus. `python diag.py` prints everything the trainer can see — run that first if
something looks wrong.

Administrator is not required (same-user process).

## Hotkeys

| Key | Action |
|-----|--------|
| `Ctrl+Alt+1` | Stockpiles full — gold, iron, stone, wood pinned to cap |
| `Ctrl+Alt+2` | Gold full |
| `Ctrl+Alt+3` | Purge darkness (hold at 0) |
| `Ctrl+Alt+4` | Freeze resource tick |
| `Ctrl+Alt+R` | Re-scan (after a map load) |
| `Ctrl+Alt+Q` | Quit |

Toggles are re-applied every loop, which is what beats the simulation writing the
value back on its own tick.

Input is polled with `GetAsyncKeyState` on a dedicated thread, so game discovery
and console output do not block key capture. Completed chords are queued for the
main thread to handle. Both top-row digits and numpad digits (Num Lock on) work;
the modifiers and action key can be pressed in either order. Release any part of
the chord before pressing it again to toggle back. The
status line shows `held: [CTRL ALT]` live, so you can see whether the trainer is
seeing your modifier keys.

If a key does nothing, run `keytest.bat` (or `python trainer.py --keytest`). It
prints every chord it sees for 20 seconds and nothing else — that separates "the
trainer isn't seeing the key" from "the key was seen but the cheat did nothing".

### Why "full" and not "999999"

`world_resources::update()` runs every simulation tick and **rebuilds the `max`
block from scratch** — it zeroes max (at `update+0x67`), sums each building's
storage contribution back in (`update+0xF6C`), then clamps `current` to it. So a
written `max` is gone within one tick, and a written `current` is capped to the
real cap. Pinning `current` to `max` is the strongest cheat available without
patching code, and it is effectively unlimited: you spend, and it refills on the
next tick.

Raising the cap itself needs a code patch (NOP the four max-zeroing instructions at
`update+0x67`, then hold `max` at a target from the trainer). That is not shipped —
it writes to code in a live process and can crash a running match.

### What cannot be cheated by writing

`food` and `villagers` are **not stockpiles**. They are population counters
recomputed every tick from live units — a written value snaps back within one tick
(verified). `current` is what's in use, `max` is your housing/food capacity from
buildings. `agent_upkeep_count` is the underlying count. Raising them means
building, not writing.

## How it works

The game is Unreal Engine 4.26.2 and ships its full shipping PDB
(`Achilles-Win64-Shipping.pdb`, 855 MB), so every symbol address and struct layout
is exact rather than pattern-scanned.

Gameplay does **not** live in UObjects. There is a separate deterministic
simulation layer (lowercase C-style types: `world_data`, `agent_database`,
`simulation_memory_pool`) using `fpm::fixed<int,int64,10>` — Q10 fixed point, so a
stored `int32` is the real value × 1024. Simulation state is addressed by
`sim_ptr<T>` handles into a pooled buffer, not raw pointers.

Access path:

```
GUObjectArray                     (RVA 0x054FA8C8)
  -> USimulationHandler           (found by class name via UE reflection)
  -> +0x830 SimWorld              -> world_data
  -> +0x660 resources             -> world_resources
  -> +0x08  per_team_sim_state    -> sim_ptr<sim_state_data>
     resolved as pool->buffer + buffer_offset + team * bytes_per_element
  -> +0x00  current               -> FFixedResourceCost
     { food, gold, iron, stone, villagers, wood, darkness }  (7 x int32 Q10)
```

Names come from `NamePoolData` (RVA 0x054E1C80). This build has
`WITH_CASE_PRESERVING_NAME=0`, so `FName` is 8 bytes (ComparisonIndex + Number) and
the entry header packs `bIsWide:1, LowercaseProbeHash:5, Len:10` — the length is
`header >> 6`.

## Layout

```
aod/mem.py       ReadProcessMemory / WriteProcessMemory + typed helpers
aod/ue.py        UE 4.26 reflection: FName pool, GUObjectArray, find-by-class
aod/game.py      world_data / world_resources / sim_ptr resolution
aod/cheats.py    cheat registry - adding a cheat is one entry, nothing dispatches
aod/offsets.json generated; every layout constant lives here
tools/pdbdump.py DbgHelp+ctypes PDB reader (symbol RVAs, UDT field offsets)
tools/gen_offsets.py  regenerates aod/offsets.json from the PDB
tools/classes.txt     2996 native UClass names, for reference
diag.py          prints what the trainer sees; run this to debug
trainer.py       the trainer
```

## After a game patch

```bash
python tools/gen_offsets.py
```

That re-reads the shipping PDB and rewrites `aod/offsets.json`. It prints a `!!`
line for anything it could not find, which is your signal that a struct changed
shape. `offsets.json` records the exe SHA-256 it was generated from.

If a future patch stops shipping the PDB, this whole approach needs replacing with
signature scanning — `tools/pdbdump.py` is the only thing that reads it, but every
offset flows from it.

## Status

Everything below was verified against a live match.

- attach, module base, read/write without elevation
- FName pool resolution (`id 0` -> `None`, object names read correctly)
- `GUObjectArray` walk — 526,770 objects in 0.08 s; `Class` count matches the 2996
  native classes found in the PDB
- `USimulationHandler` -> `world_data` discovery
- `sim_ptr` resolution — 8 team slots, stride 252 = `sizeof(sim_state_data)`,
  and the computed address matches the game's own cached pointer at
  `world_resources+0x68`
- resource decode — a starting position read back as food 16/50, gold 100/500,
  iron 0/50, stone 0/50, villagers 4/10, wood 20/50, which is exactly right and
  confirms the Q10 fixed-point conversion
- writes: gold, iron, stone, wood and darkness hold; food and villagers do not
  (see above)
- every cheat currently in the registry

## Ideas not yet built

`world_data` also exposes `agents`, `buildings`, `projectiles`, `research_systems[8]`,
`waves`, `objectives`, `triggers`, `fog_of_war_map` and `darkness_map`, plus the
flags `disable_building`, `disable_selling`, `disable_repair` and `disable_skill_tree`.
God mode, instant research, instant build and map reveal all look reachable from
there by the same pattern — find the table, write the field, re-apply each tick.
