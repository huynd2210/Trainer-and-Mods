"""Age of Darkness: Final Stand simulation access.

The game runs a deterministic fixed-point lockstep simulation (`world_data`)
alongside the UE object graph. Simulation state lives in a `simulation_memory_pool`
and is addressed through `sim_ptr<T>` handles rather than raw pointers.

Entry path:  GUObjectArray -> USimulationHandler -> SimWorld (world_data*)
"""
import struct
from .mem import Proc
from .ue import Names, Objects, OFF, S, o

FRAC_BITS = 10                 # fpm::fixed<int, int64, 10>
FIXED_ONE = 1 << FRAC_BITS

RESOURCES = ["food", "gold", "iron", "stone", "villagers", "wood", "darkness"]

# world_resources::sim_state_data blocks that are FFixedResourceCost
RESOURCE_BLOCKS = ["current", "max", "agent_upkeep", "agent_upkeep_per_tick",
                   "agent_upkeep_count", "market_current", "market_max",
                   "market_excess_exchange", "trigger_action_changes"]


def to_fixed(v):
    return int(round(float(v) * FIXED_ONE))


def from_fixed(raw):
    return raw / float(FIXED_ONE)


class SimPtr:
    """A resolved sim_ptr<T>: an element array inside the simulation memory pool."""

    def __init__(self, p, addr):
        self.p = p
        self.addr = addr
        b = lambda m: o("sim_ptr_base", m)
        self.pool = p.ptr(addr + b("parent"))
        self.element_count = p.u32(addr + b("element_count"))
        self.max_element_count = p.u32(addr + b("max_element_count"))
        self.bytes_per_element = p.u32(addr + b("bytes_per_element"))
        self.buffer_offset = p.u32(addr + b("buffer_offset"))
        self.buffer = p.ptr(self.pool + o("simulation_memory_pool", "buffer")) if self.pool else None
        self.buffer_size = p.u32(self.pool + o("simulation_memory_pool", "buffer_size")) if self.pool else 0

    @property
    def valid(self):
        return bool(self.buffer) and bool(self.bytes_per_element)

    def element(self, i):
        """Address of element i, or None if out of range / unresolvable."""
        if not self.valid or i < 0 or i >= max(self.element_count, 1):
            return None
        off = self.buffer_offset + i * self.bytes_per_element
        if self.buffer_size and off + self.bytes_per_element > self.buffer_size:
            return None
        return self.buffer + off

    def __repr__(self):
        return ("SimPtr(buffer=0x%X off=0x%X count=%s/%s stride=%s)"
                % (self.buffer or 0, self.buffer_offset, self.element_count,
                   self.max_element_count, self.bytes_per_element))


class Game:
    """Attached game session. Re-call `locate()` after a map load."""

    def __init__(self, proc=None):
        self.p = proc or Proc()
        self.names = Names(self.p)
        self.objs = Objects(self.p, self.names)
        self.sim_handler = None
        self.world = None

    # ---------- discovery ----------
    def locate(self, verbose=False):
        """Find USimulationHandler and world_data. Returns True if in a live match."""
        self.sim_handler = None
        self.world = None
        for obj in self.objs.find_by_class("SimulationHandler", exact=True):
            w = self.p.ptr(obj + o("USimulationHandler", "SimWorld"))
            if self._plausible_world(w):
                self.sim_handler, self.world = obj, w
                break
            if self.sim_handler is None:
                self.sim_handler = obj
        if verbose:
            print("sim_handler=0x%X world=0x%X"
                  % (self.sim_handler or 0, self.world or 0))
        return self.world is not None

    def _plausible_world(self, w):
        """world_data sanity check: vtable + pool + resources all look like pointers."""
        if not w or w < 0x10000 or w > 0x7FFFFFFFFFFF:
            return False
        for m in ("smp", "resources"):
            v = self.p.ptr(w + o("world_data", m))
            if not v or v < 0x10000 or v > 0x7FFFFFFFFFFF:
                return False
        return True

    # ---------- world fields ----------
    def wfield(self, member):
        return None if self.world is None else self.world + o("world_data", member)

    @property
    def local_player_index(self):
        return self.p.u8(self.wfield("local_player_index"))

    @property
    def local_team_index(self):
        return self.p.u8(self.wfield("local_player_team_index"))

    @property
    def frame(self):
        if not self.sim_handler:
            return None
        return self.p.u32(self.sim_handler + o("USimulationHandler", "FrameCounter"))

    @property
    def sim_tick(self):
        if not self.sim_handler:
            return None
        return self.p.i32(self.sim_handler + o("USimulationHandler", "SimTickCounter"))

    @property
    def is_server(self):
        return bool(self.p.u8(self.wfield("is_server")))

    def player_team(self, player_index):
        base = self.wfield("players")
        if base is None:
            return None
        return self.p.u8(base + player_index * OFF["sizeof"]["per_player_data"]
                         + o("per_player_data", "team_index"))

    # ---------- resources ----------
    def resources_ptr(self):
        wr = self.p.ptr(self.wfield("resources"))
        if not wr:
            return None
        return SimPtr(self.p, wr + o("world_resources", "per_team_sim_state"))

    def team_state(self, team=None):
        """Address of world_resources::sim_state_data for a team."""
        sp = self.resources_ptr()
        if sp is None or not sp.valid:
            return None
        if team is None:
            team = self.local_team_index or 0
        return sp.element(team)

    def block_addr(self, block, team=None):
        st = self.team_state(team)
        if st is None:
            return None
        return st + o("world_resources::sim_state_data", block)

    def read_block(self, block="current", team=None):
        a = self.block_addr(block, team)
        if a is None:
            return None
        raw = self.p.read(a, OFF["sizeof"]["FFixedResourceCost"])
        if raw is None:
            return None
        out = {}
        for r in RESOURCES:
            off = o("FFixedResourceCost", r)
            out[r] = from_fixed(struct.unpack_from("<i", raw, off)[0])
        return out

    def write_resource(self, name, value, block="current", team=None):
        a = self.block_addr(block, team)
        if a is None:
            return False
        return self.p.w_i32(a + o("FFixedResourceCost", name), to_fixed(value))

    def write_block(self, values, block="current", team=None):
        ok = True
        for k, v in values.items():
            if k in RESOURCES:
                ok &= bool(self.write_resource(k, v, block, team))
        return ok

    def teams_with_state(self, limit=8):
        sp = self.resources_ptr()
        if sp is None or not sp.valid:
            return []
        return list(range(min(sp.element_count or 0, limit)))

    # ---------- toggles living directly on world_data ----------
    def get_flag(self, member):
        a = self.wfield(member)
        return None if a is None else bool(self.p.u8(a))

    def set_flag(self, member, on):
        a = self.wfield(member)
        return False if a is None else self.p.w_u8(a, 1 if on else 0)

    def close(self):
        self.p.close()
