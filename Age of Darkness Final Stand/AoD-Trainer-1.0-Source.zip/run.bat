@echo off
cd /d "%~dp0"
python trainer.py
pause
