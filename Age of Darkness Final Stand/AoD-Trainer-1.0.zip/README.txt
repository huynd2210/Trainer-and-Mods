Age of Darkness: Final Stand - trainer
======================================

SINGLE-PLAYER ONLY.
The game runs a deterministic lockstep simulation. This writes simulation state
directly, so using it in multiplayer will desync every other player in the match.

Built for game build 4.26.2 (Achilles-Win64-Shipping.exe, 92,643,000 bytes).
The trainer checks this on startup and refuses to run against a different build
rather than reading garbage out of the wrong addresses. If the game updates, you
need a new trainer build.


HOW TO USE
----------
1. Start the game and load into a match.
2. Run AoDTrainer.exe (or run.bat).
3. Hold Ctrl+Alt and press a number.

The status line must read "in match" in green. If it says "attached (menu /
loading)" the toggles will refuse - you are not in a match yet.


KEYS
----
  Ctrl+Alt+1    Stockpiles full - gold, iron, stone, wood held at cap
  Ctrl+Alt+2    Gold full
  Ctrl+Alt+3    Purge darkness (hold at 0)
  Ctrl+Alt+4    Freeze resource tick

  Ctrl+Alt+R    Re-scan (use after loading a different map)
  Ctrl+Alt+Q    Quit

The status line shows "held: [CTRL ALT]" while you hold the modifiers, so you can
see the trainer is receiving your keys before you press anything.


WHY "FULL" AND NOT "999999 GOLD"
--------------------------------
The simulation rebuilds your storage cap from your buildings every single tick,
then clamps your resources to it. A written cap is gone within one tick. So the
trainer pins your resources AT the cap instead - which works out the same in
practice, because spending refills within a tick. You never run out.

food and villagers are not stockpiles. They are population counters recomputed
each tick from your actual units, so they cannot be written at all - raising them
means building more housing, not cheating.


IF NOTHING HAPPENS
------------------
Run diagnose.bat with the game in a match. It prints what the trainer can see.
AoDTrainer.exe --keytest prints every key chord it detects for 20 seconds, which
tells you whether the trainer is seeing your keyboard at all.

Administrator is not required. Nothing is injected into the game and no game file
is modified - close the trainer and the game is exactly as it was.
