@echo off
cd /d "%~dp0"
AoDTrainer.exe
